/* ShopJoy Admin - 부서관리 (Tree CRUD 그리드) */
window.SyDeptMng = {
  name: 'SyDeptMng',
  props: {
    navigate:    { type: Function, required: true }, // 페이지 이동
  },
  setup(props) {

    /* ##### [01] 초기 변수 정의 #################################################### */

    const nextId = window.nextId || { value: (arr, key) => ((arr || []).reduce((mm, x) => Math.max(mm, Number(x?.[key]) || 0), 0) || 0) + 1 };
    const { ref, reactive, computed, watch, onMounted } = Vue;
    const showToast    = window.boApp.showToast;   // 토스트 알림
    const showConfirm  = window.boApp.showConfirm; // 확인 모달
    const depts = reactive([]);                    // 부서 트리 데이터
    const uiState = reactive({                     // UI 상태
      checkAll: false, loading: false, error: null, selectedTreeId: null, focusedIdx: null,
    });
    const codes = reactive({ USE_YN: [], DEPT_TYPE: [] });

    /* ===== 검색조건 ===== */

    /* ##### [02] 액션 모음 (dispatch) ############################################## */

    /* handleBtnAction — 버튼 액션 dispatch (cmd: '{영역명}-기능명'). 5줄 이하 짧은 로직은 인라인 */
    const handleBtnAction = (cmd, param = {}) => {
      console.log(' ■■ SyDeptMng.js : handleBtnAction -> ', cmd, param);
      // 검색조건으로 목록 조회
      if (cmd === 'searchParam-list') {
        return handleSearchList('DEFAULT');
      // 검색조건 초기화 + 재조회
      } else if (cmd === 'searchParam-reset') {
        Object.assign(searchParam, searchParamInit);
        return handleSearchList();
      // 부서 그리드 행 추가
      } else if (cmd === 'depts-add') {
        return addRow();
      // 부서 그리드 저장
      } else if (cmd === 'depts-save') {
        return handleSave();
      // 체크된 부서 일괄 삭제
      } else if (cmd === 'depts-deleteChecked') {
        return deleteRows();
      // 체크된 부서 일괄 취소
      } else if (cmd === 'depts-cancelChecked') {
        return cancelChecked();
      // 부서 목록 엑셀 내보내기
      } else if (cmd === 'depts-excel') {
        return exportExcel();
      // 부서 트리 전체 펼치기
      } else if (cmd === 'deptTree-expandAll') {
        return expandAll();
      // 부서 트리 전체 접기
      } else if (cmd === 'deptTree-collapseAll') {
        return collapseAll();
      // 부서 트리 노드 펼치기/접기 토글
      } else if (cmd === 'deptTree-toggle') {
        if (expanded.has(param)) { expanded.delete(param); } else { expanded.add(param); }
        return;
      // 상위부서 선택 모달 닫기
      } else if (cmd === 'parentModal-close') {
        parentModal.show = false;
        return;
      } else {
        console.warn('[handleBtnAction] unknown cmd:', cmd);
      }
    };

    /* handleSelectAction — 그리드 행/노드/모달 선택 액션 dispatch (cmd: '{영역명}-기능명'). 5줄 이하 짧은 로직은 인라인 */
    const handleSelectAction = (cmd, param = {}) => {
      console.log(' ■■ SyDeptMng.js : handleSelectAction -> ', cmd, param);
      // 부서 그리드 행 삭제 마킹
      if (cmd === 'depts-rowDelete') {
        return deleteRow(param);
      // 부서 그리드 행 변경 취소
      } else if (cmd === 'depts-rowCancel') {
        return cancelRow(param);
      // 좌측 트리 노드 선택 → 우측 그리드 필터링
      } else if (cmd === 'deptTree-select') {
        uiState.selectedTreeId = param;
        uiState.focusedIdx = null;        // 트리(부모) 변경 시 자식 포커스행 해제
        uiState.checkAll = false;         // 자식 전체체크 해제 (부모 변경 시 정책)
        return handleGridSearch();
      // 상위부서 선택 모달 열기 (parentPick 컬럼)
      } else if (cmd === 'parentModal-open') {
        return openParentModal(param);
      // 상위부서 모달에서 상위 선택 → 행 parentDeptId 갱신
      } else if (cmd === 'parentModal-select') {
        if (parentModal.targetRow) {
          parentModal.targetRow.parentDeptId = param.deptId;
          parentModal.targetRow._depth = 0;
          onCellChange(parentModal.targetRow);
        }
        parentModal.show = false;
        return;
      } else {
        console.warn('[handleSelectAction] unknown cmd:', cmd);
      }
    };

    /* handleGridCellAction — 그리드 셀 변경/클릭 라우터. colKey 기준 분기 (CRUD 셀 변경) */
    const handleGridCellAction = (cmd, colKey, row, e = {}) => {
      if (cmd === 'depts-cellChange') {
        return onCellChange(row);
      } else {
        console.warn('[handleGridCellAction] unknown cmd:', cmd);
      }
    };


    /* fnCallbackModal — 모든 모달 통합 dispatch. cmd=모달명, param=호출 시 파라미터, result=응답 결과 */
    const fnCallbackModal = (popCmd, param, result) => {
      console.log(' ■■ SyDeptMng : fnCallbackModal -> ', popCmd, param, result);
      if (popCmd === 'cmPopup-parent-dept') {
        if (result == null) {
          parentModal.show = false;
          return;
        }
        if (parentModal.targetRow) {
          parentModal.targetRow.parentDeptId = result.selId;
          parentModal.targetRow._depth = 0;
          onCellChange(parentModal.targetRow);
        }
        parentModal.show = false;
        return;
      } else {
        console.warn('[fnCallbackModal] unknown popCmd:', popCmd);
      }
    };
    const searchParam = reactive({ searchType: '', searchValue: '', type: '', useYn: 'Y' });
    /* searchParamInit — [초기화] 기준값. initPage 끝에서 그때의 searchParam 을 복사해 둔다.
       리터럴 기본값이 아니라 '화면을 열었을 때의 상태'가 기준이라, initPage 가 채운
       기본 기간·사이트 값도 함께 복원된다. (재대입 금지 — Object.assign 으로만 갱신) */
    const searchParamInit = {};

    /* ===== 좌측 부서 트리 ===== */
    const expanded = reactive(new Set([null]));

    /* ===== CRUD 그리드 ===== */
    const gridRows   = reactive([]);
    let   _tempId    = -1;
    const EDIT_FIELDS = ['deptCode', 'deptNm', 'parentDeptId', 'deptTypeCd', 'sortOrd', 'useYn', 'deptRemark'];

    /* ===== 깊이 표시 상수 ===== */
    const DEPTH_BULLETS = ['●', '◦', '·', '-'];
    const DEPTH_COLORS  = ['#e8587a', '#2563eb', '#52c41a', '#f59e0b', '#8b5cf6'];

    /* depthBullet — 깊이 글머리 */
    const depthBullet = (d) => DEPTH_BULLETS[Math.min(d, 3)];

    /* depthColor — 깊이 색상 */
    const depthColor  = (d) => DEPTH_COLORS[d % 5];

    /* ===== 상위부서 선택 모달 ===== */
    const parentModal = reactive({ show: false, targetRow: null });

    /* ##### [04] 내장 사용 함수 (이벤트 핸들러 on* / handle*) ############################ */

    /* handleSearchTree — 부서 트리 조회 */
    const handleSearchTree = async () => {
      try {
        const res = await boApiSvc.syDept.getTree('부서관리', '트리조회');
        const list = res.data?.data || [];
        depts.splice(0, depts.length, ...list);
      } catch (err) {
        console.error('[handleSearchTree]', err);
      }
    };

    /* handleGridSearch — 그리드 목록 조회 (트리 노드 선택 or 검색 조건 기반) */
    const handleGridSearch = async () => {
      uiState.loading = true;
      try {
        const { type, ...restParam } = searchParam;
        const params = {
          pageNo: 1, pageSize: 10000,
          ...Object.fromEntries(Object.entries(restParam).filter(([, v]) => v !== '' && v !== null && v !== undefined)),
          ...(type ? { typeCd: type } : {}),
          /* 좌측 트리 선택 노드 — 서버측 자기참조 재귀 CTE(findTreeDeptIds)로 자손 부서 포함 필터 */
          ...(uiState.selectedTreeId != null ? { parentDeptId: uiState.selectedTreeId } : {}),
        };
        const res = await boApiSvc.syDept.getPage(params, '부서관리', '목록조회');
        const list = res.data?.data?.pageList || res.data?.data?.list || [];
        gridRows.splice(0);
        const treeRows = buildTreeRows(list);
        treeRows.forEach(d => gridRows.push(makeRow(d)));
        uiState.error = null;
      } catch (err) {
        console.error('[handleGridSearch]', err);
        uiState.error = err.message;
      } finally {
        uiState.loading = false;
      }
    };

    /* handleSearchList — 목록 조회 (트리 + 그리드) */
    const handleSearchList = async () => {
      await handleSearchTree();
      await handleGridSearch();
    };

    /* buildTree — 트리 빌드 (orphan 자동 root 처리 — buildTreeRows 와 동일 알고리즘) */
    const buildTree = (items) => {
      const map = {};
      items.forEach(d => { map[d.deptId] = { ...d, children: [] }; });
      const roots = [];
      const attached = new Set();
      items.forEach(d => {
        const hasValidParent = d.parentDeptId && d.parentDeptId !== d.deptId && map[d.parentDeptId];
        if (hasValidParent) { map[d.parentDeptId].children.push(map[d.deptId]); attached.add(d.deptId); }
        else { roots.push(map[d.deptId]); attached.add(d.deptId); }
      });
      const sort = arr => arr.sort((a, b) => (a.sortOrd || 0) - (b.sortOrd || 0));
      const sortAll = (node) => { sort(node.children); node.children.forEach(sortAll); };
      sort(roots).forEach(sortAll);
      return { deptId: null, deptNm: '전체', children: roots };
    };

    const cfTree = computed(() => buildTree(depts));

    /* cfDeptCounts — 부서별 자손 부서수 (자기 자신 제외) — 프론트 자체 계산
     *   { deptId: 자손합계(자기제외), __total__: 전체 부서수 }
     *   - 리프 노드 = 0
     *   - IT개발팀 = 3 (프론트엔드/백엔드/인프라)
     *   - 전체 = 15 (depts.length) */
    const cfDeptCounts = computed(() => {
      const out = {};
      const recur = (node) => {
        let descCnt = 0;
        for (const ch of (node.children || [])) {
          descCnt += 1 + recur(ch); // 자식 본인(1) + 그 자식의 자손
        }
        if (node.deptId != null) out[node.deptId] = descCnt;
        return descCnt;
      };
      cfTree.value.children.forEach(r => recur(r));
      out.__total__ = depts.length;
      return out;
    });

    /* expandAll — 트리 전체 펼치기 */
    const expandAll = () => {
      const walk = (n) => { expanded.add(n.deptId); n.children.forEach(walk); };
      cfTree.value.children.forEach(walk);
      expanded.add(null);
    };

    /* collapseAll — 트리 전체 접기 */
    const collapseAll = () => { expanded.clear(); expanded.add(null); };



    /* fnLoadCodes — 공통코드 로드 */
    const fnLoadCodes = async () => {
      const codeStore = window.sfGetBoCodeStore();
      await codeStore.saLoadCodes(['USE_YN', 'DEPT_TYPE_CD'], { compNm: 'SyDeptMng' });
      codes.USE_YN     = codeStore.sgGetGrpCodes('USE_YN');
      codes.DEPT_TYPE  = codeStore.sgGetGrpCodes('DEPT_TYPE_CD');
    };

    // ★ onMounted — 진입 시 코드 로드 + 트리 + 그리드 조회
    /* initPage — 화면 로드 시퀀스. 마운트 시 실행한다. */
    const initPage = async () => {
      await fnLoadCodes();
      await handleSearchTree();
      expanded.add(null);
      /* 공유된 링크(bo-page shareQuery)로 들어온 경우 URL 쿼리의 검색조건을 복원 */
      const _qs = new URLSearchParams(window.location.search);
      const _reserved = ['page','id','orderId','claimId','embed','dtlMode'];
      Object.keys(searchParam).forEach((k) => { if (!_reserved.includes(k) && _qs.has(k)) searchParam[k] = _qs.get(k); });
      await handleGridSearch();
      Object.assign(searchParamInit, searchParam);   // [초기화] 기준값 스냅샷
    };
    onMounted(initPage);

    /* buildTreeRows — 그리드용 트리 행 빌드 (서버에서 필터된 list 받아 평탄화만)
     *   순환참조/자기참조 안전망 — 누락 부서는 자동 root 처리 */
    const buildTreeRows = (items) => {
      const map = {};
      items.forEach(d => { map[d.deptId] = { ...d, _children: [] }; });
      const roots = [];
      items.forEach(d => {
        const hasValidParent = d.parentDeptId && d.parentDeptId !== d.deptId && map[d.parentDeptId];
        if (hasValidParent) { map[d.parentDeptId]._children.push(map[d.deptId]); }
        else { roots.push(map[d.deptId]); }
      });
      const result = [];
      const visited = new Set();
      const traverse = (node, depth) => {
        if (visited.has(node.deptId)) return;
        visited.add(node.deptId);
        result.push({ ...node, _depth: depth });
        node._children.sort((a, b) => (a.sortOrd || 0) - (b.sortOrd || 0)).forEach(c => traverse(c, depth + 1));
      };
      roots.sort((a, b) => (a.sortOrd || 0) - (b.sortOrd || 0)).forEach(r => traverse(r, 0));
      /* 안전망 — 도달하지 못한 부서(순환참조 등)는 root 로 표시 */
      items.forEach(d => { if (!visited.has(d.deptId)) traverse(map[d.deptId], 0); });
      return result;
    };

    /* makeRow — 행 생성 */
    const makeRow = (d) => ({
      ...d, _depth: d._depth || 0, _row_status: 'N', _row_check: false,
      _row_org: { deptCode: d.deptCode, deptNm: d.deptNm, parentDeptId: d.parentDeptId,
               deptTypeCd: d.deptTypeCd, sortOrd: d.sortOrd, useYn: d.useYn, deptRemark: d.deptRemark },
    });

    /* onCellChange — 셀 변경 감지 */
    const onCellChange = (row) => {
      if (row._row_status === 'I' || row._row_status === 'D') { return; }
      const changed = EDIT_FIELDS.some(f => String(row[f]) !== String(row._row_org[f]));
      row._row_status = changed ? 'U' : 'N';
    };

    /* addRow — 행 추가 */
    const addRow = () => {
      const ref = uiState.focusedIdx !== null ? gridRows[uiState.focusedIdx] : null;
      const newRow = {
        deptId: _tempId--, deptCode: '', deptNm: '', parentDeptId: ref ? ref.parentDeptId : null,
        deptTypeCd: ref ? ref.deptTypeCd : 'HQ',
        sortOrd: ref ? (ref.sortOrd || 0) + 1 : 1,
        useYn: 'Y', deptRemark: '',
        _depth: ref ? ref._depth : 0, _row_status: 'I', _row_check: false, _row_org: null,
      };
      const insertAt = uiState.focusedIdx !== null ? uiState.focusedIdx + 1 : gridRows.length;
      gridRows.splice(insertAt, 0, newRow);
      uiState.focusedIdx = insertAt;
    };

    /* deleteRow — 행 삭제 */
    const deleteRow = (realIdx) => {
      const row = gridRows[realIdx];
      if (row._row_status === 'I') {
        gridRows.splice(realIdx, 1);
        if (uiState.focusedIdx !== null) { uiState.focusedIdx = Math.max(0, uiState.focusedIdx - (uiState.focusedIdx >= realIdx ? 1 : 0)); }
      } else { row._row_status = 'D'; }
    };

    /* cancelRow — 행 취소 */
    const cancelRow = (realIdx) => {
      const row = gridRows[realIdx];
      if (row._row_status === 'I') {
        gridRows.splice(realIdx, 1);
        if (uiState.focusedIdx !== null) { uiState.focusedIdx = Math.max(0, uiState.focusedIdx - (uiState.focusedIdx >= realIdx ? 1 : 0)); }
      } else {
        if (row._row_org) { EDIT_FIELDS.forEach(f => { row[f] = row._row_org[f]; }); }
        row._row_status = 'N';
      }
    };

    /* cancelChecked — 선택 행 취소 */
    const cancelChecked = () => {
      const checkedIds = new Set(gridRows.filter(r => r._row_check).map(r => r.deptId));
      if (!checkedIds.size) { showToast('취소할 행을 선택해주세요.', 'info'); return; }
      for (let i = gridRows.length - 1; i >= 0; i--) {
        const row = gridRows[i];
        if (!checkedIds.has(row.deptId)) { continue; }
        if (row._row_status === 'I') { gridRows.splice(i, 1); }
        else if (row._row_status !== 'N') {
          if (row._row_org) { EDIT_FIELDS.forEach(f => { row[f] = row._row_org[f]; }); }
          row._row_status = 'N';
        }
      }
    };

    /* deleteRows — 선택 행 삭제 */
    const deleteRows = () => {
      for (let i = gridRows.length - 1; i >= 0; i--) {
        if (!gridRows[i]._row_check) { continue; }
        if (gridRows[i]._row_status === 'I') { gridRows.splice(i, 1); }
        else { gridRows[i]._row_status = 'D'; }
      }
    };

    /* handleSave — 저장 */
    const handleSave = async () => {
      const iRows = gridRows.filter(r => r._row_status === 'I');
      const uRows = gridRows.filter(r => r._row_status === 'U');
      const dRows = gridRows.filter(r => r._row_status === 'D');
      if (!iRows.length && !uRows.length && !dRows.length) { showToast('변경된 데이터가 없습니다.', 'error'); return; }
      for (const r of [...iRows, ...uRows]) {
        if (!r.deptCode || !r.deptNm) { showToast('부서코드와 부서명은 필수 항목입니다.', 'error'); return; }
      }
      const details = [];
      if (iRows.length) { details.push({ label: `등록 ${iRows.length}건`, cls: 'badge-blue' }); }
      if (uRows.length) { details.push({ label: `수정 ${uRows.length}건`, cls: 'badge-orange' }); }
      if (dRows.length) { details.push({ label: `삭제 ${dRows.length}건`, cls: 'badge-red' }); }
      const ok = await showConfirm('저장 확인', '다음 내용을 저장하시겠습니까?', { details, btnOk: '예', btnCancel: '아니오' });
      if (!ok) { return; }
      const saveRows = [...iRows, ...uRows, ...dRows].map(r => ({ ...r, rowStatus: r._row_status }));
      try {
        await boApiSvc.syDept.saveList('base', saveRows, '부서관리', '저장');
        showToast('저장되었습니다.');
        await handleSearchList();
      } catch (err) {
        showToast(coUtil.cofErrMsg(err), 'error', 0);
      }
    };

    /* openParentModal — 상위부서 선택 모달 열기 (handleSearchList 호출 X — gridRows 가 새로 갱신되면 targetRow 가 stale ref 됨) */
    const openParentModal = (row) => { parentModal.targetRow = row; parentModal.show = true; };

    /* excelModal — 엑셀 다운로드 (공용 모달) */
    const excelModal = reactive({ show: false });
    const buildExcelParams = () => {
      const { type, ...restParam } = searchParam;
      return {
        ...Object.fromEntries(Object.entries(restParam).filter(([, v]) => v !== '' && v !== null && v !== undefined)),
        ...(type ? { typeCd: type } : {}),
        ...(uiState.selectedTreeId != null ? { parentDeptId: uiState.selectedTreeId } : {}),
      };
    };
    const exportExcel = () => { excelModal.show = true; };

    /* ##### [05] 사용자 함수 (헬퍼 / 카운트 / 렌더 / 컬럼정의) #################### */

    const cfSiteNm = computed(() => boUtil.bofGetSiteNm());
    const cfTypeOptions = computed(() => [...new Set(depts.map(d => d.deptTypeCd).filter(v => v != null && v !== ''))].sort());

    /* parentNm — 상위 부서명 */
    const parentNm = (parentDeptId) => {
      if (!parentDeptId) { return ''; }
      const p = depts.find(d => d.deptId === parentDeptId);
      return p ? p.deptNm : `ID:${parentDeptId}`;
    };

    // 기본 검색
    const columns = {};
    columns.baseSearch = [
      { key: 'searchType', type: 'multiCheck', label: '검색대상',
        options: [
          { value: 'deptCode', label: '부서코드' },
          { value: 'deptNm',   label: '부서명' },
        ],
        placeholder: '검색대상 전체', allLabel: '전체 선택', minWidth: '160px' },
      { key: 'searchValue', type: 'text', label: '검색어', placeholder: '검색어 입력' },
      { key: 'type', type: 'select', label: '유형', options: () => cfTypeOptions.value, nullLabel: '유형 전체' },
      { key: 'useYn', type: 'select', label: '사용여부', options: () => codes.USE_YN, nullLabel: '사용여부 전체' },
    ];

    // 기본 그리드
    columns.baseGrid = [
      { key: 'deptCode',     label: '부서코드', style: 'width:110px;',    edit: 'text', mono: true },
      { key: 'deptNm',       label: '부서명',   style: 'min-width:190px;', edit: 'text',
        treeDepth: true, treeBullet: depthBullet, treeColor: depthColor },
      { key: 'parentDeptId', label: '상위부서', style: 'min-width:150px;',
        parentPick: { label: parentNm, open: (row) => handleSelectAction('parentModal-open', row),
          clear: (row) => { row.parentDeptId = null; onCellChange(row); }, title: '상위부서 선택' } },
      { key: 'deptTypeCd',   label: '유형',     style: 'width:90px;',     edit: 'select', options: () => codes.DEPT_TYPE },
      { key: 'sortOrd',      label: '순서',     cls: 'col-ord',  edit: 'number' },
      { key: 'useYn',        label: '사용여부', cls: 'col-use',  edit: 'select', options: () => codes.USE_YN },
      { key: 'deptRemark',   label: '비고',     edit: 'text' },
      { key: 'siteNm',       label: '사이트명', style: 'width:80px;', align: 'center',
        cellStyle: 'font-size:11px;color:#2563eb;', fmt: () => cfSiteNm.value },
    ];

    /* ##### [06] return (템플릿 노출) ############################################## */

    return {
      columns,
      depts, uiState, searchParam, gridRows, expanded, parentModal,       // 상태 / 데이터
      excelModal, buildExcelParams, // 엑셀 다운로드 모달
      handleBtnAction, handleSelectAction, handleGridCellAction, fnCallbackModal,                                                                   // dispatch (모든 이벤트 / 액션 라우팅)
      cfTree, cfDeptCounts, // computed
    };
  },
  template: /* html */`
<bo-page title="부서관리" :share-query="searchParam">
  <!-- ===== ■. 검색 ====================================================== -->
  <bo-container>
    <bo-search-area :loading="uiState.loading" @search="handleBtnAction('searchParam-list')" @reset="handleBtnAction('searchParam-reset')" :columns="columns.baseSearch" :param="searchParam" />
  </bo-container>
  <!-- ===== ■. 본문 영역 (트리 + 목록) ===================================== -->
  <div class="bo-2col">
    <!-- ===== ■.■. 부서 트리 ================================================= -->
    <bo-container title="📂 부서">
      <template #toolbar-actions>
        <button class="btn btn_expand_all" @click="handleBtnAction('deptTree-expandAll')" style="font-size:11px;">
          ▼ 전체펼치기
        </button>
        <button class="btn btn_collapse_all" @click="handleBtnAction('deptTree-collapseAll')" style="font-size:11px;">
          ▶ 전체닫기
        </button>
      </template>
      <div style="max-height:calc(100vh - 320px);overflow:auto;">
        <bo-dept-tree-node :node="cfTree" :expanded="expanded" :selected="uiState.selectedTreeId"
          :on-toggle="id => handleBtnAction('deptTree-toggle', id)"
          :on-select="id => handleSelectAction('deptTree-select', id)"
          :depth="0" :counts="cfDeptCounts" />
      </div>
    </bo-container>
    <!-- ===== ■.■. 부서목록 CRUD 그리드 ====================================== -->
    <bo-container bare>
      <bo-grid-crud
        :columns="columns.baseGrid" :rows="gridRows" row-key="deptId" :selected-key="uiState.selectedTreeId"
        list-title="부서목록" :show-export="true" :draggable="false" max-height="calc(100vh - 320px)"
        v-model:focusedIdx="uiState.focusedIdx"
        v-model:checkAll="uiState.checkAll"
        @add="handleBtnAction('depts-add')" @save="handleBtnAction('depts-save')"
        @delete-checked="handleBtnAction('depts-deleteChecked')" @cancel-checked="handleBtnAction('depts-cancelChecked')"
        grid-id="depts-cellChange" @cell-change="e => handleGridCellAction(e.cmd, e.colKey, e.row, e)"
        @export="handleBtnAction('depts-excel')">
        <template #row-actions="{ row, idx }">
          <bo-row-cancel-delete :row="row" :allow-delete-null="true"
            @cancel="handleSelectAction('depts-rowCancel', idx)"
            @delete="handleSelectAction('depts-rowDelete', idx)" />
        </template>
      </bo-grid-crud>
      <!-- ===== ■.■.■. 상위부서 선택 모달 ========================================= -->
      <bo-cm-popup-modal v-if="parentModal ? (parentModal.show) : false" popup-cmd="cmPopup-parent-dept" popup-code="dept" clearable :exclude-id="parentModal.targetRow?.deptId > 0 ? parentModal.targetRow.deptId : null" :on-callback="fnCallbackModal" />
      <bo-excel-down-modal :show="excelModal.show" domain="dept" area-nm="부서"
        :columns="columns.baseGrid" ui-nm="부서관리" :params="buildExcelParams()"
        @close="excelModal.show = false" />
    </bo-container>
  </div>
  <!-- ===== □. 본문 영역 =================================================== -->
</bo-page>
`,
};

/* BoDeptTreeNode (구 DeptTreeNode) 는 components/comp/BoComp.js 로 이동. 태그: <bo-dept-tree-node> */
