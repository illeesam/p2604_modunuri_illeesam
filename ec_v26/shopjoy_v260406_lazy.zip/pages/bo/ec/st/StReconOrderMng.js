/* ShopJoy Admin - 주문-정산 대사 */
window.StReconOrderMng = {
  name: 'StReconOrderMng',
  props: {
    navigate:     { type: Function, required: true }, // 페이지 이동
  },
  setup(props) {

    /* ##### [01] 초기 변수 정의 ################################################## */

    const { ref, reactive, computed, watch, onMounted } = Vue;
const uiState = reactive({ error: null, dateRange: '이번달', dateRangeStart: '', dateRangeEnd: ''});
    const codes = reactive({
      order_statuses: [],
      recon_results: [],
      date_range_opts: [],
    });

    /* ##### [02] 액션 모음 (dispatch) ############################################## */

    /* handleBtnAction — 버튼 액션 dispatch (cmd: '{영역명}-기능명'). 5줄 이하 짧은 로직은 인라인 */
    const handleBtnAction = (cmd, param = {}) => {
      console.log(' ■■ StReconOrderMng.js : handleBtnAction -> ', cmd, param);
      if (cmd === 'searchParam-list') {
        baseGridPager.pageNo = 1;
        return handleSearchList('DEFAULT');
      } else if (cmd === 'searchParam-reset') {
        Object.assign(searchParam, searchParamInit);
        baseGridPager.pageNo = 1;
        return handleSearchList('DEFAULT');
      } else if (cmd === 'searchParam-dateRange') {
        return handleDateRangeChange();
      } else if (cmd === 'reconOrders-pager-setPage') {
        if (param >= 1 && param <= baseGridPager.pageTotalPage) { baseGridPager.pageNo = param; handleSearchList('PAGE_CLICK'); }
        return;
      } else {
        console.warn('[handleBtnAction] unknown cmd:', cmd);
      }
    };

    /* handleSelectAction — 페이지 선택 액션 dispatch */
    const handleSelectAction = (cmd, param = {}) => {
      console.log(' ■■ StReconOrderMng.js : handleSelectAction -> ', cmd, param);
      if (cmd === 'reconOrders-pager-sizeChange') {
        baseGridPager.pageNo = 1;
        return handleSearchList('DEFAULT');
      } else {
        console.warn('[handleSelectAction] unknown cmd:', cmd);
      }
    };

    /* ##### [03] 초기 함수 (마운트 / 코드 로드 / watch) ############################## */

    /* fnLoadCodes — 공통코드 로드 */
    const fnLoadCodes = async () => {
      const codeStore = window.sfGetBoCodeStore();
      /* 필요한 코드그룹만 지연 로딩 — 캐시에 있으면 API 가 나가지 않는다 */
      await codeStore.saLoadCodes(['ORDER_STATUS_CD', 'RECON_RESULT_ORDER', 'DATE_RANGE_OPT'], {compNm: 'StReconOrderMng'});
      try {
        codes.order_statuses = codeStore.sgGetGrpCodes('ORDER_STATUS_CD');
        codes.recon_results = codeStore.sgGetGrpCodes('RECON_RESULT_ORDER');
        codes.date_range_opts = codeStore.sgGetGrpCodes('DATE_RANGE_OPT');
      } catch (err) {
        console.error('[fnLoadCodes]', err);
      }
    };

    /* handleDateRangeChange — 기간 변경 (searchParam.dateRange → dateRangeStart/dateRangeEnd) */
    const handleDateRangeChange = () => {
      boUtil.bofApplyDateRange(searchParam);
    };

    const rows = reactive([]);
    const excelModal = reactive({ show: false });   // 엑셀 다운로드 모달 표시 여부

    const searchParam = reactive({ searchType: '', searchValue: '', reconStatusCd: '', dateRangeType: 'reg_date', dateRange: '', dateRangeStart: '', dateRangeEnd: '' });
    /* searchParamInit — [초기화] 기준값. initPage 끝에서 그때의 searchParam 을 복사해 둔다.
       리터럴 기본값이 아니라 '화면을 열었을 때의 상태'가 기준이라, initPage 가 채운
       기본 기간·사이트 값도 함께 복원된다. (재대입 금지 — Object.assign 으로만 갱신) */
    const searchParamInit = {};
    const baseGridPager = reactive({ pageType: 'PAGE', pageNo: 1, pageSize: 10, pageTotalCount: 0, pageTotalPage: 1, pageSizes: [5, 10, 20, 30, 50, 100, 200, 500], pageCond: {} });


    const cfSummary = computed(() => ({
      match:   rows.filter(r => r.diffStatus==='MATCH').length,
      over:    rows.filter(r => r.diffStatus==='SETTLE_EXCESS').length,
      under:   rows.filter(r => r.diffStatus==='SETTLE_SHORTAGE').length,
      diffAmt: rows.reduce((s, r) => s + Math.abs(r.diff||0), 0),
    }));

    /* ##### [04] 내장 사용 함수 (이벤트 핸들러 on* / handle*) #################### */

    /* buildListParams — 검색조건 빌드 (pageNo/pageSize 제외, 목록조회·엑셀다운로드 공용).
       ⚠ reconTypeCd 가 StReconDto.Request 의 실제 필드명이다 — 이전에는 존재하지 않는
          typeCd 로 보내 서버가 조용히 무시하고 전체 유형이 섞여 나왔다. */
    const buildListParams = () => {
      const params = { reconTypeCd: 'ORDER', ...coUtil.cofOmitEmpty(searchParam) };
      // searchValue 가 있는데 searchType 가 비어있으면 전체 필드로 검색
      if (params.searchValue && !params.searchType) {
        params.searchType = 'refId,refNo';
      }
      return params;
    };

    /* buildExcelParams — 엑셀 다운로드 조건 (목록 조회와 동일한 필터 기준) */
    const buildExcelParams = () => buildListParams();

    /* handleSearchList — 목록 조회 */
    const handleSearchList = async (searchType = 'DEFAULT') => {
      try {
        const params = { pageNo: baseGridPager.pageNo, pageSize: baseGridPager.pageSize, ...buildListParams() };
        const res = await boApiSvc.stRecon.getPage(params, '주문-정산 대사', '목록조회');
        const data = res.data?.data;
        rows.splice(0, rows.length, ...(data?.pageList || data?.list || rows));
        baseGridPager.pageTotalCount = data?.pageTotalCount || rows.length;
        baseGridPager.pageTotalPage = data?.pageTotalPage || coUtil.cofTotalPage(baseGridPager);
        coUtil.cofBuildPagerNums(baseGridPager);
        Object.assign(baseGridPager.pageCond, data?.pageCond || baseGridPager.pageCond);
      } catch (_) {
        console.error('[catch-info]', _);
      }
    };

    // ★ onMounted
    /* initPage — 화면 로드 시퀀스.
       코드 응답을 받은 뒤 초기 조회를 시작한다 — 코드 기반 select·라벨·기본값이
       빈 상태로 첫 조회가 나가는 것을 막는다(순서가 코드에 드러나도록 한 곳에 모았다). */
    const initPage = async () => {
      await fnLoadCodes();
      /* 공유된 링크(bo-page shareQuery)로 들어온 경우 URL 쿼리의 검색조건을 복원 */
      const _qs = new URLSearchParams(window.location.search);
      const _reserved = ['page','id','orderId','claimId','embed','dtlMode'];
      Object.keys(searchParam).forEach((k) => { if (!_reserved.includes(k) && _qs.has(k)) searchParam[k] = _qs.get(k); });
      await handleSearchList('DEFAULT');
      Object.assign(searchParamInit, searchParam);   // [초기화] 기준값 스냅샷
    };
    onMounted(initPage);

    /* fnDiffBadge — 유틸 */
    const fnDiffBadge = s => ({ '일치':'badge-green', '정산과다':'badge-red', '정산부족':'badge-orange' }[s] || 'badge-gray');

    /* fmtW — 포맷 W */
    const fmtW = coUtil.cofWon;





    /* setPage — 설정 */
    const setPage = n => { if (n >= 1 && n <= baseGridPager.pageTotalPage) { baseGridPager.pageNo = n; handleSearchList('PAGE_CLICK'); } };



    /* ##### [05] 사용자 함수 (헬퍼 / 카운트 / 렌더 / 컬럼정의) #################### */

    // --- [컬럼 정의] ---

    const columns = {};
    columns.baseSearch = [
      { key: 'dateRange', label: '대사일', type: 'dateRange',
        typeKey: 'dateRangeType', startKey: 'dateRangeStart', endKey: 'dateRangeEnd',
        typeOptions: () => [{ value: 'reg_date', label: '등록일' }, { value: 'upd_date', label: '수정일' }],
        rangeOptions: () => codes.date_range_opts,
        rangeFirst: true, dateWidth: '140px',
        sepStyle: 'line-height:32px',
        onRangeChange: () => handleDateRangeChange() },
      { key: 'reconStatusCd', label: '대사결과', type: 'select', options: () => codes.recon_results, nullLabel: '대사결과 전체' },
      { key: 'searchType', label: '검색대상', type: 'multiCheck',
        options: [{ value: 'refId', label: '주문ID' }, { value: 'refNo', label: '주문번호' }],
        placeholder: '검색대상 전체', allLabel: '전체 선택', minWidth: '160px' },
      { key: 'searchValue', label: '검색어', type: 'text', placeholder: '검색어 입력', width: '180px' },
    ];

    // 기본 그리드
    columns.baseGrid = [
      { key: 'orderId',    label: '주문ID' },
      { key: 'orderDate',  label: '주문일',  fmt: (v) => coUtil.cofYmd(v) || '-' },
      { key: 'vendorNm',   label: '업체' },
      { key: 'orderAmt',   label: '주문금액', fmt: fmtW },
      { key: 'settleAmt',  label: '정산기준액', fmt: fmtW },
      { key: 'reconAmt',   label: '실정산액', fmt: fmtW },
      { key: 'diff',       label: '차이금액',
        fmt: (v) => v !== 0 ? (v > 0 ? '+' : '') + Number(v).toLocaleString() + '원' : '-',
        cellStyle: (v) => Math.abs(v) > 0 ? 'color:#e74c3c;font-weight:700' : '' },
      { key: 'diffStatus', label: '대사결과', badge: (row) => fnDiffBadge(row.diffStatus) },
    ];

    /* summaryFormColumns — 집계 요약 (검색영역과 같은 스케일의 자유배치 행) */
    columns.summaryForm = [
      { key: '_match',   label: '일치',          fmt: () => `<b style="color:#27ae60;">${cfSummary.value.match}건</b>` },
      { key: '_over',    label: '정산과다',      fmt: () => `<b style="color:#e74c3c;">${cfSummary.value.over}건</b>` },
      { key: '_under',   label: '정산부족',      fmt: () => `<b style="color:#e67e22;">${cfSummary.value.under}건</b>` },
      { key: '_diffAmt', label: '차이금액 합계', fmt: () => `<b style="color:#333;">${fmtW(cfSummary.value.diffAmt)}</b>` },
    ];

    /* ##### [06] return (템플릿 노출) ############################################## */

    return {
      columns,
      uiState, baseGridPager, rows, searchParam, excelModal,       // 상태 / 데이터
      handleBtnAction, handleSelectAction, buildExcelParams, // dispatch
    };
  },
  template: /* html */`
<bo-page title="주문-정산 대사" :share-query="searchParam"
  desc-summary="주문 데이터와 정산 수집원장 간 금액 불일치를 검출하고 대사 처리합니다."
  :desc-detail="['• 주문금액(order_amt) vs 정산수집 금액(recon_amt) 차이를 자동 비교합니다.','• 차이 상태: 일치 / 차이발생 / 검토중 / 처리완료','• 차이 발생 건은 원인 파악 후 조정(StSettleAdjMng)으로 처리하거나 수동 대사 확인합니다.'].join(String.fromCharCode(10))">
  <!-- ===== ■. 검색 영역 ================================================= -->
  <bo-container>
    <bo-search-area :loading="uiState.loading" bar-style="flex-wrap:wrap;gap:8px"
      :columns="columns.baseSearch" :param="searchParam"
      @search="handleBtnAction('searchParam-list')" @reset="handleBtnAction('searchParam-reset')" />
  </bo-container>
  <!-- ===== ■. 목록 영역 ================================================= -->
  <bo-container title="목록" :count-text="baseGridPager.pageTotalCount + '건'">
    <template #toolbar-actions>
      <button class="btn btn_excel" @click="excelModal.show = true">엑셀</button>
    </template>
    <div style="display:flex;flex-wrap:wrap;align-items:center;gap:8px 24px;padding:8px 14px;background:#f8f9fb;border:1px solid #e5e7eb;border-radius:8px;font-size:12px;">
      <span v-for="c in columns.summaryForm" :key="c.key" style="color:#666;">
        {{ c.label }}: <span v-html="c.fmt()"></span>
      </span>
    </div>
    <div style="height:12px"></div>
    <bo-grid bare
      :columns="columns.baseGrid" :rows="rows" row-key="orderId" />
    <bo-pager :pager="baseGridPager" :on-set-page="n => handleBtnAction('reconOrders-pager-setPage', n)" :on-size-change="() => handleSelectAction('reconOrders-pager-sizeChange')" />
  </bo-container>
  <bo-excel-down-modal :show="excelModal.show" domain="stRecon" area-nm="주문-정산 대사"
    ui-nm="주문-정산 대사" :columns="columns.baseGrid" :params="buildExcelParams()"
    @close="excelModal.show = false" />
</bo-page>
`,
};
