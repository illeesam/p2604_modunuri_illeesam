/* ShopJoy Admin - 전시위젯Lib 위젯미리보기 (#page=ecDispWidgetLibPreview) */

/* -- 위젯미리보기 서브컴포넌트 (grid · dashboard 공용) -- */
const _WidgetPreview = {
  name: 'WidgetPreview',
  props: { lib: Object, compact: { type: Boolean, default: false } },
  setup(props) {
    // ===== 초기 변수 정의 =====================================================

    const { ref, reactive, computed, watchEffect, onMounted } = Vue;
    const showToast    = window.boApp.showToast;  // 토스트 알림
    const showConfirm  = window.boApp.showConfirm;  // 확인 모달
    const showRefModal = window.boApp.showRefModal;  // 참조 모달
    /* 차트 막대 — coUtil.cofChartBars 위임 (팔레트/계산 공용) */
    const cfChartBars = computed(() => coUtil.cofChartBars((props.lib || {}).chartValues, (props.lib || {}).chartLabels));

    // ===== return (템플릿 노출) ===============================================

    return { cfChartBars, coUtil };
  },
  template: /* html */`
<div style="padding:10px;">
  <!-- ===== ■. 이미지 배너 ================================================== -->
  <template v-if="lib.widgetType==='image_banner'">
    <div style="border-radius:6px;overflow:hidden;background:#f0f0f0;">
      <img v-if="lib.imageUrl" :src="coUtil.cofImgSrc(lib.imageUrl)" style="width:100%;display:block;max-height:130px;object-fit:cover;" />
      <div v-else style="height:80px;display:flex;align-items:center;justify-content:center;color:#ccc;font-size:12px;">🖼 이미지 배너</div>
    </div>
    <div v-if="lib.linkUrl" style="font-size:10px;color:#aaa;margin-top:4px;">🔗 {{ lib.linkUrl }}</div>
  </template>
  <!-- ===== □. 이미지 배너 ================================================== -->
  <!-- ===== ■. 상품 슬라이더 / 상품 ============================================ -->
  <template v-else-if="lib.widgetType==='product_slider'||lib.widgetType==='product'">
    <div style="font-size:12px;font-weight:700;color:#222;margin-bottom:7px;">{{ lib.name }}</div>
    <div style="display:flex;gap:6px;overflow-x:auto;">
      <div v-for="i in 4" :key="i" style="flex-shrink:0;width:64px;text-align:center;">
        <div style="height:56px;background:#f5f5f5;border-radius:5px;margin-bottom:4px;display:flex;align-items:center;justify-content:center;font-size:16px;">
          👗
        </div>
        <div style="font-size:10px;color:#888;">상품{{ i }}</div>
      </div>
    </div>
  </template>
  <!-- ===== □. 상품 슬라이더 / 상품 ============================================ -->
  <!-- ===== ■. 차트 ====================================================== -->
  <template v-else-if="lib.widgetType ? (lib.widgetType.startsWith('chart_')) : false">
    <div style="font-size:12px;font-weight:700;color:#222;margin-bottom:8px;">{{ lib.chartTitle||lib.name }}</div>
    <div v-if="cfChartBars.length" style="display:flex;align-items:flex-end;gap:4px;height:60px;">
      <div v-for="(bar,i) in cfChartBars" :key="i" style="flex:1;display:flex;flex-direction:column;align-items:center;gap:2px;">
        <div :style="{height:bar.pct+'%',background:bar.color,borderRadius:'3px 3px 0 0',width:'100%',minHeight:'3px'}"></div>
        <div style="font-size:9px;color:#aaa;">{{ bar.label }}</div>
      </div>
    </div>
    <div v-else style="height:50px;display:flex;align-items:center;justify-content:center;color:#ccc;font-size:11px;">데이터 없음</div>
  </template>
  <!-- ===== □. 차트 ====================================================== -->
  <!-- ===== ■. 텍스트 배너 ================================================== -->
  <template v-else-if="lib.widgetType==='text_banner'">
    <div :style="{background:lib.bgColor||'#fff',color:lib.textColor||'#222',padding:'10px',borderRadius:'5px',border:'1px solid #eee',fontSize:'12px'}">
      <span v-if="lib.textContent" v-html="lib.textContent"></span>
      <span v-else style="color:#ccc;">텍스트 배너</span>
    </div>
  </template>
  <!-- ===== □. 텍스트 배너 ================================================== -->
  <!-- ===== ■. 정보 카드 =================================================== -->
  <template v-else-if="lib.widgetType==='info_card'">
    <div style="background:#f8f9fa;border-radius:5px;padding:10px;border:1px solid #eee;">
      <div style="font-size:12px;font-weight:700;margin-bottom:4px;">{{ lib.infoTitle||'카드 제목' }}</div>
      <div style="font-size:11px;color:#666;white-space:pre-line;">{{ (lib.infoBody||'카드 내용').slice(0,100) }}</div>
    </div>
  </template>
  <!-- ===== □. 정보 카드 =================================================== -->
  <!-- ===== ■. 쿠폰 ====================================================== -->
  <template v-else-if="lib.widgetType==='coupon'">
    <div style="background:linear-gradient(135deg,#e8587a,#f97316);border-radius:6px;padding:12px;color:#fff;display:flex;align-items:center;justify-content:space-between;gap:8px;">
      <div>
        <div style="font-size:10px;opacity:.8;">쿠폰</div>
        <div style="font-size:14px;font-weight:700;">{{ lib.couponCode||'CODE' }}</div>
        <div v-if="lib.couponDesc" style="font-size:10px;opacity:.8;">{{ lib.couponDesc }}</div>
      </div>
      <span style="font-size:22px;">🎟</span>
      <div style="border:2px dashed rgba(255,255,255,.5);border-radius:6px;padding:5px 12px;font-size:11px;font-weight:700;white-space:nowrap;">
        쿠폰 발기
      </div>
    </div>
  </template>
  <!-- ===== □. 쿠폰 ====================================================== -->
  <!-- ===== ■. 캐시 배너 =================================================== -->
  <template v-else-if="lib.widgetType==='cache_banner'">
    <div style="background:linear-gradient(135deg,#f59e0b,#d97706);border-radius:6px;padding:12px;color:#fff;display:flex;align-items:center;gap:10px;">
      <span style="font-size:22px;">💰</span>
      <div>
        <div style="font-size:10px;opacity:.8;">적립 캐시</div>
        <div style="font-size:16px;font-weight:800;">{{ lib.cacheAmount ? lib.cacheAmount.toLocaleString()+'원' : '-' }}</div>
        <div v-if="lib.cacheDesc" style="font-size:10px;opacity:.8;">{{ lib.cacheDesc }}</div>
      </div>
    </div>
  </template>
  <!-- ===== □. 캐시 배너 =================================================== -->
  <!-- ===== ■. HTML 에디터 ================================================ -->
  <template v-else-if="lib.widgetType==='html_editor'">
    <div v-if="lib.htmlContent" v-html="lib.htmlContent" style="font-size:12px;overflow:hidden;max-height:120px;"></div>
    <div v-else style="color:#ccc;font-size:11px;padding:8px 0;">HTML 미리보기</div>
  </template>
  <!-- ===== □. HTML 에디터 ================================================ -->
  <!-- ===== ■. 위젯 임베드 ================================================== -->
  <template v-else-if="lib.widgetType==='widget_embed'">
    <div v-if="lib.embedCode" v-html="lib.embedCode" style="overflow:hidden;max-height:140px;"></div>
    <div v-else style="color:#ccc;font-size:11px;padding:8px 0;">임베드 미리보기</div>
  </template>
  <!-- ===== □. 위젯 임베드 ================================================== -->
  <!-- ===== ■. 팝업 ====================================================== -->
  <template v-else-if="lib.widgetType==='popup'">
    <div style="border:2px solid #e0e0e0;border-radius:6px;overflow:hidden;">
      <div style="background:#444;color:#fff;padding:5px 10px;font-size:11px;display:flex;justify-content:space-between;">
        <span>팝업</span>
        <span>✕</span>
      </div>
      <div style="height:60px;background:#f5f5f5;display:flex;align-items:center;justify-content:center;color:#bbb;font-size:11px;">
        {{ lib.popupWidth||600 }}×{{ lib.popupHeight||400 }}
      </div>
    </div>
  </template>
  <!-- ===== □. 팝업 ====================================================== -->
  <!-- ===== ■. 파일 ====================================================== -->
  <template v-else-if="lib.widgetType==='file'">
    <div style="display:flex;align-items:center;gap:8px;padding:10px;border:1px solid #e5e7eb;border-radius:6px;background:#f9fafb;">
      <span style="font-size:20px;">📎</span>
      <div>
        <div style="font-size:12px;font-weight:600;color:#222;">{{ lib.fileLabel||'파일 다운로드' }}</div>
        <div v-if="lib.fileUrl" style="font-size:10px;color:#aaa;">{{ lib.fileUrl.split('/').pop() }}</div>
      </div>
    </div>
  </template>
  <!-- ===== □. 파일 ====================================================== -->
  <!-- ===== ■. 기타 ====================================================== -->
  <template v-else>
    <div style="background:#f5f5f5;border-radius:6px;padding:16px;text-align:center;color:#bbb;">
      <div style="font-size:24px;margin-bottom:4px;">▪</div>
      <div style="font-size:11px;">{{ lib.name }}</div>
    </div>
  </template>
</div>

  <!-- ===== □. 기타 ====================================================== -->`,
};

/* -- 메인 컴포넌트 -- */
window.DpDispWidgetLibPreview = {
  name: 'DpDispWidgetLibPreview',
  props: {
    navigate:     { type: Function, required: true }, // 페이지 이동
  },
  setup(props) {
    // ===== 초기 변수 정의 =====================================================

    const { ref, reactive, computed, watch, watchEffect, onMounted } = Vue;
    const showToast = window.boApp.showToast;
    const codes = reactive({ widget_status_opts: [{value:'활성',label:'활성'},{value:'비활성',label:'비활성'}], need_yn_opts: [{codeValue:'Y',codeLabel:'필요'},{codeValue:'N',codeLabel:'불필요'}], condition_opts: ['항상 표시','로그인 필요','로그인+VIP','로그인+우수','비로그인 전용'], auth_grade_opts: ['일반','우수','VIP'] });
    const cfDispWidgetTypes = computed(() => {
      const codeStore = window.sfGetBoCodeStore();
      return codeStore?.sgGetGrpCodes?.('WIDGET_TYPE_CD') || [];
    });
    const widgetLibs = reactive([]);
    const cfSiteNm = computed(() => boUtil.bofGetSiteNm());

    /* handleBtnAction — 버튼 액션 dispatch (cmd: '{영역명}-기능명'). 5줄 이하 짧은 로직은 인라인 */
    const handleBtnAction = (cmd, param = {}) => {
      console.log(' ■■ DpDispWidgetLibPreview.js : handleBtnAction -> ', cmd, param);
      // 검색조건으로 목록 필터링
      if (cmd === 'searchParam-list') {
        return onSearch();
      // 검색조건 초기화
      } else if (cmd === 'searchParam-reset') {
        return onReset();
      // 트리 전체 펼치기
      } else if (cmd === 'pathTree-expand-all') {
        return expandAll();
      // 트리 전체 닫기
      } else if (cmd === 'pathTree-collapse-all') {
        return collapseAll();
      // 실제컨텐츠 토글
      } else if (cmd === 'preview-toggle-real') {
        uiState.showRealContent = !uiState.showRealContent;
        return;
      // 현재 그리드 / 대시보드 초기화
      } else if (cmd === 'preview-reset') {
        return resetCurrent();
      // span 팝업 닫기
      } else if (cmd === 'spanPopup-close') {
        return closeSpanPopup();
      // 슬롯 제거 (param: idx)
      } else if (cmd === 'slot-remove') {
        return removeSlot(param);
      // 대시보드 항목 제거 (param: id)
      } else if (cmd === 'dashItem-remove') {
        return removeDashItem(param);
      } else {
        console.warn('[handleBtnAction] unknown cmd:', cmd);
      }
    };

    /* handleSelectAction — 그리드 행/노드/모달 선택 액션 dispatch (cmd: '{영역명}-기능명'). 5줄 이하 짧은 로직은 인라인 */
    const handleSelectAction = (cmd, param = {}) => {
      console.log(' ■■ DpDispWidgetLibPreview.js : handleSelectAction -> ', cmd, param);
      // 트리 노드 토글 (param: key)
      if (cmd === 'pathTree-toggle') {
        return toggleNode(param);
      // 트리 노드 전체 자식 토글 (param: { e, node })
      } else if (cmd === 'pathTree-toggle-children') {
        return toggleAllChildren(param.e, param.node);
      // 트리에서 위젯 선택 (param: lib)
      } else if (cmd === 'pathTree-select') {
        return onTreeSelect(param);
      // 그리드 탭 전환 (param: tabId)
      } else if (cmd === 'preview-tab') {
        uiState.previewGrid = param;
        return;
      // 뷰포트 모드 변경 (param: key)
      } else if (cmd === 'preview-viewport') {
        uiState.viewportMode = param;
        return;
      // span 설정 (param: { idx, axis, delta })
      } else if (cmd === 'slot-span-set') {
        return setSpan(param.idx, param.axis, param.delta);
      // span 팝업 토글 (param: { e, idx })
      } else if (cmd === 'slot-span-popup') {
        return toggleSpanPopup(param.e, param.idx);
      } else {
        console.warn('[handleSelectAction] unknown cmd:', cmd);
      }
    };

    // ===== 내장 사용 함수 (이벤트 핸들러 on* / handle*) =======================

    /* handleSearchList — 실 dp_widget_lib 조회 + 어댑터 */
    const handleSearchList = async () => {
      try {
        const res = await boApiSvc.dpWidgetLib.getPage({ pageNo: 1, pageSize: 10000 }, '전시위젯라이브러리', '조회');
        const rows = (res.data?.data?.pageList || []).map(x => {
          let cfg = {}; try { cfg = JSON.parse(x.widgetConfigJson || '{}'); } catch (e) { /* 파싱 실패 무시 */ }
          return { ...cfg, libId: x.widgetLibId, libCode: x.widgetCode, name: x.widgetNm,
                   widgetType: x.widgetTypeCd, desc: x.widgetLibDesc, tags: cfg.tags || '',
                   status: x.useYn === 'Y' ? '활성' : '비활성', thumbnailUrl: x.thumbnailUrl,
                   sortOrd: x.sortOrd || 0 };
        });
        widgetLibs.splice(0, widgetLibs.length, ...rows);
      } catch (err) { console.error('[handleSearchList]', err); }
    };

    // ★ onMounted — 진입 시 코드 로드 + 목록 초기 조회
    /* initPage — 화면 로드 시퀀스. 마운트 시 실행한다. */
    const initPage = async () => {
      handleSearchList();
      Object.assign(searchParamInit, searchParam);   // [초기화] 기준값 스냅샷
    };
    onMounted(initPage);

    const today   = coUtil.cofToYmd(new Date());
    const nowTime = new Date().toTimeString().slice(0, 5);

    const WIDGET_ICONS = {
      'image_banner':'🖼', 'product_slider':'🛒', 'product':'📦',
      'cond_product':'🔍', 'chart_bar':'📊',      'chart_line':'📈',
      'chart_pie':'🥧',   'text_banner':'📝',     'info_card':'ℹ️',
      'popup':'💬',        'file':'📎',            'file_list':'📁',
      'coupon':'🎟',       'html_editor':'📄',     'event_banner':'🎉',
      'cache_banner':'💰', 'widget_embed':'🧩',    'textarea':'📋',
      'markdown':'📑',     'barcode':'🔖',          'qrcode':'📱',
      'barcode_qrcode':'🔖','video_player':'▶️',   'countdown':'⏱',
      'payment_widget':'💳','approval_widget':'✅', 'map_widget':'🗺',
    };

    /* wIcon — w 아이콘 */
    const wIcon      = (v) => WIDGET_ICONS[v] || '▪';

    /* wTypeLabel — w 유형 라벨 */
    const wTypeLabel = (v) => cfDispWidgetTypes.value.find(t => t.codeValue === v)?.codeLabel || v;

    const searchParam = reactive({ previewDate: today, previewTime: nowTime, filterType: '', filterStatus: '활성', filterCondition: '', filterAuthReq: '', filterAuthGrade: '', searchType: '', searchValue: ''});
    /* searchParamInit — [초기화] 기준값 (initPage 끝에서 스냅샷) */
    const searchParamInit = {};

    /* 적용된 조회 조건 스냅샷 — 검색조건 입력 즉시 filter 금지, [조회] 시점에만 반영 (UI/UX 검색 방식 정책) */
    const applied = reactive({ type: '', status: '활성', searchType: '', searchValue: '' });

    /* onSearch — 조회 */
    const onSearch = () => {
      Object.assign(applied, {
        type:       searchParam.filterType,
        status:     searchParam.filterStatus,
        searchType: searchParam.searchType,
        searchValue: (searchParam.searchValue || '').trim().toLowerCase(),
      });
    };

    /* onReset — 초기화 */
    const onReset = () => {
      Object.assign(searchParam, searchParamInit);
      Object.assign(applied, { type: '', status: '활성', searchType: '', searchValue: '' });
    resetCurrent();   // 검색 초기화 시 우측 미리보기도 비움
    };

    const cfFilteredLibs = computed(() => {
      const searchVal = applied.searchValue;
      const types = applied.searchType || 'widgetNm,tag,widgetLibDesc';
      return (Array.isArray(widgetLibs) ? widgetLibs : []).filter(lib => {
        if (applied.type   && lib.widgetType !== applied.type) { return false; }
        if (applied.status && lib.status     !== applied.status) { return false; }
        if (searchVal) {
          const hits = [];
          if (types.includes('widgetNm')) { hits.push((lib.name || '').toLowerCase().includes(searchVal)); }
          if (types.includes('tag')) { hits.push((lib.tags || '').toLowerCase().includes(searchVal)); }
          if (types.includes('widgetLibDesc')) { hits.push((lib.desc || '').toLowerCase().includes(searchVal)); }
          if (!hits.some(Boolean)) { return false; }
        }
        return true;
      });
    });

    /* -- 트리 선택 -- */
        const onTreeSelect  = (lib) => { uiState.selectedLibId = lib.libId; };

    /* -- 위젯유형 → 카테고리 분류 맵 -- */
    const WIDGET_TYPE_CATEGORY = {
      'image_banner':     'Common > Banner',
      'popup':            'Common > Popup',
      'text_banner':      'Common > Text',
      'html_editor':      'Common > HTML',
      'textarea':         'Common > Textarea',
      'markdown':         'Common > Markdown',
      'info_card':        'Common > InfoCard',
      'file':             'Common > File',
      'file_list':        'Common > FileList',
      'barcode':          'Common > Code',
      'qrcode':           'Common > Code',
      'barcode_qrcode':   'Common > Code',
      'chart_bar':        'Common > Chart',
      'chart_line':       'Common > Chart',
      'chart_pie':        'Common > Chart',
      'video_player':     'Common > Media',
      'payment_widget':   'Common > Widget',
      'approval_widget':  'Common > Widget',
      'widget_embed':     'Common > Widget',
      'map_widget':       'Common > Map',
      'product_slider':   'Product > Slider',
      'product':          'Product > Grid',
      'cond_product':     'Product > CondGrid',
      'coupon':           'Promotion > Coupon',
      'cache_banner':     'Promotion > Cache',
      'countdown':        'Promotion > Countdown',
      'event_banner':     'Promotion > Event',
    };

    /* -- 트리 상태 (위젯유형 카테고리 기반) -- */
    const cfTree = computed(() => {
      const map = {};
      window.safeArrayUtils.safeForEach(cfFilteredLibs.value, lib => {
        const catPath = WIDGET_TYPE_CATEGORY[lib.widgetType] || ('기타 > ' + (lib.widgetType || '미분류'));
        const parts = catPath.split('>').map(s => s.trim());
        const top = parts[0] || '기타';
        const sub = parts[1] || '기타';
        if (!map[top]) { map[top] = {}; }
        if (!map[top][sub]) { map[top][sub] = []; }
        map[top][sub].push(lib);
      });
      return Object.keys(map).sort().map(top => ({
        label: top,
        children: Object.keys(map[top]).sort().map(sub => ({
          label: sub,
          libs: map[top][sub],
        })),
      }));
    });
    const openNodes = reactive(new Set());

    /* toggleNode — 노드 토글 */
    const toggleNode = (key) => {
      if (openNodes.has(key)) { openNodes.delete(key); }
      else { openNodes.add(key); }
    };

    /* isOpen — 여부 확인 */
    const isOpen = (key) => openNodes.has(key);

    /* allChildrenOpen — 전체 자식 열기 */
    const allChildrenOpen = (node) =>
      window.safeArrayUtils.safeEvery(node.children, sub => openNodes.has(node.label + '_' + sub.label));

    /* toggleAllChildren — 전체 토글 */
    const toggleAllChildren = (e, node) => {
      e.stopPropagation();
      const open = !allChildrenOpen(node);
      window.safeArrayUtils.safeForEach(node.children, (sub) => {
        const key = node.label + '_' + sub.label;
        if (open) { openNodes.add(key); }
        else { openNodes.delete(key); }
      });
      if (open) { openNodes.add(node.label); }
    };
    watchEffect(() => {
      if (!openNodes.has('__root__')) { openNodes.add('__root__'); }
      const treeArr = Array.isArray(cfTree.value) ? cfTree.value : [];
      /* 데이터 로드 후 최초 1회: 모든 최상위 노드 자동 펼침 */
      if (treeArr.length && openNodes.size === 1) {
        treeArr.forEach(n => { if (n && n.label) { openNodes.add(n.label); } });
      }
    });

    /* expandAll — 펼치기 전체 */
    const expandAll = () => { window.safeArrayUtils.safeForEach(cfTree.value, n => openNodes.add(n.label)); openNodes.add('__root__'); };

    /* collapseAll — 접기 전체 */
    const collapseAll = () => { openNodes.clear(); openNodes.add('__root__'); };

    /* onItemDragStart — 이벤트 */
    const onItemDragStart = (e, lib) => {
      window._dragWidgetLib  = lib;
      window._dragWidgetLibs = null;
      e.dataTransfer.effectAllowed = 'copy';
      e.dataTransfer.setData('text/plain', lib.libId);
    };

    /* onItemDragEnd — 이벤트 */
    const onItemDragEnd = () => { window._dragWidgetLib = null; };

    /* dedupeLibs — dedupeLibs */
    const dedupeLibs = (arr) => {
      const seen = new Set();
      return window.safeArrayUtils.safeFilter(arr, lib => { if (seen.has(lib.libId)) return false; seen.add(lib.libId); return true; });
    };

    /* onNodeDragStart — 이벤트 */
    const onNodeDragStart = (e, allLibs) => {
      const libs = dedupeLibs(allLibs);
      window._dragWidgetLib  = null;
      window._dragWidgetLibs = libs;
      e.dataTransfer.effectAllowed = 'copy';
      e.dataTransfer.setData('text/plain', 'node:' + libs.length);
    };

    /* onNodeDragEnd — 이벤트 */
    const onNodeDragEnd = () => { window._dragWidgetLibs = null; };

    /* -- 그리드 탭 -- */
        const GRID_TABS   = [
      { id:'grid1',     label:'grid1',     cols:1 },
      { id:'grid2',     label:'grid2',     cols:2 },
      { id:'grid3',     label:'grid3',     cols:3 },
      { id:'grid4',     label:'grid4',     cols:4 },
      { id:'dashboard', label:'dashboard', cols:null },
    ];
    const GRID_COLS = { grid1:1, grid2:2, grid3:3, grid4:4 };

    /* -- 반응형 뷰포트 (grid1~4 전용) -- */
        const VIEWPORT = {
      desktop: { label:'🖥 PC',     width: null  },
      tablet:  { label:'📟 태블릿', width:'768px' },
      mobile:  { label:'📱 모바일', width:'375px' },
    };

    /* 실제컨텐츠 토글 */
    const uiState = reactive({ dashDragOver: false, showRealContent: false, selectedLibId: null, previewGrid: 'grid1', viewportMode: 'desktop', dragOverIdx: -1, spanPopupIdx: -1});
    const tab = Vue.toRef(uiState, 'tab');

    /* auto-fill 반응형: 뷰포트 width 제약 + 브라우저 창 리사이즈 모두 반응 */
    const cfAutoGridColumns = computed(() => {
      const map = {
        grid1: 'repeat(1,1fr)',
        grid2: 'repeat(auto-fill,minmax(max(calc(50% - 5px),260px),1fr))',
        grid3: 'repeat(auto-fill,minmax(max(calc(33.333% - 6px),190px),1fr))',
        grid4: 'repeat(auto-fill,minmax(max(calc(25% - 6px),220px),1fr))',
      };
      return map[uiState.previewGrid] || 'repeat(1,1fr)';
    });

    /* makeInit — 생성 */
    const makeInit = (cols) => Array(cols * 2).fill(null);
    const tabSlots = reactive({
      grid1: makeInit(1),
      grid2: makeInit(2),
      grid3: makeInit(3),
      grid4: makeInit(4),
    });
    const cfCurrentSlots = computed(() => tabSlots[uiState.previewGrid] || []);

    /* autoExpand — 자동 펼치기 */
    const autoExpand = (tabId) => {
      const cols = GRID_COLS[tabId];
      if (!cols) { return; }
      const arr = tabSlots[tabId];
      const lastRowStart = arr.length - cols;
      if (arr.slice(lastRowStart).some(Boolean)) {
        for (let i = 0; i < cols; i++) { arr.push(null); }
      }
    };

    /* -- 드래그·드롭 (그리드) -- */
    const onDragOver  = (e, idx) => {
      e.preventDefault();
      if (e.dataTransfer) { e.dataTransfer.dropEffect = 'copy'; }
      if (uiState.dragOverIdx !== idx) { uiState.dragOverIdx = idx; }
    };

    /* onDragLeave — 슬롯 밖 이탈 시에만 해제 (깜빡임 방지) */
    const onDragLeave = (e, idx) => {
      const to = e && e.relatedTarget;
      if (to && e.currentTarget && e.currentTarget.contains(to)) { return; }
      if (uiState.dragOverIdx === idx) { uiState.dragOverIdx = -1; }
    };

    /* onDrop — 이벤트 */
    const onDrop = (e, idx) => {
      e.preventDefault(); uiState.dragOverIdx = -1;

      /* -- 노드 일괄 배치 -- */
      const nodeLibs = window._dragWidgetLibs;
      if (nodeLibs) {
        window._dragWidgetLibs = null;
        if (nodeLibs.length > 40) {
          showToast(`노드 하위 위젯이 ${nodeLibs.length}개로 40개를 초과합니다. 배치할 수 없습니다.`, 'error');
          return;
        }
        const tabId = uiState.previewGrid;
        const arr   = tabSlots[tabId];
        const cols  = GRID_COLS[tabId] || 1;
        let placed = 0, i = idx;
        while (placed < nodeLibs.length) {
          if (i >= arr.length) {
            for (let c = 0; c < cols; c++) { arr.push(null); }
          }
          if (!arr[i]) { arr.splice(i, 1, { ...nodeLibs[placed], colSpan: 1, rowSpan: 1 }); placed++; }
          i++;
        }
        autoExpand(tabId);
        return;
      }

      /* -- 단일 위젯 배치 -- */
      const lib = window._dragWidgetLib;
      if (!lib) { return; }
      const tabId = uiState.previewGrid;
      tabSlots[tabId].splice(idx, 1, { ...lib, colSpan: 1, rowSpan: 1 });
      autoExpand(tabId);
    };

    /* removeSlot — 제거 */
    const removeSlot = (idx) => { tabSlots[uiState.previewGrid].splice(idx, 1, null); };

    /* setSpan — 설정 */
    const setSpan = (idx, axis, delta) => {
      const slot = tabSlots[uiState.previewGrid][idx];
      if (!slot) { return; }
      const maxCol = GRID_COLS[uiState.previewGrid] || 1;
      if (axis === 'col') { slot.colSpan = Math.max(1, Math.min(maxCol, (slot.colSpan || 1) + delta)); }
      if (axis === 'row') { slot.rowSpan = Math.max(1, Math.min(4,      (slot.rowSpan || 1) + delta)); }
    };

    /* -- span 팝업 -- */
        const toggleSpanPopup = (e, idx) => {
      e.stopPropagation();
      uiState.spanPopupIdx = uiState.spanPopupIdx === idx ? -1 : idx;
    };

    /* closeSpanPopup — 닫기 */
    const closeSpanPopup = () => { uiState.spanPopupIdx = -1; };

    /* -- 대시보드: 자유 배치 + 크기 조절 -- */
    const dashCanvas = ref(null);
    const dashItems  = reactive([]); // { id, lib, x, y, w, h }

    /* onDashDragOver — 이벤트 */
    const onDashDragOver = (e) => { e.preventDefault(); uiState.dashDragOver = true; };

    /* onDashDragLeave — 이벤트 */
    const onDashDragLeave = () => { uiState.dashDragOver = false; };

    /* onDashDrop — 이벤트 */
    const onDashDrop = (e) => {
      e.preventDefault(); uiState.dashDragOver = false;
      if (!dashCanvas.value) { return; }
      const rect = dashCanvas.value.getBoundingClientRect();

      /* -- 노드 일괄 배치 -- */
      const nodeLibs = window._dragWidgetLibs;
      if (nodeLibs) {
        window._dragWidgetLibs = null;
        if (nodeLibs.length > 40) {
          showToast(`노드 하위 위젯이 ${nodeLibs.length}개로 40개를 초과합니다. 배치할 수 없습니다.`, 'error');
          return;
        }
        const startX = Math.max(0, e.clientX - rect.left - 120);
        const startY = Math.max(0, e.clientY - rect.top  - 20);
        const COLS = 3, W = 260, H = 200, GAP = 10;
        window.safeArrayUtils.safeForEach(nodeLibs, (lib, i) => {
          const col = i % COLS, row = Math.floor(i / COLS);
          dashItems.push({ id: Date.now() + i, lib: { ...lib },
            x: startX + col * (W + GAP), y: startY + row * (H + GAP), w: W, h: H });
        });
        return;
      }

      /* -- 단일 위젯 배치 -- */
      const lib = window._dragWidgetLib;
      if (!lib) { return; }
      const x = Math.max(0, e.clientX - rect.left - 110);
      const y = Math.max(0, e.clientY - rect.top  - 20);
      dashItems.push({ id: Date.now(), lib: { ...lib }, x, y, w: 240, h: 180 });
    };

    /* removeDashItem — 제거 */
    const removeDashItem = (id) => {
      const i = dashItems.findIndex(d => d.id === id);
      if (i >= 0) { dashItems.splice(i, 1); }
    };

    /* startItemMove — 시작 항목 이동 */
    const startItemMove = (e, item) => {
      e.preventDefault();
      const ox = e.clientX - item.x;
      const oy = e.clientY - item.y;

      /* onMove — 이벤트 */
      const onMove = (me) => {
        item.x = Math.max(0, me.clientX - ox);
        item.y = Math.max(0, me.clientY - oy);
      };

      /* onUp — 이벤트 */
      const onUp = () => {
        document.removeEventListener('mousemove', onMove);
        document.removeEventListener('mouseup', onUp);
      };
      document.addEventListener('mousemove', onMove);
      document.addEventListener('mouseup', onUp);
    };

    /* startItemResize — 시작 항목 Resize */
    const startItemResize = (e, item) => {
      e.preventDefault(); e.stopPropagation();
      const sx = e.clientX, sy = e.clientY;
      const sw = item.w,    sh = item.h;

      /* onMove — 이벤트 */
      const onMove = (me) => {
        item.w = Math.max(160, sw + (me.clientX - sx));
        item.h = Math.max(120, sh + (me.clientY - sy));
      };

      /* onUp — 이벤트 */
      const onUp = () => {
        document.removeEventListener('mousemove', onMove);
        document.removeEventListener('mouseup', onUp);
      };
      document.addEventListener('mousemove', onMove);
      document.addEventListener('mouseup', onUp);
    };

    /* -- 배치 수 / 초기화 -- */
    const cfPlacedCount = computed(() =>
      uiState.previewGrid === 'dashboard'
        ? dashItems.length
        : (cfCurrentSlots.value || []).filter(Boolean).length
    );

    /* resetCurrent — 초기화 */
    const resetCurrent = () => {
      if (uiState.previewGrid === 'dashboard') {
        dashItems.splice(0);
      } else {
        const cols = GRID_COLS[uiState.previewGrid];
        const arr  = tabSlots[uiState.previewGrid];
        arr.splice(0, arr.length, ...makeInit(cols));
      }
    };

    // ===== return (템플릿 노출) ===============================================

    return {
      uiState, codes, searchParam, applied,                                          // 상태 / 데이터
      tabSlots, dashItems, dashCanvas,                                               // 상태 (그리드/대시보드)
      handleBtnAction, handleSelectAction,                                            // dispatch (모든 이벤트 / 액션 라우팅)
      cfSiteNm, cfFilteredLibs, cfTree, cfAutoGridColumns, cfCurrentSlots,           // computed
      cfPlacedCount, cfDispWidgetTypes,                                              // computed
      VIEWPORT, GRID_TABS, GRID_COLS, today,                                          // 상수
      wIcon, wTypeLabel,                                                              // 헬퍼
      isOpen, allChildrenOpen,                                                        // 헬퍼 (template 사용)
      onItemDragStart, onItemDragEnd, onNodeDragStart, onNodeDragEnd,                 // 드래그 이벤트 (직접 바인딩)
      onDragOver, onDragLeave, onDrop,                                                // 그리드 드래그 (직접 바인딩)
      onDashDragOver, onDashDragLeave, onDashDrop,                                    // 대시보드 드래그 (직접 바인딩)
      startItemMove, startItemResize,                                                 // 대시보드 마우스 이동/리사이즈 (직접 바인딩)
    };
  },
  template: /* html */`
<div>
  <!-- ===== ■. 페이지 타이틀 ================================================= -->
  <div class="page-title" style="display:flex;align-items:center;justify-content:space-between;">
    <div>전시위젯Lib 위젯미리보기 <span style="font-size:13px;font-weight:400;color:#888;">표시경로 트리 &amp; 드래그하여 배치</span></div>
    <span style="font-size:12px;background:#e8f0fe;color:#1565c0;border:1px solid #bbdefb;border-radius:10px;padding:3px 12px;font-weight:600;">
      🌐 {{ cfSiteNm }}
    </span>
  </div>
  <!-- ===== □. 페이지 타이틀 ================================================= -->
  <!-- ===== ■. 조회 조건 =================================================== -->
  <div class="card" style="padding:14px 18px;margin-bottom:12px;">
    <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
      <div style="display:flex;align-items:center;gap:5px;">
        <span style="font-size:12px;font-weight:600;color:#555;">📅 전시일시</span>
        <bo-date-time-picker v-model:date="searchParam.previewDate" v-model:time="searchParam.previewTime"
          :show-clear="false" date-width="136px" time-width="90px" />
      </div>
      <div style="width:1px;height:24px;background:#e0e0e0;"></div>
      <div style="display:flex;align-items:center;gap:5px;">
        <span style="font-size:12px;font-weight:600;color:#555;">상태</span>
        <select v-model="searchParam.filterStatus" class="form-control" style="width:76px;margin:0;font-size:12px;">
          <option value="">전체</option>
          <option v-for="o in codes.widget_status_opts" :key="o.value" :value="o.value">{{ o.label }}</option>
        </select>
      </div>
      <div style="display:flex;align-items:center;gap:5px;">
        <span style="font-size:12px;font-weight:600;color:#555;">노출조건</span>
        <select v-model="searchParam.filterCondition" class="form-control" style="width:105px;margin:0;font-size:12px;">
          <option value="">전체</option>
          <option v-for="c in codes.condition_opts" :key="c" :value="c">{{ c }}</option>
        </select>
      </div>
      <div style="display:flex;align-items:center;gap:5px;">
        <span style="font-size:12px;font-weight:600;color:#555;">인증필요</span>
        <select v-model="searchParam.filterAuthReq" class="form-control" style="width:70px;margin:0;font-size:12px;">
          <option value="">전체</option>
          <option v-for="o in codes.need_yn_opts" :key="o.codeValue" :value="o.codeValue">{{ o.codeLabel }}</option>
        </select>
      </div>
      <!-- ===== ■.■.■. 영역 ================================================== -->
      <div style="display:flex;align-items:center;gap:5px;">
        <span style="font-size:12px;font-weight:600;color:#555;">등급제한</span>
        <select v-model="searchParam.filterAuthGrade" class="form-control" style="width:72px;margin:0;font-size:12px;">
          <option value="">전체</option>
          <option v-for="g in codes.auth_grade_opts" :key="g" :value="g">{{ g }}↑</option>
        </select>
      </div>
      <div style="width:1px;height:24px;background:#e0e0e0;"></div>
      <div style="display:flex;align-items:center;gap:5px;">
        <span style="font-size:12px;font-weight:600;color:#555;">위젯유형</span>
        <select v-model="searchParam.filterType" class="form-control" style="width:114px;margin:0;font-size:12px;">
          <option v-for="t in cfDispWidgetTypes" :key="t?.value" :value="t.codeValue">{{ t.codeLabel }}</option>
        </select>
      </div>
      <bo-multi-check-select
        v-model="searchParam.searchType"
        :options="[
        { value: 'widgetNm',   label: '이름' },
        { value: 'tag',  label: '태그' },
        { value: 'widgetLibDesc', label: '설명' },
        ]"
        placeholder="검색대상 전체"
        all-label="전체 선택"
        min-width="130px" />
      <input v-model="searchParam.searchValue" class="form-control" placeholder="검색어 입력" style="margin:0;width:130px;font-size:12px;" @keyup.enter="handleBtnAction('searchParam-list')" />
      <span style="font-size:12px;color:#888;">총 <b>{{ cfFilteredLibs.length }}</b>건</span>
      <button @click="handleBtnAction('searchParam-reset')" class="btn btn_reset"
        style="padding:0;width:26px;height:26px;font-size:13px;display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;" title="초기화">🔄</button>
      <button @click="handleBtnAction('searchParam-list')" class="btn btn_search">검색</button>
    </div>
  </div>
  <!-- ===== □. 조회 조건 =================================================== -->
  <!-- ===== ■. 2단 레이아웃 ================================================= -->
  <div style="display:flex;gap:12px;height:calc(100vh - 240px);min-height:500px;align-items:stretch;">
    <!-- ===== ■.■. 왼쪽: 트리 (카드) =========================================== -->
    <div class="card" style="width:340px;flex-shrink:0;display:flex;flex-direction:column;padding:0;overflow:hidden;">
      <div style="padding:7px 12px;border-bottom:1px solid #f0f0f0;font-size:12px;font-weight:700;color:#555;background:#fafafa;flex-shrink:0;display:flex;align-items:center;justify-content:space-between;">
        <span class="list-title">표시경로
          <span style="font-size:10px;color:#aaa;font-family:monospace;font-weight:400;margin-left:4px;">#ec_disp_widget_lib</span>
        </span>
        <span style="font-size:10px;color:#aaa;font-weight:400;">⠿ 드래그하여 배치</span>
      </div>
      <!-- ===== ■.■.■. 전체펼치기 / 전체닫기 ======================================== -->
      <div style="padding:6px 12px;display:flex;gap:4px;border-bottom:1px solid #f0f0f0;background:#fff;flex-shrink:0;">
        <button @click="handleBtnAction('pathTree-expand-all')"
          style="flex:1;padding:4px 6px;font-size:10px;border:1px solid #d0d7de;border-radius:4px;background:#fff;color:#555;">
          ▼ 전체펼치기
        </button>
        <button @click="handleBtnAction('pathTree-collapse-all')"
          style="flex:1;padding:4px 6px;font-size:10px;border:1px solid #d0d7de;border-radius:4px;background:#fff;color:#555;">
          ▶ 전체닫기
        </button>
      </div>
      <div style="flex:1;overflow-y:auto;padding:4px 0;border-bottom:1px solid #ececec;">
        <!-- ===== ■.■.■.■. 루트 노드 ============================================= -->
        <div @click="handleSelectAction('pathTree-toggle', '__root__')"
          style="display:flex;align-items:center;gap:6px;padding:7px 12px;font-size:12px;font-weight:700;color:#222;user-select:none;background:#f8f9fb;border-radius:4px;margin:1px 4px;"
          :style="isOpen('__root__') ? 'background:#f0f4ff;' : ''">
          <span style="font-size:10px;color:#9ca3af;transition:transform .2s;"
            :style="isOpen('__root__') ? 'transform:rotate(90deg);' : ''">
            ▶
          </span>
          <span>📂 전체</span>
          <span style="margin-left:auto;font-size:10px;background:#fff;color:#555;border:1px solid #ddd;border-radius:8px;padding:0 6px;">
            {{ cfTree.reduce((acc,n)=>acc+n.children.reduce((a,c)=>a+c.libs.length,0),0) }}
          </span>
        </div>
        <div v-if="isOpen('__root__')" style="padding-left:8px;">
          <div v-for="node in cfTree" :key="node?.label">
            <div @click="handleSelectAction('pathTree-toggle', node.label)"
              draggable="true"
              @dragstart="onNodeDragStart($event, node.children.flatMap(c => c.libs))"
              @dragend="onNodeDragEnd"
              style="display:flex;align-items:center;gap:6px;padding:6px 12px;cursor:grab;font-size:12px;font-weight:700;color:#374151;user-select:none;border-radius:4px;margin:1px 4px;"
              :style="isOpen(node.label) ? 'background:#f0f4ff;' : ''">
              <span style="font-size:10px;color:#9ca3af;transition:transform .2s;"
                :style="isOpen(node.label) ? 'transform:rotate(90deg);' : ''">
                ▶
              </span>
              <span>{{ node.label }}</span>
              <span style="margin-left:auto;font-size:10px;background:#e5e7eb;color:#6b7280;border-radius:8px;padding:0 6px;">
                {{ node.children.reduce((acc,c)=>acc+c.libs.length,0) }}
              </span>
              <span v-if="isOpen(node.label)" @click="handleSelectAction('pathTree-toggle-children', { e: $event, node })"
                :title="allChildrenOpen(node) ? '하위 모두 닫기' : '하위 모두 열기'"
                style="font-size:10px;color:#9ca3af;padding:1px 4px;border-radius:3px;flex-shrink:0;"
                :style="allChildrenOpen(node) ? 'color:#1d4ed8;' : ''"
                >
                {{ allChildrenOpen(node) ? '⊟' : '⊞' }}
              </span>
            </div>
            <!-- ===== ■.■.■.■.■.■. 조건부 영역 ======================================== -->
            <template v-if="isOpen(node.label)">
              <div v-for="sub in node.children" :key="node.label+'_'+sub.label">
                <div @click="handleSelectAction('pathTree-toggle', node.label+'_'+sub.label)"
                  draggable="true"
                  @dragstart="onNodeDragStart($event, sub.libs)"
                  @dragend="onNodeDragEnd"
                  style="display:flex;align-items:center;gap:6px;padding:5px 12px 5px 26px;cursor:grab;font-size:11px;font-weight:600;color:#4b5563;border-radius:4px;margin:1px 4px;"
                  :style="isOpen(node.label+'_'+sub.label) ? 'background:#f9fafb;' : ''">
                  <span style="font-size:9px;color:#9ca3af;transition:transform .2s;"
                    :style="isOpen(node.label+'_'+sub.label) ? 'transform:rotate(90deg);' : ''">
                    ▶
                  </span>
                  <span>{{ sub.label }}</span>
                  <span style="margin-left:auto;font-size:10px;background:#e5e7eb;color:#6b7280;border-radius:8px;padding:0 5px;">
                    {{ sub.libs.length }}
                  </span>
                </div>
                <template v-if="isOpen(node.label+'_'+sub.label)">
                  <div v-for="lib in sub.libs" :key="lib?.libId"
                    draggable="true"
                    @dragstart="onItemDragStart($event, lib)"
                    @dragend="onItemDragEnd"
                    @click="handleSelectAction('pathTree-select', lib)"
                    style="display:flex;align-items:center;gap:7px;padding:5px 10px 5px 42px;cursor:grab;font-size:11px;border-radius:4px;margin:1px 4px;transition:background .15s;"
                    :style="uiState.selectedLibId===lib.libId ? 'background:#dbeafe;color:#1d4ed8;font-weight:700;' : 'color:#374151;'">
                    <span style="font-size:9px;color:#c4c4c4;flex-shrink:0;">⠿</span>
                    <span style="font-size:13px;flex-shrink:0;">{{ wIcon(lib.widgetType) }}</span>
                    <span style="font-size:9px;background:#f0f4ff;color:#1d4ed8;border:1px solid #dbeafe;border-radius:3px;padding:0 4px;white-space:nowrap;flex-shrink:0;">
                      {{ lib.widgetType ? lib.widgetType.replace('_',' ') : '-' }}
                    </span>
                    <span style="font-size:9px;background:#f3e5f5;color:#6a1b9a;border-radius:4px;padding:1px 6px;font-weight:600;flex-shrink:0;white-space:nowrap;">
                      (위젯)
                    </span>
                    <span style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">{{ lib.name }}</span>
                    <span style="font-size:9px;color:#9ca3af;flex-shrink:0;">#{{ String(lib.libId).padStart(4,'0') }}</span>
                  </div>
                </template>
              </div>
            </template>
          </div>
        </div>
        <!-- ===== /root children ============================================= -->
        <div v-if="!cfTree.length" style="padding:24px;text-align:center;color:#ccc;font-size:12px;">위젯이 없습니다.</div>
      </div>
    </div>
    <!-- ===== □.□. 왼쪽: 트리 (카드) =========================================== -->
    <!-- ===== ■.■. 오른쪽 (카드) ============================================== -->
    <div class="card" style="flex:1;display:flex;flex-direction:column;overflow:hidden;background:#f0f2f5;min-width:0;padding:0;">
      <!-- ===== ■.■.■. 영역 제목 ================================================ -->
      <div style="padding:7px 12px;border-bottom:1px solid #f0f0f0;background:#fafafa;flex-shrink:0;">
        <span class="list-title">미리보기</span>
      </div>
      <!-- ===== ■.■.■. 탭바 + 뷰포트 토글 + 배치수 =================================== -->
      <div style="display:flex;align-items:stretch;background:#f8f9fa;border-bottom:1px solid #e8e8e8;flex-shrink:0;padding:0 12px;">
        <div style="display:flex;gap:2px;align-items:flex-end;padding-top:8px;flex:1;">
          <button v-for="tab in GRID_TABS" :key="tab?.id" @click="handleSelectAction('preview-tab', tab.id)"
            style="padding:5px 14px;border:1px solid transparent;border-bottom:none;border-radius:6px 6px 0 0;font-size:12px;font-weight:600;transition:all .15s;margin-bottom:-1px;"
            :style="uiState.previewGrid===tab.id
            ? 'background:#fff;border-color:#e8e8e8;border-bottom-color:#fff;color:#1d4ed8;z-index:1;'
            : 'background:transparent;color:#9ca3af;'">
            {{ tab.label }}
          </button>
        </div>
        <!-- ===== ■.■.■.■. 실제컨텐츠 + 뷰포트 토글 (dashboard 제외) ===================== -->
        <div v-if="uiState.previewGrid!=='dashboard'" style="display:flex;align-items:center;gap:4px;padding:6px 0 6px 12px;border-left:1px solid #e5e7eb;margin-left:8px;">
          <button @click="handleBtnAction('preview-toggle-real')"
            style="font-size:11px;padding:3px 9px;border-radius:6px;border:1px solid #d1d5db;white-space:nowrap;transition:all .15s;margin-right:4px;"
            :style="uiState.showRealContent?'background:#059669;color:#fff;border-color:#059669;':'background:#fff;color:#6b7280;'">
            {{ uiState.showRealContent ? '✅ 실제컨텐츠' : '👁 실제컨텐츠' }}
          </button>
          <div style="width:1px;height:18px;background:#e5e7eb;margin-right:2px;"></div>
          <button v-for="(vp, key) in VIEWPORT" :key="key" @click="handleSelectAction('preview-viewport', key)"
            style="font-size:11px;padding:3px 8px;border-radius:6px;border:1px solid #d1d5db;white-space:nowrap;transition:all .15s;"
            :style="uiState.viewportMode===key
            ? 'background:#1d4ed8;color:#fff;border-color:#1d4ed8;'
            : 'background:#fff;color:#6b7280;'">
            {{ vp.label }}
          </button>
        </div>
        <div style="display:flex;align-items:center;gap:8px;padding:0 0 0 12px;">
          <span style="font-size:12px;color:#555;font-weight:600;">{{ cfPlacedCount }}개</span>
          <button @click="handleBtnAction('preview-reset')"
            style="font-size:11px;padding:3px 10px;border:1px solid #d0d0d0;border-radius:6px;background:#fff;color:#666;white-space:nowrap;">
            초기화
          </button>
        </div>
      </div>
      <!-- ===== ■.■.■. 그리드 캔버스 (grid1~4) =================================== -->
      <div v-if="uiState.previewGrid!=='dashboard'" @click="handleBtnAction('spanPopup-close')" style="flex:1;overflow-y:auto;overflow-x:auto;padding:16px;">
        <!-- ===== ■.■.■.■. 뷰포트 래퍼 ============================================ -->
        <div :style="{
          width: VIEWPORT[uiState.viewportMode].width || '100%',
          maxWidth: VIEWPORT[uiState.viewportMode].width || '100%',
          margin: '0 auto',
          transition: 'width .3s',
          }">
          <!-- ===== ■.■.■.■.■. 디바이스 프레임 표시 ===================================== -->
          <div v-if="uiState.viewportMode!=='desktop'"
            style="text-align:center;margin-bottom:8px;font-size:11px;color:#9ca3af;font-weight:600;">
            {{ uiState.viewportMode==='mobile' ? '📱 375px' : '📟 768px' }}
          </div>
          <div :style="{
            border: uiState.viewportMode!=='desktop' ? '2px solid #d1d5db' : 'none',
            borderRadius: uiState.viewportMode!=='desktop' ? '12px' : '0',
            padding: uiState.viewportMode!=='desktop' ? '12px' : '0',
            background: '#fff',
            boxShadow: uiState.viewportMode!=='desktop' ? '0 4px 20px rgba(0,0,0,.12)' : 'none',
            }">
            <div :style="{
              display: 'grid',
              gridTemplateColumns: cfAutoGridColumns,
              gap: '10px',
              }">
              <template v-for="(slot, idx) in cfCurrentSlots" :key="idx">
                <div v-if="!uiState.showRealContent || slot"
                  @dragover="onDragOver($event, idx)"
                  @dragleave="onDragLeave($event, idx)"
                  @drop="onDrop($event, idx)"
                  style="border-radius:8px;transition:all .15s;position:relative;"
                  :style="[
                  uiState.dragOverIdx===idx
                  ? 'border:2px dashed #1d4ed8;background:#eff6ff;min-height:110px;'
                  : slot
                  ? (uiState.showRealContent ? 'border:none;background:transparent;min-height:0;' : 'border:1px solid #e5e7eb;background:#fff;box-shadow:0 1px 4px rgba(0,0,0,.07);min-height:110px;')
                  : 'border:2px dashed #d1d5db;background:#f9fafb;min-height:60px;',
                  (slot?.colSpan||1) > 1 ? { gridColumn: 'span ' + slot.colSpan } : {},
                  (slot?.rowSpan||1) > 1 ? { gridRow:    'span ' + slot.rowSpan } : {},
                  ]">
                  <!-- ===== ■.■.■.■.■.■.■.■.■. 비어있음 ==================================== -->
                  <div v-if="!slot ? (uiState.dragOverIdx!==idx) : false"
                    style="height:100%;min-height:60px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:5px;color:#d1d5db;padding:10px;">
                    <span style="font-size:20px;">+</span>
                    <span style="font-size:11px;">드래그하여 추가</span>
                  </div>
                  <!-- ===== ■.■.■.■.■.■.■.■.■. 드롭 오버 =================================== -->
                  <div v-else-if="!slot ? (uiState.dragOverIdx===idx) : false"
                    style="min-height:60px;display:flex;align-items:center;justify-content:center;color:#1d4ed8;font-size:12px;font-weight:700;padding:10px;">
                    ▼ 여기에 추가
                  </div>
                  <!-- ===== ■.■.■.■.■.■.■.■.■. 배치됨 ===================================== -->
                  <template v-else-if="slot">
                    <!-- ===== ■.■.■.■.■.■.■.■.■.■. 슬롯 헤더 (실제컨텐츠 OFF) ===================== -->
                    <div v-if="!uiState.showRealContent" style="display:flex;align-items:center;gap:5px;padding:6px 10px 5px;border-bottom:1px solid #f0f0f0;background:#fafafa;border-radius:8px 8px 0 0;">
                      <span style="font-size:12px;">{{ wIcon(slot.widgetType) }}</span>
                      <span style="font-size:10px;background:#f0f4ff;color:#1d4ed8;border:1px solid #dbeafe;border-radius:4px;padding:0 5px;white-space:nowrap;">
                        {{ wTypeLabel(slot.widgetType) }}
                      </span>
                      <span style="font-size:11px;font-weight:600;color:#333;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">
                        {{ slot.name }}
                      </span>
                      <!-- ===== ■.■.■.■.■.■.■.■.■.■.■. span 설정 아이콘 ========================= -->
                      <button @click="handleSelectAction('slot-span-popup', { e: $event, idx })"
                        :title="'열 ' + (slot.colSpan||1) + ' × 행 ' + (slot.rowSpan||1)"
                        style="flex-shrink:0;width:22px;height:22px;border-radius:4px;border:1px solid #e5e7eb;font-size:13px;display:flex;align-items:center;justify-content:center;padding:0;transition:all .15s;"
                        :style="uiState.spanPopupIdx===idx ? 'background:#1d4ed8;color:#fff;border-color:#1d4ed8;' : 'background:#f9fafb;color:#6b7280;'">
                        ⚙
                      </button>
                      <button @click="handleBtnAction('slot-remove', idx)"
                        style="flex-shrink:0;width:17px;height:17px;border-radius:50%;border:none;background:#e5e7eb;color:#6b7280;font-size:10px;display:flex;align-items:center;justify-content:center;padding:0;">
                        ✕
                      </button>
                    </div>
                    <!-- ===== ■.■.■.■.■.■.■.■.■.■. span 설정 레이어 팝업 ======================== -->
                    <div v-if="uiState.spanPopupIdx===idx" @click.stop
                      style="position:absolute;top:36px;right:6px;z-index:20;background:#fff;border:1px solid #e5e7eb;border-radius:8px;box-shadow:0 4px 16px rgba(0,0,0,.12);padding:12px 14px;min-width:170px;">
                      <!-- ===== ■.■.■.■.■.■.■.■.■.■.■. 닫기 ================================== -->
                      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;">
                        <span style="font-size:11px;font-weight:700;color:#374151;">그리드 스팬 설정</span>
                        <button @click="handleBtnAction('spanPopup-close')" style="border:none;background:none;font-size:13px;color:#9ca3af;padding:0;line-height:1;">
                          ✕
                        </button>
                      </div>
                      <!-- ===== ■.■.■.■.■.■.■.■.■.■.■. 열(colspan) ========================== -->
                      <div style="display:flex;align-items:center;gap:6px;margin-bottom:8px;">
                        <span style="font-size:11px;color:#6b7280;width:36px;">열 span</span>
                        <button @click="handleSelectAction('slot-span-set', { idx, axis:'col', delta:-1 })" :disabled="(slot.colSpan||1)<=1"
                          style="width:24px;height:24px;border:1px solid #e5e7eb;border-radius:4px;background:#f9fafb;font-size:13px;display:flex;align-items:center;justify-content:center;padding:0;"
                          :style="(slot.colSpan||1)<=1?'opacity:.3;cursor:default;':''">
                          −
                        </button>
                        <span style="min-width:28px;text-align:center;font-size:14px;font-weight:700;color:#1d4ed8;">
                          {{ slot.colSpan||1 }}
                        </span>
                        <button @click="handleSelectAction('slot-span-set', { idx, axis:'col', delta:+1 })" :disabled="(slot.colSpan||1)>=(GRID_COLS[uiState.previewGrid]||1)"
                          style="width:24px;height:24px;border:1px solid #e5e7eb;border-radius:4px;background:#f9fafb;font-size:13px;display:flex;align-items:center;justify-content:center;padding:0;"
                          :style="(slot.colSpan||1)>=(GRID_COLS[uiState.previewGrid]||1)?'opacity:.3;cursor:default;':''">
                          +
                        </button>
                        <span style="font-size:10px;color:#9ca3af;">/ {{ GRID_COLS[uiState.previewGrid]||1 }}</span>
                      </div>
                      <!-- ===== ■.■.■.■.■.■.■.■.■.■.■. 행(rowspan) ========================== -->
                      <div style="display:flex;align-items:center;gap:6px;">
                        <span style="font-size:11px;color:#6b7280;width:36px;">행 span</span>
                        <button @click="handleSelectAction('slot-span-set', { idx, axis:'row', delta:-1 })" :disabled="(slot.rowSpan||1)<=1"
                          style="width:24px;height:24px;border:1px solid #e5e7eb;border-radius:4px;background:#f9fafb;font-size:13px;display:flex;align-items:center;justify-content:center;padding:0;"
                          :style="(slot.rowSpan||1)<=1?'opacity:.3;cursor:default;':''">
                          −
                        </button>
                        <span style="min-width:28px;text-align:center;font-size:14px;font-weight:700;color:#1d4ed8;">
                          {{ slot.rowSpan||1 }}
                        </span>
                        <button @click="handleSelectAction('slot-span-set', { idx, axis:'row', delta:+1 })" :disabled="(slot.rowSpan||1)>=4"
                          style="width:24px;height:24px;border:1px solid #e5e7eb;border-radius:4px;background:#f9fafb;font-size:13px;display:flex;align-items:center;justify-content:center;padding:0;"
                          :style="(slot.rowSpan||1)>=4?'opacity:.3;cursor:default;':''">
                          +
                        </button>
                        <span style="font-size:10px;color:#9ca3af;">/ 4</span>
                      </div>
                    </div>
                    <!-- ===== ■.■.■.■.■.■.■.■.■.■. 실제컨텐츠 ON: ×버튼만 ======================== -->
                    <div v-else style="position:relative;">
                      <button @click="handleBtnAction('slot-remove', idx)"
                        style="position:absolute;top:4px;right:4px;z-index:5;width:18px;height:18px;border-radius:50%;border:none;background:rgba(0,0,0,.3);color:#fff;font-size:11px;line-height:1;display:flex;align-items:center;justify-content:center;padding:0;">
                        ✕
                      </button>
                    </div>
                    <!-- ===== ■.■.■.■.■.■.■.■.■.■. 위젯미리보기 ================================ -->
                    <widget-preview :lib="slot" />
                  </template>
                </div>
                <!-- ===== /slot ====================================================== -->
              </template>
            </div>
            <!-- ===== /grid ====================================================== -->
          </div>
          <!-- ===== /device frame ============================================== -->
        </div>
        <!-- ===== /viewport wrapper ========================================== -->
      </div>
      <!-- ===== /grid canvas =============================================== -->
      <!-- ===== ■.■.■. 대시보드 캔버스 (자유 배치) ==================================== -->
      <div v-else style="flex:1;overflow:auto;padding:16px;">
        <div
          ref="dashCanvas"
          @dragover="onDashDragOver"
          @dragleave="onDashDragLeave"
          @drop="onDashDrop"
          style="position:relative;min-height:560px;min-width:600px;background:#fff;border-radius:8px;border:2px dashed #e5e7eb;transition:border-color .15s;"
          :style="uiState.dashDragOver ? 'border-color:#1d4ed8;background:#eff6ff;' : ''">
          <!-- ===== ■.■.■.■.■. 빈 상태 ============================================ -->
          <div v-if="!dashItems.length ? (!uiState.dashDragOver) : false"
            style="position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;color:#d1d5db;pointer-events:none;">
            <span style="font-size:48px;">🧩</span>
            <span style="font-size:13px;">왼쪽 트리에서 위젯을 드래그하여 배치하세요</span>
          </div>
          <div v-if="uiState.dashDragOver ? (!dashItems.length) : false"
            style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;color:#1d4ed8;font-size:14px;font-weight:700;pointer-events:none;">
            ▼ 여기에 배치
          </div>
          <!-- ===== ■.■.■.■.■. 배치된 아이템 ========================================= -->
          <div v-for="item in dashItems" :key="item?.id"
            :style="{
            position:'absolute',
            left: item.x+'px',
            top:  item.y+'px',
            width: item.w+'px',
            minHeight: item.h+'px',
            border:'1px solid #e5e7eb',
            borderRadius:'8px',
            background:'#fff',
            boxShadow:'0 2px 10px rgba(0,0,0,.1)',
            userSelect:'none',
            zIndex: 1,
            }">
            <!-- ===== ■.■.■.■.■.■. 이동 핸들 헤더 ====================================== -->
            <div
              @mousedown="startItemMove($event, item)"
              style="display:flex;align-items:center;gap:5px;padding:6px 10px;background:#f8f9fa;border-bottom:1px solid #f0f0f0;border-radius:8px 8px 0 0;cursor:move;">
              <span style="font-size:10px;color:#c4c4c4;letter-spacing:1px;">⠿⠿</span>
              <span style="font-size:12px;">{{ wIcon(item.lib.widgetType) }}</span>
              <span style="font-size:11px;background:#f0f4ff;color:#1d4ed8;border:1px solid #dbeafe;border-radius:4px;padding:0 5px;white-space:nowrap;flex-shrink:0;">
                {{ wTypeLabel(item.lib.widgetType) }}
              </span>
              <span style="font-size:11px;font-weight:600;color:#333;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;min-width:0;">
                {{ item.lib.name }}
              </span>
              <button @mousedown.stop @click="handleBtnAction('dashItem-remove', item.id)"
                style="flex-shrink:0;width:18px;height:18px;border-radius:50%;border:none;background:#e5e7eb;color:#6b7280;font-size:10px;display:flex;align-items:center;justify-content:center;padding:0;">
                ✕
              </button>
            </div>
            <!-- ===== ■.■.■.■.■.■. 위젯미리보기 ======================================== -->
            <div style="overflow:hidden;" :style="{maxHeight:(item.h-40)+'px'}">
              <widget-preview :lib="item.lib" />
            </div>
            <!-- ===== ■.■.■.■.■.■. 크기 조절 핸들 ====================================== -->
            <div
              @mousedown="startItemResize($event, item)"
              style="position:absolute;right:0;bottom:0;width:18px;height:18px;cursor:se-resize;border-radius:0 0 8px 0;overflow:hidden;">
              <div style="width:0;height:0;border-style:solid;border-width:0 0 18px 18px;border-color:transparent transparent #d1d5db transparent;position:absolute;right:0;bottom:0;"></div>
            </div>
            <!-- ===== ■.■.■.■.■.■. 크기 표시 ========================================= -->
            <div style="position:absolute;right:22px;bottom:3px;font-size:9px;color:#c4c4c4;pointer-events:none;user-select:none;">
              {{ Math.round(item.w) }}×{{ Math.round(item.h) }}
            </div>
          </div>
        </div>
        <!-- ===== /dashCanvas ================================================ -->
      </div>
      <!-- ===== /dashboard ================================================= -->
    </div>
    <!-- ===== /오른쪽 ======================================================= -->
  </div>
  <!-- ===== /2단 ======================================================== -->
</div>

    <!-- ===== □.□. 오른쪽 (카드) ============================================== -->
  <!-- ===== □. 2단 레이아웃 ================================================= -->`,
  components: {
    WidgetPreview: _WidgetPreview,
  },
};
