﻿/**
 * 개발도구 — 연동설정 대시보드
 *
 * 외부 서비스 연동 설정 현황을 한 눈에 확인하는 bo-grid 기반 대시보드.
 * 소셜로그인 / 결제 / 지도 / 메일·SMS / 푸시 / 챗봇 / 앱 메시지 등
 * BE 설정 여부 / FE 설정 여부 / 테스트 버튼 / 연동결과 / 테스트 결과 표시.
 * 행 클릭 시 상세정보(BE·FE 실제 키 값, 설명, 발급처 링크) 펼침.
 */
window.ZdInfDashboard = {
  name: 'ZdInfDashboard',
  props: {
    navigate:  { type: Function, required: true },                       // 페이지 이동
    showToast: { type: Function, default: () => {} },                    // 토스트 알림
  },
  setup(props) {

    /* ##### [01] 초기 변수 정의 #################################################### */

    const { reactive, ref, onMounted } = Vue;
    const showToast = props.showToast || window.boApp?.showToast || (() => {});

    const codes = reactive({});
    const loading = ref(false);

    const tab = ref('channel');
    const tabMode = ref('tab');
    const fnTabModeClass = (m) => m === 'tab' ? '' : 'cols-' + m.replace('col', '');
    const tabs = reactive([
      { id: 'channel', label: '연동 채널 목록', icon: '🔌' },
      { id: 'env',     label: '환경값정보',     icon: '⚙️' },
      { id: 'ref',     label: '외부연동구조',   icon: '📋' },
    ]);




    /* ##### [02] 그리드 컬럼 정의 ################################################### */

    /* ── 참고자료 그리드 (사용 안 함 — 트리 테이블로 대체) ── */
    const refGridColumns = [];

    /* ── 참고자료 행 ──
     * svc / app / level / kind / val / applied / note / propKey / color
     * propKey : 실제 적용 키명 (sy_prop 키 또는 yml 경로)
     * _where  : propKey 자동 추론 — sy_prop / yml / foEnvConsts / boEnvConsts / (없음)
     */
    const _mkR = (svc, app, level, kind, val, applied, note, propKey, color, configUrl) => {
      let _where = '';
      if (propKey) {
        /* 토스 테스트키·SDK URL은 fo/boEnvConsts.js 하드코딩 */
        if (propKey === '__foEnvConsts__')       _where = 'foEnvConsts';
        else if (propKey === '__boEnvConsts__')  _where = 'boEnvConsts';
        /* spring.mail.* 은 yml 설정 + sy_prop 양쪽 */
        else if (propKey.startsWith('spring.'))  _where = 'sy_prop + yml';
        /* app.* 는 모두 sy_prop */
        else if (propKey.startsWith('app.'))     _where = 'sy_prop';
      }
      return { _svc: svc, _app: app || '', _level: level || '', _kind: kind, _val: val,
               _applied: applied || '', _note: note || '', _propKey: propKey || '',
               _where, _color: color || 'gray', _configUrl: configUrl || '' };
    };

    const refRows = [
      /* ── YouTube 강좌 ── */
      _mkR('YouTube', '소셜로그인', '-', '강좌링크', '소셜로그인 구현 원리 (네이버/카카오/깃헙)',  '참고', 'https://www.youtube.com/watch?v=Aa6oqanyOHY', '', 'red'),
      _mkR('YouTube', '소셜로그인', '-', '강좌링크', '카카오 로그인 설정 및 준비',                 '참고', 'https://www.youtube.com/watch?v=Aa6oqanyOHY', '', 'red'),
      _mkR('YouTube', '소셜로그인', '-', '강좌링크', '네이버 소셜 로그인 구현',                    '참고', 'https://www.youtube.com/watch?v=NrMUyA47gdU', '', 'red'),
      _mkR('YouTube', '소셜로그인', '-', '강좌링크', 'Google OAuth 구글 소셜 로그인',              '참고', 'https://www.youtube.com/watch?v=olnJzoa4A68', '', 'red'),
      _mkR('YouTube', '결제',       '-', '강좌링크', '토스페이먼츠 5분 결제 연동',                 '참고', 'https://www.youtube.com/watch?v=HtwLMwzTG5c', '', 'red'),
      _mkR('YouTube', '메일',       '-', '강좌링크', '스프링 SMTP / 구글 앱 비밀번호 신청',        '참고', 'https://www.youtube.com/watch?v=Sedf9uO7W4E', '', 'red'),
      /* ── Kakao: illeesam_netlify (ID: 1429368) ── */
      _mkR('Kakao', 'illeesam_netlify (1429368)', 'Lv1 앱',       'REST API 키',          '44074b1c358f60292145b3068460f37d', '미설정',   '',                                               '', 'green',  'https://developers.kakao.com/console/app/1429368'),
      _mkR('Kakao', 'illeesam_netlify (1429368)', 'Lv1 앱',       'JavaScript 키',        '797a116c08880d3865a89cf4f70b91f5',  '미설정',   'Kakao.init() / 카카오맵 공용',                   '', 'blue',   'https://developers.kakao.com/console/app/1429368'),
      _mkR('Kakao', 'illeesam_netlify (1429368)', 'Lv1 앱',       '네이티브 앱 키',       '96e57663db167a8e7a78345c9d0cf9d2',  '미사용',   '',                                               '', 'purple', 'https://developers.kakao.com/console/app/1429368'),
      _mkR('Kakao', 'illeesam_netlify (1429368)', 'Lv2 로그인',   '시크릿(로그인)',       '1gV3lHvBP6KNju9P5E6I4TbchWByfPIh', '미설정',   '활성화:ON',                                      '', 'yellow', 'https://developers.kakao.com/console/app/1429368/product/login'),
      _mkR('Kakao', 'illeesam_netlify (1429368)', 'Lv2 로그인',   '시크릿(비즈)',         'ZyuNrjSOp2yilmTv9MSxDlXRdwPFXDTB', '미설정',   'Redirect: /login/oauth2/code/kakao | 활성화:ON', '', 'yellow', 'https://developers.kakao.com/console/app/1429368/product/login'),
      _mkR('Kakao', 'illeesam_netlify (1429368)', 'Lv3 동의항목', '닉네임',               '',                                   '필수동의', '',                                               '', 'gray'),
      _mkR('Kakao', 'illeesam_netlify (1429368)', 'Lv3 동의항목', '프로필사진',           '',                                   '필수동의', '',                                               '', 'gray'),
      _mkR('Kakao', 'illeesam_netlify (1429368)', 'Lv3 동의항목', '친구목록',             '',                                   '이용중동의','카카오서비스내 친구목록',                        '', 'gray'),
      _mkR('Kakao', 'illeesam_netlify (1429368)', 'Lv3 접근권한', '카카오톡 메시지 전송', '',                                   '선택동의', '',                                               '', 'gray'),
      /* ── Kakao: illeesam_synology (ID: 1491354) — DB 적용 앱 ── */
      _mkR('Kakao', 'illeesam_synology (1491354)', 'Lv1 앱',      'REST API 키',          '63d491e61a4caacf2fc90ee252f2d644',  '미설정',   '',                                               '',                                'green',  'https://developers.kakao.com/console/app/1491354'),
      _mkR('Kakao', 'illeesam_synology (1491354)', 'Lv1 앱',      'JavaScript 키',        'a2990e41aa57c3a4ad1fe97a210938d7',  '적용됨',   'app.auth.social.kakao-js-key / app.map.kakao-js-key', 'app.auth.social.kakao-js-key', 'blue', 'https://developers.kakao.com/console/app/1491354'),
      _mkR('Kakao', 'illeesam_synology (1491354)', 'Lv1 앱',      '네이티브 앱 키',       '4f43ddc38e22c79280d18595a31ff27b',  '미사용',   '',                                               '',                                'purple', 'https://developers.kakao.com/console/app/1491354'),
      _mkR('Kakao', 'illeesam_synology (1491354)', 'Lv2 로그인',  '시크릿(로그인)',       '7gxUHEectTM7qYSDmhnXUJc3ZE1ymqRO', '미설정',   '활성화:ON',                                      '',                                'yellow', 'https://developers.kakao.com/console/app/1491354/product/login'),
      _mkR('Kakao', 'illeesam_synology (1491354)', 'Lv2 로그인',  '시크릿(비즈)',         'Q6d7uCUnJBXCXQ2qINFWt2wSZ0sEzpB2', '미설정',   'Redirect: /login/oauth2/code/kakao | 활성화:ON', '',                                'yellow', 'https://developers.kakao.com/console/app/1491354/product/login'),
      _mkR('Kakao', 'illeesam_synology (1491354)', 'Lv3 동의항목','닉네임',               '',                                  '필수동의', '',                                               '',                                'gray'),
      _mkR('Kakao', 'illeesam_synology (1491354)', 'Lv3 동의항목','프로필사진',           '',                                  '필수동의', '',                                               '',                                'gray'),
      _mkR('Kakao', 'illeesam_synology (1491354)', 'Lv3 동의항목','친구목록',             '',                                  '이용중동의','',                                               '',                                'gray'),
      _mkR('Kakao', 'illeesam_synology (1491354)', 'Lv3 접근권한','카카오톡 메시지 전송', '',                                  '선택동의', '',                                               '',                                'gray'),
      /* ── Kakao: illeesam_localhost (ID: 1491909) ── */
      _mkR('Kakao', 'illeesam_localhost (1491909)', 'Lv1 앱',     'REST API 키',          '2e8671b1cc341f7d4d92724a2d4eee2c',  '미설정',   '',                                               '', 'green',  'https://developers.kakao.com/console/app/1491909'),
      _mkR('Kakao', 'illeesam_localhost (1491909)', 'Lv1 앱',     'JavaScript 키',        '2e8671b1cc341f7d4d92724a2d4eee2c',  '미설정',   '',                                               '', 'blue',   'https://developers.kakao.com/console/app/1491909'),
      _mkR('Kakao', 'illeesam_localhost (1491909)', 'Lv1 앱',     '네이티브 앱 키',       '4f43ddc38e22c79280d18595a31ff27b',  '미사용',   '',                                               '', 'purple', 'https://developers.kakao.com/console/app/1491909'),
      _mkR('Kakao', 'illeesam_localhost (1491909)', 'Lv2 로그인', '시크릿(로그인)',       '7gxUHEectTM7qYSDmhnXUJc3ZE1ymqRO', '미설정',   '활성화:ON',                                      '', 'yellow', 'https://developers.kakao.com/console/app/1491909/product/login'),
      _mkR('Kakao', 'illeesam_localhost (1491909)', 'Lv2 로그인', '시크릿(비즈)',         'Q6d7uCUnJBXCXQ2qINFWt2wSZ0sEzpB2', '미설정',   '활성화:ON',                                      '', 'yellow', 'https://developers.kakao.com/console/app/1491909/product/login'),
      _mkR('Kakao', 'illeesam_localhost (1491909)', 'Lv3 동의항목','닉네임',              '',                                  '필수동의', '',                                               '', 'gray'),
      _mkR('Kakao', 'illeesam_localhost (1491909)', 'Lv3 동의항목','프로필사진',          '',                                  '필수동의', '',                                               '', 'gray'),
      _mkR('Kakao', 'illeesam_localhost (1491909)', 'Lv3 동의항목','친구목록',            '',                                  '이용중동의','',                                               '', 'gray'),
      _mkR('Kakao', 'illeesam_localhost (1491909)', 'Lv3 접근권한','카카오톡 메시지 전송','',                                  '선택동의', '',                                               '', 'gray'),
      /* ── Naver ── */
      _mkR('Naver', 'illeesam_netlify',   'Lv1 앱',       'Client ID',     'r6RWBr2qMOCZbGPFALrA', '미설정',   '',                              '',                                    'green',  'https://developers.naver.com/apps'),
      _mkR('Naver', 'illeesam_netlify',   'Lv1 앱',       'Client Secret', 'c_V0sjmlR5',            '미설정',   'Callback: /oauth/callback/naver','',                                    'yellow', 'https://developers.naver.com/apps'),
      _mkR('Naver', 'illeesam_netlify',   'Lv2 동의항목', '회원이름',      '', '필수', '', '', 'gray'),
      _mkR('Naver', 'illeesam_netlify',   'Lv2 동의항목', '이메일',        '', '필수', '', '', 'gray'),
      _mkR('Naver', 'illeesam_synology',  'Lv1 앱',       'Client ID',     'jWtLT9SUfE2JWEji2XGq', '적용됨',   '',                              'app.auth.social.naver-client-id',     'green',  'https://developers.naver.com/apps'),
      _mkR('Naver', 'illeesam_synology',  'Lv1 앱',       'Client Secret', 'QOX2GZO1uk',            '적용됨',   'Callback: /oauth/callback/naver','app.auth.social.naver-client-secret', 'yellow', 'https://developers.naver.com/apps'),
      _mkR('Naver', 'illeesam_synology',  'Lv2 동의항목', '회원이름',      '', '필수', '', '', 'gray'),
      _mkR('Naver', 'illeesam_synology',  'Lv2 동의항목', '이메일',        '', '필수', '', '', 'gray'),
      _mkR('Naver', 'illeesam_localhost', 'Lv1 앱',       'Client ID',     '01sBNJ_R7mdQDl5_d3AM', '미설정',   '',                              '',                                    'green',  'https://developers.naver.com/apps'),
      _mkR('Naver', 'illeesam_localhost', 'Lv1 앱',       'Client Secret', 'c5cSSSZCaF',            '미설정',   'Callback: /oauth/callback/naver','',                                    'yellow', 'https://developers.naver.com/apps'),
      _mkR('Naver', 'illeesam_localhost', 'Lv2 동의항목', '회원이름',      '', '필수', '', '', 'gray'),
      _mkR('Naver', 'illeesam_localhost', 'Lv2 동의항목', '이메일',        '', '필수', '', '', 'gray'),
      /* ── Google ── */
      _mkR('Google', '공통 계정',   'Lv1 계정', 'Client ID',  '207844440856-5ib9mk6frvt7rfpt8823e48c3c0lavth.apps.googleusercontent.com', '적용됨', 'OAuth 2.0 사용자 인증 정보', 'app.auth.social.google-client-id', 'blue', 'https://console.cloud.google.com/apis/credentials'),
      _mkR('Google', 'Play Console','Lv1',      'Console URL','developer.android.com/distribute/console', '참고', '', '', 'blue', 'https://play.google.com/console'),
      /* ── 토스페이먼츠 ── */
      _mkR('토스페이먼츠', '문서용 테스트키', 'Lv1 FE', '클라이언트 키 (sy_prop)',    'test_gck_docs_Ovk5rk1EwkEbP0W43n07xlzm', '적용됨', '결제위젯 연동',                               'app.pay.toss.widget-client-key', 'green',  'https://developers.tosspayments.com/'),
      _mkR('토스페이먼츠', '문서용 테스트키', 'Lv1 FE', '클라이언트 키 (하드코딩)',   'test_gck_docs_Ovk5rk1EwkEbP0W43n07xlzm', '적용됨', 'foEnvConsts.toss.TEST_CLIENT_KEY (폴백)',     '__foEnvConsts__',               'green',  'https://developers.tosspayments.com/'),
      _mkR('토스페이먼츠', '문서용 테스트키', 'Lv1 BE', '시크릿 키 (sy_prop)',        'test_gsk_docs_OaPz8L5KdmQXkzRz3y47BMw6',  '적용됨', '결제 연동하기 가이드',                        'app.pay.toss.secret-key',        'yellow', 'https://developers.tosspayments.com/'),
      _mkR('토스페이먼츠', '문서용 테스트키', 'Lv1 BE', '시크릿 키 (하드코딩)',       'test_gsk_docs_OaPz8L5KdmQXkzRz3y47BMw6',  '적용됨', 'fo/boEnvConsts.toss.TEST_SECRET_KEY (폴백)', '__foEnvConsts__',               'yellow', 'https://developers.tosspayments.com/'),
      /* ── SMTP/Gmail ── */
      _mkR('SMTP/Gmail', 'illeesam4app', 'Lv1', '계정',       'illeesam4@gmail.com', '사용중', '',                        'spring.mail.username', 'blue',   'https://myaccount.google.com/apppasswords'),
      _mkR('SMTP/Gmail', 'illeesam4app', 'Lv1', '비밀번호',   'sxxx5xx4x!',          '사용중', '구글 계정 비밀번호',       '',                     'red'),
      _mkR('SMTP/Gmail', 'illeesam4app', 'Lv1', '앱 비밀번호','wqji ylpf pcwt vhnh', '사용중', '2단계 인증 활성화 필수',   'spring.mail.password', 'yellow', 'https://myaccount.google.com/apppasswords'),
    ];

    /* 트리 렌더용: refRows를 서비스→앱→레벨→키 4단계 계층으로 변환 (정적 배열 → 일반 변수) */
    const cfRefTree = (() => {
      const svcMap = {};
      refRows.forEach((r, idx) => {
        const svcKey = r._svc;
        const appKey = r._app || '(공통)';
        const lvKey  = r._level || '-';
        if (!svcMap[svcKey]) svcMap[svcKey] = { label: svcKey, color: r._color, apps: {} };
        const svc = svcMap[svcKey];
        if (!svc.apps[appKey]) svc.apps[appKey] = { label: appKey, levels: {} };
        const app = svc.apps[appKey];
        if (!app.levels[lvKey]) app.levels[lvKey] = { label: lvKey, rows: [] };
        app.levels[lvKey].rows.push({ ...r, _idx: idx });
      });
      return Object.values(svcMap).map(svc => ({
        ...svc,
        apps: Object.values(svc.apps).map(app => ({
          ...app,
          levels: Object.values(app.levels),
        })),
      }));
    })();

    /* 펼침/접힘 상태 (서비스·앱 단위) */
    const refOpenSvc = reactive({});
    const refOpenApp = reactive({});
    const fnRefToggleSvc = (svcLabel) => {
      refOpenSvc[svcLabel] = !(refOpenSvc[svcLabel] !== false);
    };
    const fnRefToggleApp = (key) => {
      refOpenApp[key] = !(refOpenApp[key] !== false);
    };
    const fnRefSvcOpen = (lbl) => refOpenSvc[lbl] !== false;
    const fnRefAppOpen = (key) => refOpenApp[key]  !== false;
    const fnRefExpandAll = () => {
      cfRefTree.forEach(svc => {
        refOpenSvc[svc.label] = true;
        svc.apps.forEach(app => { refOpenApp[svc.label + '|' + app.label] = true; });
      });
    };
    const fnRefCollapseAll = () => {
      cfRefTree.forEach(svc => {
        refOpenSvc[svc.label] = false;
        svc.apps.forEach(app => { refOpenApp[svc.label + '|' + app.label] = false; });
      });
    };

    const baseGridColumns = [
      { key: 'channelCode', label: '코드',          width: '110px', mono: true },
      { key: 'category',    label: '분류',           width: '80px' },
      { key: 'channel',     label: '채널 / 서비스',  width: '130px' },
      { key: 'beStat',      label: 'BE 설정',        width: '240px', align: 'center' },
      { key: 'feStat',      label: 'FE 설정',        width: '200px', align: 'center' },
      { key: '_test',       label: '테스트',         width: '90px',  align: 'center' },
      { key: 'testResultCd',  label: '연동결과',       width: '150px', align: 'center' },
      { key: 'testMsg',     label: '테스트 결과',    width: '180px' },
    ];

    /* ##### [03] 데이터 로드 ######################################################## */

    const rows = reactive([]);

    const _feKey = (name) => {
      if (!name) return null;
      const store = window.sfGetBoAppStore?.();
      if (!store) return null;
      /* boAppStore 필드명: sv + 첫글자대문자 + 나머지 (예: kakaoJsKey → svKakaoJsKey) */
      const svKey = 'sv' + name.charAt(0).toUpperCase() + name.slice(1);
      const val = store[svKey];
      return (val && val !== '' && val !== '-') ? val : null;
    };

    const _beCache = reactive({});

    const _statOf = (val) => (val ? '설정됨' : '미설정');

    const _META = [
      /* ── 소셜 로그인 ── */
      {
        channelCode: 'SOCIAL_GOOGLE',
        category: '소셜로그인', channel: 'Google 로그인', feKey: 'googleClientId', beKey: 'app.auth.social.google-client-id',
        remark: 'OAuth2 클라이언트 ID', testFn: 'google',
        desc: 'Google OAuth 2.0 소셜 로그인에 사용합니다. Google Cloud Console에서 OAuth 클라이언트 ID를 발급받아 등록하세요.',
        guideUrl: 'https://console.cloud.google.com/apis/credentials',
        guideLabel: 'Google Cloud Console',
        feDesc: 'FE에서 Google Sign-In 버튼 초기화에 사용 (window.google.accounts.id.initialize) | {illeesam@gmail.com, 앱이름:illeesam_app_260628, 비번:ndem vvnt xwpu hswa } ',
        feFile: 'sy_prop:app.auth.social.google-client-id',
        beDesc: 'BE에서 Google 토큰 검증 및 사용자 정보 조회 시 사용',
        beFile: 'sy_prop:app.auth.social.google-client-id',
        dbTable: 'mb_member_sns (sns_type=GOOGLE)',
      },
      {
        channelCode: 'SOCIAL_KAKAO',
        category: '소셜로그인', channel: 'Kakao 로그인', feKey: 'kakaoJsKey', beKey: 'app.auth.social.kakao-js-key',
        remark: 'JavaScript 키', testFn: 'kakao',
        desc: 'Kakao 소셜 로그인에 사용합니다. Kakao Developers에서 앱을 생성하고 JavaScript 키를 발급받으세요.',
        guideUrl: 'https://developers.kakao.com/console/app',
        guideLabel: 'Kakao Developers',
        feDesc: 'FE에서 Kakao.init() 호출 시 사용하는 JavaScript 앱 키 (FE·BE 동일 키)',
        feFile: 'sy_prop:app.auth.social.kakao-js-key',
        beDesc: 'BE에서 Kakao 사용자정보 API 호출 시 사용 (JavaScript 키)',
        beFile: 'sy_prop:app.auth.social.kakao-js-key',
        dbTable: 'mb_member_sns (sns_type=KAKAO)',
      },
      {
        channelCode: 'SOCIAL_NAVER',
        category: '소셜로그인', channel: 'Naver 로그인', feKey: 'naverClientId', beKey: 'app.auth.social.naver-client-id',
        remark: '클라이언트 ID', testFn: 'naver',
        desc: 'Naver 소셜 로그인에 사용합니다. Naver Developers에서 애플리케이션을 등록하고 클라이언트 ID를 발급받으세요.',
        guideUrl: 'https://developers.naver.com/apps',
        guideLabel: 'Naver Developers',
        feDesc: 'FE에서 Naver 로그인 버튼 초기화 시 사용 (naver.LoginWithNaverId)',
        feFile: 'sy_prop:app.auth.social.naver-client-id',
        beDesc: 'BE에서 Naver 액세스 토큰 검증 및 사용자 프로필 조회 시 사용',
        beFile: 'sy_prop:app.auth.social.naver-client-id',
        dbTable: 'mb_member_sns (sns_type=NAVER)',
      },
      /* ── 결제 ── */
      {
        channelCode: 'PAY_TOSS',
        category: '결제', channel: '토스페이먼츠', feKey: 'tossClientKey', beKey: 'app.pay.toss.widget-client-key',
        remark: 'FE:클라이언트키 / BE:시크릿키(app.pay.toss.secret-key)', testFn: 'toss',
        desc: '토스페이먼츠 결제 연동에 사용합니다. 토스페이먼츠 개발자 센터에서 클라이언트 키(FE)와 시크릿 키(BE)를 발급받으세요.',
        guideUrl: 'https://developers.tosspayments.com/',
        guideLabel: '토스페이먼츠 개발자센터',
        feDesc: 'FE에서 결제창 초기화 시 사용하는 클라이언트 키 (test_gck_docs_* 또는 live_ck_* 접두어)',
        feFile: 'sy_prop:app.pay.toss.widget-client-key',
        beDesc: 'BE에서 결제 승인/취소 API 호출 시 HTTP Basic Auth 비밀번호로 사용하는 시크릿 키',
        beFile: 'sy_prop:app.pay.toss.secret-key',
        dbTable: 'od_pay, od_pay_method, od_refund',
      },
      /* ── 지도 ── */
      {
        channelCode: 'MAP_KAKAO',
        category: '지도', channel: 'Kakao 지도', feKey: 'kakaoMapJsKey', beKey: 'app.map.kakao-js-key',
        remark: 'JavaScript 키 (카카오맵)', testFn: 'kakaoMap',
        desc: 'Kakao Maps API 연동에 사용합니다. Kakao Developers에서 앱 > 카카오맵 사용 설정을 ON으로 변경하고 JavaScript 키를 사용하세요.',
        guideUrl: 'https://developers.kakao.com/console/app',
        guideLabel: 'Kakao Developers',
        feDesc: 'FE에서 Kakao.maps 스크립트 로드 시 appkey 파라미터로 사용 (소셜 로그인과 동일 JavaScript 키)',
        feFile: 'sy_prop:app.map.kakao-js-key',
        beDesc: '현재 BE 서버 사이드 Kakao 지도 API 호출 없음 (FE 전용)',
        beFile: 'sy_prop:app.map.kakao-js-key',
        dbTable: 'sy_site (site_address 좌표변환 시 사용)',
      },
      {
        channelCode: 'MAP_NAVER',
        category: '지도', channel: 'Naver 지도', feKey: 'naverMapClientId', beKey: 'app.map.naver-map-client-id',
        remark: 'NCP 클라이언트 ID', testFn: 'naverMap',
        desc: 'Naver Cloud Platform Maps API 연동에 사용합니다. NCP Console에서 Maps 서비스를 활성화하고 클라이언트 ID를 발급받으세요.',
        guideUrl: 'https://console.ncloud.com/naver-service/application',
        guideLabel: 'Naver Cloud Platform Console',
        feDesc: 'FE 지도 스크립트 로드 시 ncpClientId 파라미터로 사용',
        feFile: 'sy_prop:app.map.naver-map-client-id',
        beDesc: 'BE에서 주소 → 좌표 변환(Geocoding) 등 서버 사이드 Maps API 호출 시 사용',
        beFile: 'sy_prop:app.map.naver-map-client-id',
        dbTable: 'sy_site (site_address 좌표변환 시 사용)',
      },
      {
        channelCode: 'MAP_GOOGLE',
        category: '지도', channel: 'Google 지도', feKey: 'googleMapApiKey', beKey: 'app.map.google-api-key',
        remark: 'Maps JavaScript API 키', testFn: 'googleMap',
        desc: 'Google Maps Platform 연동에 사용합니다. Google Cloud Console에서 Maps JavaScript API와 Geocoding API를 활성화하고 API 키를 발급받으세요.',
        guideUrl: 'https://console.cloud.google.com/google/maps-apis',
        guideLabel: 'Google Maps Platform Console',
        feDesc: 'FE 지도 스크립트 로드 시 key 파라미터로 사용 (Maps JavaScript API)',
        feFile: 'sy_prop:app.map.google-api-key',
        beDesc: 'BE에서 서버 사이드 Geocoding / Places API 호출 시 사용',
        beFile: 'sy_prop:app.map.google-api-key',
        dbTable: 'sy_site (site_address 좌표변환 시 사용)',
      },
      /* ── 메일 ── */
      {
        channelCode: 'MAIL_SMTP',
        category: '메일', channel: 'SMTP', feKey: null, beKey: 'spring.mail.host',
        remark: 'SMTP 호스트', testFn: 'smtp',
        desc: '이메일 발송에 사용하는 SMTP 서버 설정입니다. Gmail 사용 시 앱 비밀번호를 별도 발급해야 합니다.',
        guideUrl: 'https://myaccount.google.com/apppasswords',
        guideLabel: 'Gmail 앱 비밀번호 발급',
        feDesc: null,
        feFile: null,
        beDesc: 'application.yml의 spring.mail.host / port / username / password 값으로 설정',
        beFile: 'yml:spring.mail.host / port',
        dbTable: 'cmh_push_log (channel=EMAIL)',
      },
      /* ── SMS ── */
      {
        channelCode: 'MSG_SMS',
        category: 'SMS', channel: 'SMS 발송', feKey: null, beKey: 'app.sms.api-key',
        remark: 'API 키', testFn: 'sms',
        desc: 'SMS 문자 발송 서비스 API 키입니다. 현재 연동된 SMS 공급사의 콘솔에서 API 키를 발급받으세요.',
        guideUrl: null,
        guideLabel: null,
        feDesc: null,
        feFile: null,
        beDesc: 'BE SMS 발송 서비스에서 인증 헤더 또는 파라미터로 사용',
        beFile: 'sy_prop:app.sms.api-key',
        dbTable: 'cmh_push_log (channel=SMS)',
      },
      /* ── 푸시 ── */
      {
        channelCode: 'PUSH_FCM',
        category: '푸시', channel: 'FCM', feKey: 'fcmProjectId', beKey: 'app.push.fcm.project-id',
        remark: '프로젝트 ID', testFn: 'fcm',
        desc: 'Firebase Cloud Messaging(FCM) 푸시 알림 연동에 사용합니다. Firebase Console에서 프로젝트를 생성하고 서비스 계정 키를 다운로드하세요.',
        guideUrl: 'https://console.firebase.google.com/',
        guideLabel: 'Firebase Console',
        feDesc: 'FE Web Push 초기화 시 Firebase 프로젝트 ID로 사용',
        feFile: 'sy_prop:app.push.fcm.project-id',
        beDesc: 'BE에서 FCM v1 API 호출 시 프로젝트 ID (서비스 계정 JSON 파일도 별도 필요)',
        beFile: 'sy_prop:app.push.fcm.project-id',
        dbTable: 'mb_device_token, cmh_push_log (channel=FCM)',
      },
      {
        channelCode: 'PUSH_APNS',
        category: '푸시', channel: 'APNs', feKey: null, beKey: 'app.push.apns.key-id',
        remark: '키 ID', testFn: 'apns',
        desc: 'Apple Push Notification service(APNs) iOS 푸시 알림 연동에 사용합니다. Apple Developer 계정에서 APNs 키를 생성하세요.',
        guideUrl: 'https://developer.apple.com/account/resources/authkeys/list',
        guideLabel: 'Apple Developer 계정',
        feDesc: null,
        feFile: null,
        beDesc: 'BE에서 APNs JWT 토큰 생성 시 사용하는 키 ID (.p8 인증서 파일도 별도 필요)',
        beFile: 'sy_prop:app.push.apns.key-id',
        dbTable: 'mb_device_token, cmh_push_log (channel=APNS)',
      },
      /* ── 카카오 ── */
      {
        channelCode: 'KAKAO_ALIM',
        category: '카카오', channel: '알림톡', feKey: null, beKey: 'app.kakao.alimtalk.sender-key',
        remark: '발신 프로필 키', testFn: 'kakaoAlim',
        desc: '카카오 알림톡 발송에 사용합니다. 비즈니스 채널을 개설하고 발신 프로필 키를 발급받으세요.',
        guideUrl: 'https://business.kakao.com/',
        guideLabel: '카카오비즈니스',
        feDesc: null,
        feFile: null,
        beDesc: 'BE에서 알림톡 API 호출 시 인증 헤더로 사용하는 발신 프로필 키',
        beFile: 'yml:app.kakao.alimtalk.sender-key',
        dbTable: 'cmh_push_log (channel=KAKAO)',
      },
      /* ── 카카오 공유 ── */
      {
        channelCode: 'KAKAO_SHARE',
        category: '카카오', channel: '카카오톡 공유', feKey: 'kakaoJsKey', beKey: 'app.auth.social.kakao-js-key',
        remark: 'JavaScript 키 (소셜 로그인과 동일)', testFn: 'kakaoShare',
        desc: '카카오톡 공유 기능에 사용합니다. 소셜 로그인과 동일한 JavaScript 키를 사용하며, Kakao Developers 에서 Web 플랫폼에 도메인을 등록해야 합니다.',
        guideUrl: 'https://developers.kakao.com/console/app',
        guideLabel: 'Kakao Developers',
        feDesc: 'FE에서 Kakao.Share.sendDefault() 호출 시 Kakao.init() 에 사용하는 JavaScript 앱 키',
        feFile: 'sy_prop:app.auth.social.kakao-js-key',
        beDesc: 'BE 서버 사이드 카카오 공유 API 없음 (FE 전용, Kakao SDK 2.x)',
        beFile: 'sy_prop:app.auth.social.kakao-js-key',
        dbTable: '없음 (클라이언트 공유, 서버 저장 없음)',
      },
      /* ── AI ── */
      {
        channelCode: 'AI_CHATBOT',
        category: 'AI/챗봇', channel: 'AI 챗봇', feKey: null, beKey: 'app.chat.ai.api-key',
        remark: 'API 키', testFn: 'ai',
        desc: 'AI 챗봇 서비스 연동 API 키입니다. 연동한 AI 서비스(OpenAI / Claude 등) 콘솔에서 API 키를 발급받으세요.',
        guideUrl: null,
        guideLabel: null,
        feDesc: null,
        feFile: null,
        beDesc: 'BE AI 챗봇 서비스에서 API 인증 헤더로 사용',
        beFile: 'sy_prop:app.chat.ai.api-key',
        dbTable: 'cm_chatt_room, cm_chatt_msg',
      },
    ];

    /* 이력 패널 상태 */
    const histState = reactive({
      show: true, channelKey: '', channelLabel: '전체', logs: [], loading: false,
      pageNo: 1, pageSize: 5, total: 0, searchWord: '',
      get pageTotalPage() { return Math.max(1, Math.ceil(this.total / this.pageSize)); },
    });

    const _buildRows = () => {
      rows.length = 0;
      _META.forEach((m) => {
        const feVal = _feKey(m.feKey);
        const beVal = m.beKey ? (_beCache[m.beKey] ?? null) : null;
        const key = m.testFn || m.feKey || m.beKey || '-';
        rows.push({
          channelCode:   m.channelCode || key.toUpperCase(),
          category:      m.category,
          channel:       m.channel,
          keyName:       key,
          feStat:        m.feKey ? _statOf(feVal) : '-',
          beStat:        m.beKey ? _statOf(beVal)  : '-',
          feRawVal:      feVal ? String(feVal).slice(0, 6) + '••••••' : null,
          beRawVal:      beVal ? String(beVal).slice(0, 6) + '••••••' : null,
          testResultCd:    '-',
          testMsg:       '',
          lastTestDate:  null,
          lastTestOk:    null,
          remark:        m.remark,
          _testFn:       m.testFn,
          _testing:      false,
          _desc:         m.desc,
          _guideUrl:     m.guideUrl,
          _guideLabel:   m.guideLabel,
          _feKey:        m.feKey,
          _beKey:        m.beKey,
          _feDesc:       m.feDesc,
          _feFile:       m.feFile ? m.feFile.replace('propKey', m.feKey || '') : null,
          _beDesc:       m.beDesc,
          _beFile:       m.beFile  || null,
          _dbTable:      m.dbTable || null,
        });
      });
    };

    /* 페이지 로드 시 채널별 최신 이력 1건씩 가져와 연동결과 열 초기화 */
    const _fetchLatestResults = async () => {
      try {
        const res = await boApi.get('/bo/sy/ext-test-log/latest',
          coUtil.cofApiHdr('연동설정대시보드', '최신이력조회'));
        const list = res.data?.data || [];
        const map = {};
        list.forEach((lg) => { map[lg.channelKey] = lg; });
        rows.forEach((row) => {
          const lg = map[row.keyName];
          if (lg) {
            row.lastTestDate = lg.regDate;
            row.lastTestOk   = lg.testResultCd === 'SUCCESS';
          }
        });
      } catch (_) { /* 무시 */ }
    };

    const fnFmtDatetime = (iso) => {
      if (!iso) return '-';
      const d = new Date(iso);
      const pad = (n) => String(n).padStart(2, '0');
      return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate())
        + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds());
    };

    /* 이력 셀 표시 헬퍼 */

    /* JSON 문자열 → [{k, v}, ...] 배열 (중첩 없이 1단계만) */
    const fnParseKv = (str) => {
      if (!str) return null;
      try {
        const obj = JSON.parse(str);
        if (typeof obj !== 'object' || obj === null) return null;
        return Object.entries(obj).map(([k, v]) => ({
          k,
          v: (typeof v === 'object' && v !== null) ? JSON.stringify(v) : String(v == null ? '' : v),
        }));
      } catch (_) { return null; }
    };

    /* 계정정보: [{k,v}] 배열 반환 */
    const fnFmtAccount = (lg) => {
      if (lg.testAccount) {
        const kv = fnParseKv(lg.testAccount);
        if (kv) return kv;
        return [{ k: '대상', v: lg.testAccount }];
      }
      /* 구형 데이터: testMsg에서 [요청]{...}[결과] 추출 */
      if (lg.testMsg && lg.testMsg.startsWith('[요청]')) {
        try {
          const m = lg.testMsg.match(/^\[요청\]\s*(\{[\s\S]*?\})\s*\[결과\]/);
          if (m) {
            const obj = JSON.parse(m[1]);
            const acc = [];
            if (obj.toEmail)     acc.push({ k: 'toEmail',  v: obj.toEmail });
            if (obj.toPhone)     acc.push({ k: 'toPhone',  v: obj.toPhone });
            if (obj.deviceToken) acc.push({ k: 'deviceToken', v: obj.deviceToken.slice(0, 20) + '…' });
            if (obj.targetValue) acc.push({ k: 'target',   v: (obj.targetType || '') + ':' + obj.targetValue });
            return acc.length ? acc : null;
          }
        } catch (_) {}
      }
      return null;
    };

    /* 요청내용: [{k,v}] 배열 반환 */
    const fnFmtReq = (lg) => {
      if (lg.testReqBody) {
        const kv = fnParseKv(lg.testReqBody);
        if (kv) return kv;
        return [{ k: '내용', v: lg.testReqBody }];
      }
      if (lg.testMsg && lg.testMsg.startsWith('[요청]')) {
        try {
          const m = lg.testMsg.match(/^\[요청\]\s*(\{[\s\S]*?\})\s*\[결과\]/);
          if (m) {
            const kv = fnParseKv(m[1]);
            return kv || [{ k: '내용', v: m[1] }];
          }
        } catch (_) {}
      }
      return null;
    };

    /* 응답내용: 문자열 반환 */
    const fnFmtResp = (lg) => {
      if (!lg.testMsg) return null;
      if (lg.testMsg.startsWith('[요청]')) {
        const idx = lg.testMsg.indexOf('[결과]');
        return idx >= 0 ? lg.testMsg.slice(idx + 4).trim() : lg.testMsg;
      }
      return lg.testMsg;
    };

    const _loadHist = async () => {
      histState.loading = true;
      try {
        const params = { pageNo: histState.pageNo, pageSize: histState.pageSize };
        if (histState.channelKey) params.channelKey = histState.channelKey;
        if (histState.searchWord) params.searchWord = histState.searchWord;
        const res = await boApi.get('/bo/sy/ext-test-log/list', {
          params,
          ...coUtil.cofApiHdr('연동설정대시보드', '이력조회'),
        });
        const d = res.data?.data || {};
        histState.logs  = d.pageList || (Array.isArray(d) ? d : []);
        histState.total = d.pageTotalCount ?? histState.logs.length;
      } catch (_) { histState.logs = []; histState.total = 0; }
      finally { histState.loading = false; }
    };

    const handleHistOpen = async (row) => {
      histState.show         = true;
      histState.channelKey   = row.keyName;
      histState.channelLabel = row.channel;
      histState.pageNo       = 1;
      histState.logs         = [];
      histState.total        = 0;
      await _loadHist();
    };

    const handleHistClose = () => { histState.show = false; };

    const handleHistPage = async (n) => { histState.pageNo = n; await _loadHist(); };
    const handleHistSearch = async () => { histState.pageNo = 1; await _loadHist(); };

    /* ##### [04] BE 설정 조회 ####################################################### */

    const _fetchBeSettings = async () => {
      try {
        /* app-config/all: BE가 active profile 필터링 후 resolved 값 반환 */
        const r1 = await boApi.get('/bo/sy/app-config/all', coUtil.cofApiHdr('연동설정대시보드', 'yml조회'));
        const ymlList = r1.data?.data?.items || [];
        ymlList.forEach((item) => {
          if (item.ymlKey && item.ymlValue && item.ymlValue !== '(미설정)') {
            _beCache[item.ymlKey] = item.ymlValue;
          }
        });

        /* sy_prop 직접 조회로 보완 — 빈값 덮어쓰기 방지: 이미 채워진 키는 건너뜀 */
        const r2 = await boApi.get('/bo/sy/prop', {
          params: { pageSize: 999 },
          ...coUtil.cofApiHdr('연동설정대시보드', '설정조회'),
        });
        const propList = r2.data?.data || [];
        if (Array.isArray(propList)) {
          propList.forEach((p) => {
            /* 값이 있는 경우만, 기존 채워진 키는 덮어쓰지 않음 */
            if (p.propKey && p.propValue && !_beCache[p.propKey]) {
              _beCache[p.propKey] = p.propValue;
            }
          });
        }
      } catch (_) { /* BE 조회 실패 — beStat '-' 유지 */ }
    };

    /* ##### [05] 테스트 실행 ####################################################### */

    /*
     * 채널별 테스트 맵
     * method: 'key-check' — BE/FE 키 설정 여부로만 판정 (실제 API 호출 없음)
     * method: 'post'/'get' — 실제 API 호출
     * checkBeKey / checkFeKey — key-check 시 확인할 BE/FE 키 이름
     */
    const _TEST_MAP = {
      google:     { method: 'key-check', label: 'Google OAuth',  checkBeKey: 'app.auth.social.google-client-id', checkFeKey: 'googleClientId' },
      kakao:      { method: 'key-check', label: 'Kakao OAuth',   checkBeKey: 'app.auth.social.kakao-js-key',    checkFeKey: 'kakaoJsKey' },
      naver:      { method: 'key-check', label: 'Naver OAuth',   checkBeKey: 'app.auth.social.naver-client-id', checkFeKey: 'naverClientId' },
      toss:       { method: 'key-check', label: '토스 결제',     checkBeKey: 'app.pay.toss.widget-client-key',  checkFeKey: 'tossClientKey' },
      kakaoMap:   { method: 'key-check', label: 'Kakao 지도',    checkBeKey: 'app.map.kakao-js-key',            checkFeKey: 'kakaoMapJsKey' },
      naverMap:   { method: 'key-check', label: 'Naver 지도',    checkBeKey: 'app.map.naver-map-client-id',     checkFeKey: 'naverMapClientId' },
      googleMap:  { method: 'key-check', label: 'Google 지도',   checkBeKey: 'app.map.google-api-key',          checkFeKey: 'googleMapApiKey' },
      kakaoShare: { method: 'key-check', label: '카카오톡 공유', checkBeKey: 'app.auth.social.kakao-js-key',    checkFeKey: 'kakaoJsKey' },
      smtp:       { method: 'post', url: '/co/ext/mail-send/send',      label: 'SMTP',
                    body: { toEmail: 'test@example.com', toName: '테스트', subject: '[ShopJoy] 연동 테스트', body: '연동 설정 대시보드 테스트 발송' } },
      sms:        { method: 'post', url: '/co/ext/sms-send/send',       label: 'SMS',
                    body: { toPhone: '01000000000', message: '[ShopJoy] SMS 연동 테스트' } },
      fcm:        { method: 'post', url: '/co/ext/push-fcm-send/send',  label: 'FCM',
                    body: { targetType: 'topic', targetValue: 'test_ping', title: '[ShopJoy] FCM 테스트', body: '연동 확인' } },
      apns:       { method: 'post', url: '/co/ext/push-apns-send/send', label: 'APNs',
                    body: { deviceToken: 'TEST_TOKEN', title: '[ShopJoy] APNs 테스트', body: '연동 확인' } },
      kakaoAlim:  { method: 'post', url: '/co/ext/kakao-send/send',     label: '카카오 알림톡',
                    body: { msgType: 'alimtalk', toPhone: '01000000000', templateCode: 'TEST_TMPL', variables: {} } },
      ai:         { method: 'post', url: '/co/ext/ai-chat/chat',        label: 'AI 챗봇',
                    body: { provider: 'openai', message: '연동 테스트: 안녕하세요' } },
    };

    const handleTest = async (row) => {
      if (row._testing) return;
      const meta = _TEST_MAP[row._testFn];
      if (!meta) { row.testResultCd = '실패'; row.testMsg = '테스트 미정의'; return; }
      row._testing = true; row.testResultCd = '-'; row.testMsg = '확인 중...';

      let ok = false;
      let msg = '';
      let reqBody = null;

      try {
        if (meta.method === 'key-check') {
          /* 실제 키 설정 여부로 판정 */
          const beOk = !meta.checkBeKey || !!_beCache[meta.checkBeKey];
          const feOk = !meta.checkFeKey || !!_feKey(meta.checkFeKey);
          const msgs = [];
          if (meta.checkBeKey) msgs.push('BE(' + meta.checkBeKey + '): ' + (beOk ? '설정됨' : '미설정'));
          if (meta.checkFeKey) msgs.push('FE(' + meta.checkFeKey + '): ' + (feOk ? '설정됨' : '미설정'));
          ok  = (meta.checkBeKey ? beOk : true) && (meta.checkFeKey ? feOk : true);
          msg = msgs.join(' / ');
        } else {
          let res;
          if (meta.method === 'post') {
            reqBody = meta.body || {};
            res = await boApi.post(meta.url, reqBody, coUtil.cofApiHdr('연동설정대시보드', meta.label + ' 테스트'));
          } else {
            res = await boApi.get(meta.url, coUtil.cofApiHdr('연동설정대시보드', meta.label + ' 테스트'));
          }
          ok  = res.data?.success !== false;
          msg = res.data?.data?.message || res.data?.message || (ok ? '정상' : '오류');
        }
        row.testResultCd = ok ? '성공' : '실패';
        row.testMsg    = msg;
      } catch (e) {
        ok  = false;
        msg = coUtil.cofErrMsg(e, '연결 실패');
        row.testResultCd = '실패';
        row.testMsg    = msg;
      } finally {
        row._testing = false;
      }

      /* 이력 저장 */
      try {
        const now = new Date().toISOString();
        row.lastTestDate = now;
        row.lastTestOk   = ok;

        /* 계정정보: 채널별로 수신자/대상 정보 추출 */
        let testAccount = null;
        if (reqBody) {
          if (reqBody.toEmail)     testAccount = reqBody.toEmail;
          else if (reqBody.toPhone)  testAccount = reqBody.toPhone;
          else if (reqBody.deviceToken) testAccount = reqBody.deviceToken.slice(0, 40) + (reqBody.deviceToken.length > 40 ? '…' : '');
          else if (reqBody.targetValue) testAccount = reqBody.targetType + ':' + reqBody.targetValue;
        }

        /* 요청 내용: body JSON (key-check는 checkBeKey/checkFeKey 정보) */
        let testReqBody = null;
        if (meta.method === 'key-check') {
          const parts = [];
          if (meta.checkBeKey) parts.push('BE:' + meta.checkBeKey);
          if (meta.checkFeKey) parts.push('FE:' + meta.checkFeKey);
          testReqBody = parts.join(' / ');
        } else if (reqBody && Object.keys(reqBody).length) {
          testReqBody = JSON.stringify(reqBody, null, 0).slice(0, 2000);
        }

        await boApi.post('/bo/sy/ext-test-log/save', {
          siteId:       window.boCommonFilter?.siteId || '',
          channelKey:   row.keyName,
          channelLabel: row.channel,
          testResultCd:   ok ? 'SUCCESS' : 'FAIL',
          testMsg:      msg.slice(0, 2000),
          testUrl:      meta.url || null,
          testReqBody:  testReqBody,
          testAccount:  testAccount,
        }, coUtil.cofApiHdr('연동설정대시보드', '이력저장'));

        /* 테스트 완료 후 해당 채널 이력 패널 자동 열기/갱신 */
        histState.show         = true;
        histState.channelKey   = row.keyName;
        histState.channelLabel = row.channel;
        histState.pageNo       = 1;
        await _loadHist();
      } catch (_) { /* 이력 저장 실패는 조용히 무시 */ }
    };

    /* ##### [06] 이벤트 핸들러 ##################################################### */

    const handleRefresh = async () => {
      loading.value = true;
      await _fetchBeSettings();
      _buildRows();
      loading.value = false;
      _fetchLatestResults();
      showToast('연동 설정 현황을 새로고침했습니다.', 'success');
    };

    const handleTestAll = async () => {
      for (const row of rows) await handleTest(row);
      showToast('전체 테스트 완료.', 'success');
    };

    /* ##### [07] 라이프사이클 ####################################################### */

    /* initPage — 화면 로드 시퀀스. 마운트 시 실행한다. */
    const initPage = async () => {
      loading.value = true;
      await _fetchBeSettings();
      _buildRows();
      loading.value = false;
      _fetchLatestResults();
      _loadHist();
    };
    onMounted(initPage);

    /* ##### [08] 리턴 ############################################################## */

    return {
      codes, loading,
      tab, tabMode, tabs, fnTabModeClass,
      refGridColumns, refRows, cfRefTree,
      refOpenSvc, refOpenApp, fnRefToggleSvc, fnRefToggleApp, fnRefSvcOpen, fnRefAppOpen,
      fnRefExpandAll, fnRefCollapseAll,
      baseGridColumns, rows,
      histState, fnFmtDatetime, fnFmtAccount, fnFmtReq, fnFmtResp,
      handleHistOpen, handleHistClose, handleHistPage, handleHistSearch,
      handleTest, handleRefresh, handleTestAll, _fetchLatestResults,
    };
  },

  template: `
<div>
  <bo-page title="연동설정 대시보드" desc-summary="외부 서비스 연동 키 설정 현황 및 테스트. 행 클릭 시 하단에 이력을 표시합니다.">
    <bo-tab-bar :tabs="tabs" :tab="tab" :tab-mode="tabMode" :show-modes="true" @tab-select="id => tab = id" @mode-select="m => tabMode = m" />

    <div :class="'dtl-tab-grid ' + fnTabModeClass(tabMode)">
    <div v-show="tab === 'channel' || tabMode !== 'tab'">
    <bo-container>
      <bo-grid
        :columns="baseGridColumns"
        :rows="rows"
        :loading="loading"
        list-title="연동 채널 목록"
        empty-text="연동 설정 항목이 없습니다."
        table-max-height="720px"
      >
        <template #toolbar-actions>
          <button class="btn btn_reset btn-sm" @click="handleRefresh">새로고침</button>
          <button class="btn btn_search btn-sm" @click="handleTestAll">전체 테스트</button>
        </template>

        <!-- BE 설정 상태 -->
        <template #cell-beStat="{ row }">
          <td style="text-align:center;vertical-align:middle;padding:5px 8px;">
            <span v-if="row.beStat === '설정됨'" class="badge badge-green">설정됨</span>
            <span v-else-if="row.beStat === '미설정'" class="badge badge-red">미설정</span>
            <span v-else class="badge badge-gray">-</span>
            <div v-if="row._beFile &amp;&amp; row.beStat !== '-'"
              style="margin-top:4px;display:flex;align-items:center;gap:3px;overflow:hidden;max-width:100%;"
              :title="row._beFile.replace(/^(yml:|sy_prop:)/, '')">
              <span style="flex-shrink:0;" :style="row._beFile.startsWith('yml:') ? 'font-weight:600;color:#0284c7;background:#bae6fd;border-radius:3px;padding:1px 4px;font-family:sans-serif;font-size:10px;' : 'font-weight:600;color:#1e40af;background:#dbeafe;border-radius:3px;padding:1px 4px;font-family:sans-serif;font-size:10px;'">
                {{ row._beFile.startsWith('yml:') ? 'app~.yml' : 'sy_prop' }}
              </span>
              <span style="font-family:monospace;font-size:11px;color:#374151;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0;">
                {{ row._beFile.replace(/^(yml:|sy_prop:)/, '') }}
              </span>
            </div>
          </td>
        </template>

        <!-- FE 설정 상태 -->
        <template #cell-feStat="{ row }">
          <td style="text-align:center;vertical-align:middle;padding:5px 8px;">
            <span v-if="row.feStat === '설정됨'" class="badge badge-green">설정됨</span>
            <span v-else-if="row.feStat === '미설정'" class="badge badge-red">미설정</span>
            <span v-else class="badge badge-gray">-</span>
            <div v-if="row._feFile &amp;&amp; row.feStat !== '-'"
              style="margin-top:4px;display:flex;align-items:center;gap:3px;overflow:hidden;max-width:100%;"
              :title="row._feFile.replace(/^(yml:|sy_prop:)/, '')">
              <span style="flex-shrink:0;" :style="row._feFile.startsWith('yml:') ? 'font-weight:600;color:#0284c7;background:#bae6fd;border-radius:3px;padding:1px 4px;font-family:sans-serif;font-size:10px;' : 'font-weight:600;color:#6d28d9;background:#ede9fe;border-radius:3px;padding:1px 4px;font-family:sans-serif;font-size:10px;'">
                {{ row._feFile.startsWith('yml:') ? 'app~.yml' : 'sy_prop' }}
              </span>
              <span style="font-family:monospace;font-size:11px;color:#374151;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0;">
                {{ row._feFile.replace(/^(yml:|sy_prop:)/, '') }}
              </span>
            </div>
          </td>
        </template>

        <!-- 테스트 + 이력조회 버튼 -->
        <template #cell-_test="{ row }">
          <td style="text-align:center;padding:4px 6px;" @click.stop>
            <button class="btn btn-xs" style="display:block;width:72px;margin:0 auto 4px;"
              :disabled="row._testing"
              :style="row._testing ? 'opacity:.5' : ''"
              @click="handleTest(row)">
              {{ row._testing ? '확인중…' : '테스트' }}
            </button>
            <button class="btn btn-xs" style="display:block;width:72px;margin:0 auto;"
              :style="histState.show &amp;&amp; histState.channelKey === row.keyName ? 'background:#6366f1;color:#fff;border-color:#6366f1;' : ''"
              @click="handleHistOpen(row)">
              이력조회
            </button>
          </td>
        </template>

        <!-- 연동결과: 마지막 테스트 일시 + 결과 -->
        <template #cell-testResultCd="{ row }">
          <td style="text-align:center;padding:4px 6px;">
            <div v-if="row.lastTestDate" style="font-size:11px;line-height:1.5;">
              <div style="color:#6b7280;font-size:10px;">{{ fnFmtDatetime(row.lastTestDate) }}</div>
              <span v-if="row.lastTestOk" style="color:#059669;font-weight:600;">✅ 성공</span>
              <span v-else style="color:#dc2626;font-weight:600;">❌ 실패</span>
            </div>
            <span v-else style="color:#ccc;font-size:13px;">-</span>
          </td>
        </template>
      </bo-grid>
    </bo-container>

    <!-- 이력 목록 패널 -->
    <bo-container v-if="histState.show"
      :title="'테스트 이력 — ' + histState.channelLabel"
      :count-text="histState.total + '건'">
      <template #toolbar-actions>
        <input v-model="histState.searchWord" class="form-control" style="width:180px;" placeholder="검색어 입력" @keyup.enter="handleHistSearch" />
        <button class="btn btn_search btn-sm" @click="handleHistSearch">검색</button>
        <button class="btn btn_close btn-sm" @click="handleHistClose">닫기</button>
      </template>
      <div v-if="histState.loading" style="padding:20px;text-align:center;color:#aaa;font-size:13px;">조회 중...</div>
      <div v-else-if="!histState.logs.length" style="padding:20px;text-align:center;color:#aaa;font-size:13px;">이력이 없습니다.</div>
      <template v-else>
        <div style="overflow-x:auto;">
          <table class="bo-table" style="width:100%;min-width:960px;table-layout:fixed;">
            <colgroup>
              <col style="width:36px;">
              <col style="width:138px;">
              <col style="width:56px;">
              <col style="width:170px;">
              <col style="width:150px;">
              <col style="width:30%;">
              <col>
            </colgroup>
            <thead>
              <tr>
                <th style="text-align:center;">번호</th>
                <th style="text-align:center;">일시</th>
                <th style="text-align:center;">결과</th>
                <th>URL</th>
                <th>계정정보</th>
                <th>요청내용</th>
                <th>응답내용</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(lg, li) in histState.logs" :key="lg.logId">
                <td style="text-align:center;color:#aaa;vertical-align:top;padding-top:8px;">{{ histState.total - (histState.pageNo - 1) * histState.pageSize - li }}</td>
                <td style="text-align:center;white-space:nowrap;color:#6b7280;font-size:11px;vertical-align:top;padding-top:8px;">{{ fnFmtDatetime(lg.regDate) }}</td>
                <td style="text-align:center;vertical-align:top;padding-top:8px;">
                  <span v-if="lg.testResultCd === 'SUCCESS'" class="badge badge-green">성공</span>
                  <span v-else class="badge badge-red">실패</span>
                </td>
                <td style="font-family:monospace;font-size:10px;color:#0284c7;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;vertical-align:top;padding-top:8px;" :title="lg.testUrl">{{ lg.testUrl || '-' }}</td>
                <td style="vertical-align:top;padding:6px 8px;">
                  <template v-if="fnFmtAccount(lg)">
                    <div v-for="(item, ii) in fnFmtAccount(lg)" :key="ii"
                      style="font-size:11px;line-height:1.7;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
                      <span style="color:#9ca3af;font-size:10px;">{{ item.k }}:</span>
                      <span style="font-family:monospace;color:#1e40af;margin-left:3px;">{{ item.v }}</span>
                    </div>
                  </template>
                  <span v-else style="color:#d1d5db;font-size:11px;">-</span>
                </td>
                <td style="vertical-align:top;padding:6px 8px;">
                  <template v-if="fnFmtReq(lg)">
                    <div v-for="(item, ri) in fnFmtReq(lg)" :key="ri"
                      style="font-size:11px;line-height:1.7;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
                      <span style="color:#9ca3af;font-size:10px;">{{ item.k }}:</span>
                      <span style="font-family:monospace;color:#374151;margin-left:3px;">{{ item.v }}</span>
                    </div>
                  </template>
                  <span v-else style="color:#d1d5db;font-size:11px;">-</span>
                </td>
                <td style="vertical-align:top;padding:6px 8px;">
                  <span v-if="fnFmtResp(lg)"
                    style="font-size:11px;color:#374151;white-space:pre-wrap;word-break:break-all;line-height:1.7;">{{ fnFmtResp(lg) }}</span>
                  <span v-else style="color:#d1d5db;font-size:11px;">-</span>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        <bo-pager :pager="histState" :on-set-page="handleHistPage" />
      </template>
    </bo-container>
    </div><!-- /tab channel -->

    <div v-show="tab === 'env' || tabMode !== 'tab'">
      <bo-zd-sy-prop-grid />
      <bo-zd-yml-grid />
    </div><!-- /tab env -->

    <div v-show="tab === 'ref' || tabMode !== 'tab'">
    <bo-container title="외부 연동 참고자료" :count-text="refRows.length + '건'">
      <template #toolbar>
        <button class="btn btn_expand_all"   @click="fnRefExpandAll">전체펼치기</button>
        <button class="btn btn_collapse_all" @click="fnRefCollapseAll">전체접기</button>
      </template>
      <div style="overflow-x:auto;">
        <table class="bo-table" style="width:100%;min-width:1000px;">
          <colgroup>
            <col style="width:260px;">
            <col style="width:265px;">
            <col style="width:200px;">
            <col style="width:90px;">
            <col style="width:76px;">
            <col style="width:200px;">
          </colgroup>
          <thead>
            <tr>
              <th>키 구분</th>
              <th>값</th>
              <th>적용 prop</th>
              <th style="text-align:center;">적용위치</th>
              <th style="text-align:center;">적용여부</th>
              <th>비고</th>
            </tr>
          </thead>
          <tbody>
            <template v-for="svc in cfRefTree" :key="svc.label">
              <!-- Lv0 ── 서비스 ────────────────────────────── -->
              <tr style="background:#eff6ff;cursor:pointer;" @click="fnRefToggleSvc(svc.label)">
                <td colspan="6" style="padding:5px 10px;font-weight:700;font-size:13px;border-left:4px solid #3b82f6;">
                  <span style="margin-right:6px;font-size:9px;color:#3b82f6;line-height:1;">{{ fnRefSvcOpen(svc.label) ? '▼' : '▶' }}</span>
                  <span :class="{
                    'badge badge-red':    svc.color === 'red',
                    'badge badge-green':  svc.color === 'green',
                    'badge badge-blue':   svc.color === 'blue',
                    'badge badge-purple': svc.color === 'purple',
                    'badge badge-orange': svc.color === 'yellow',
                    'badge badge-gray':   svc.color === 'gray'
                  }" style="margin-right:8px;font-size:12px;">{{ svc.label }}</span>
                  <span style="font-size:11px;font-weight:400;color:#6b7280;">{{ svc.apps.length }}개 앱</span>
                </td>
              </tr>
              <template v-if="fnRefSvcOpen(svc.label)" v-for="app in svc.apps" :key="svc.label + '|' + app.label">
                <!-- Lv1 ── 앱 / 환경 ──────────────────────── -->
                <tr style="background:#f8fafc;cursor:pointer;" @click="fnRefToggleApp(svc.label + '|' + app.label)">
                  <td colspan="6" style="padding:4px 10px 4px 22px;font-size:12px;border-left:4px solid #93c5fd;">
                    <span style="margin-right:6px;font-size:9px;color:#60a5fa;line-height:1;">{{ fnRefAppOpen(svc.label + '|' + app.label) ? '▼' : '▶' }}</span>
                    <span style="background:#e0f2fe;color:#0369a1;border-radius:4px;padding:1px 8px;font-family:monospace;font-size:11px;font-weight:600;">{{ app.label }}</span>
                    <span style="font-size:10px;color:#9ca3af;margin-left:8px;">{{ app.levels.reduce((s, l) => s + l.rows.length, 0) }}개 항목</span>
                  </td>
                </tr>
                <template v-if="fnRefAppOpen(svc.label + '|' + app.label)" v-for="lv in app.levels" :key="svc.label + '|' + app.label + '|' + lv.label">
                  <!-- Lv2 ── 레벨 그룹 (복수일 때만) ───────── -->
                  <tr v-if="app.levels.length > 1" style="background:#fafafa;">
                    <td colspan="6" style="padding:2px 10px 2px 40px;font-size:10px;color:#9ca3af;letter-spacing:.4px;border-left:4px solid #e2e8f0;">
                      ▸ {{ lv.label }}
                    </td>
                  </tr>
                  <!-- Lv3 ── 키 데이터 행 ──────────────────── -->
                  <tr v-for="r in lv.rows" :key="r._idx" style="background:#fff;">
                    <td style="padding-left:56px;font-size:12px;border-left:4px solid #e2e8f0;"
                      :style="r._where ? 'font-weight:700;color:#1e40af;' : 'font-weight:400;color:#6b7280;'">
                      {{ r._kind }}
                    </td>
                    <td style="font-family:monospace;font-size:11px;color:#374151;word-break:break-all;">
                      <a v-if="r._val &amp;&amp; r._val.startsWith('http')" :href="r._val" target="_blank"
                        style="color:#2563eb;text-decoration:underline;word-break:break-all;">{{ r._val }}</a>
                      <span v-else-if="r._val">{{ r._val }}</span>
                      <span v-else style="color:#d1d5db;">-</span>
                    </td>
                    <td>
                      <span v-if="r._propKey"
                        style="font-size:10px;background:#dbeafe;color:#1e40af;border-radius:3px;padding:1px 5px;font-family:monospace;word-break:break-all;">{{ r._propKey }}</span>
                      <span v-else style="color:#d1d5db;font-size:11px;">-</span>
                    </td>
                    <td style="text-align:center;">
                      <span v-if="r._where === 'sy_prop'"       class="badge badge-blue"   style="font-size:10px;">sy_prop</span>
                      <span v-else-if="r._where === 'sy_prop + yml'" class="badge badge-purple" style="font-size:10px;">sy_prop+yml</span>
                      <span v-else-if="r._where === 'foEnvConsts'" class="badge badge-orange" style="font-size:10px;">foEnvConsts</span>
                      <span v-else-if="r._where === 'boEnvConsts'" class="badge badge-orange" style="font-size:10px;">boEnvConsts</span>
                      <span v-else style="color:#d1d5db;font-size:11px;">-</span>
                    </td>
                    <td style="text-align:center;">
                      <span v-if="r._applied === '적용됨'"      class="badge badge-green"  style="font-size:10px;">적용됨</span>
                      <span v-else-if="r._applied === '테스트 적용'" class="badge badge-blue"  style="font-size:10px;">테스트</span>
                      <span v-else-if="r._applied === '사용중'"      class="badge badge-green"  style="font-size:10px;">사용중</span>
                      <span v-else-if="r._applied === '미설정'"      class="badge badge-red"    style="font-size:10px;">미설정</span>
                      <span v-else-if="r._applied === '미사용'"      class="badge badge-gray"   style="font-size:10px;">미사용</span>
                      <span v-else-if="r._applied === '필수동의'"    class="badge badge-orange" style="font-size:10px;">필수동의</span>
                      <span v-else-if="r._applied === '이용중동의'"  class="badge badge-orange" style="font-size:10px;">이용중</span>
                      <span v-else-if="r._applied === '선택동의'"    class="badge badge-gray"   style="font-size:10px;">선택동의</span>
                      <span v-else-if="r._applied === '필수'"        class="badge badge-orange" style="font-size:10px;">필수</span>
                      <span v-else-if="r._applied === '참고'"        class="badge badge-gray"   style="font-size:10px;">참고</span>
                      <span v-else style="color:#d1d5db;font-size:11px;">-</span>
                    </td>
                    <td style="font-size:11px;color:#6b7280;word-break:break-all;">
                      <a v-if="r._note &amp;&amp; r._note.startsWith('http')" :href="r._note" target="_blank"
                        style="color:#2563eb;text-decoration:underline;">{{ r._note }}</a>
                      <span v-else-if="r._note">{{ r._note }}</span>
                      <span v-else style="color:#d1d5db;">-</span>
                      <a v-if="r._configUrl" :href="r._configUrl" target="_blank"
                        style="display:inline-block;margin-left:6px;padding:1px 6px;border-radius:4px;background:#eff6ff;color:#2563eb;font-size:10px;text-decoration:none;border:1px solid #bfdbfe;white-space:nowrap;">⚙ 설정</a>
                    </td>
                  </tr>
                </template>
              </template>
            </template>
          </tbody>
        </table>
      </div>
    </bo-container>
    </div><!-- /tab ref -->
    </div><!-- /dtl-tab-grid -->

  </bo-page>
</div>
`,
};
