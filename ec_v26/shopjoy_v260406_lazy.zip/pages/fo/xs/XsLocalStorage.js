/**
 * localStorage 정보 관리 (개발도구)
 */
window.XsLocalStorage = {
  name: 'XsLocalStorage',
  props: {
    navigate:  { type: Function, required: true },        // 페이지 이동
    showToast: { type: Function, default: () => {} },      // 토스트 알림
  },
  setup(props) {

    /* ##### [01] 초기 변수 정의 ################################################## */

    const { reactive, computed, onMounted, onUnmounted, watch } = Vue;
    const uiStateGlobal = reactive({ loading: false, error: null, filterKey: '', editingKey: null, editingValue: '', valueColWidth: 65, startX: 0, startWidth: 0});


    /* ##### [02] 액션 모음 (dispatch) ############################################## */

    /* handleBtnAction — 버튼 액션 dispatch (cmd: '{영역명}-기능명'). 5줄 이하 짧은 로직은 인라인 */
    const handleBtnAction = (cmd, param = {}) => {
      console.log(' ■■ XsLocalStorage.js : handleBtnAction -> ', cmd, param);
      // 목록 새로고침
      if (cmd === 'lsItems-reload') {
        return loadStorageData();
      // 전체 삭제
      } else if (cmd === 'lsItems-clearAll') {
        return clearAllStorage();
      // 편집 취소
      } else if (cmd === 'lsItems-editCancel') {
        return cancelEdit();
      } else {
        console.warn('[handleBtnAction] unknown cmd:', cmd);
      }
    };

    /* handleSelectAction — 행/선택 액션 dispatch (cmd: '{영역명}-기능명'). 5줄 이하 짧은 로직은 인라인 */
    const handleSelectAction = (cmd, param = {}) => {
      console.log(' ■■ XsLocalStorage.js : handleSelectAction -> ', cmd, param);
      // 값 복사
      if (cmd === 'lsItems-rowCopy') {
        return copyValue(param);
      // 편집 시작 ({ key, value })
      } else if (cmd === 'lsItems-rowEdit') {
        return startEdit(param.key, param.value);
      // 편집 저장
      } else if (cmd === 'lsItems-rowSave') {
        return saveEdit(param);
      // 행 삭제
      } else if (cmd === 'lsItems-rowDelete') {
        return handleDelete(param);
      // 리사이즈 시작
      } else if (cmd === 'lsItems-resize') {
        return startResize(param);
      } else {
        console.warn('[handleSelectAction] unknown cmd:', cmd);
      }
    };

    /* ##### [03] 초기 함수 (마운트 / 코드 로드 / watch) ############################## */

    const storageData = reactive([]);
    const uiState = reactive({ isResizing: false });


    /* loadStorageData — 로드 */
    const loadStorageData = () => {
      const data = [];
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        const value = localStorage.getItem(key);
        data.push({ key, value });
      }
      data.sort((a, b) => a.key.localeCompare(b.key));
      storageData.splice(0, storageData.length, ...data);
    };

    const cfFilteredData = computed(() => {
      const data = Array.isArray(storageData) ? storageData : [];
      if (!uiStateGlobal.filterKey) { return data; }
      return data.filter(item => item.key.toLowerCase().includes(uiStateGlobal.filterKey.toLowerCase()));
    });

    /* copyValue — 복사 */
    const copyValue = (value) => {
      try {
        navigator.clipboard.writeText(value);
        props.showToast('클립보드에 복사되었습니다.', 'success');
      } catch (e) {
        props.showToast('복사 실패: ' + e.message, 'error');
      }
    };

    /* startEdit — 시작 편집 */
    const startEdit = (key, value) => {
      uiStateGlobal.editingKey = key;
      uiStateGlobal.editingValue = value;
    };

    /* saveEdit — 저장 */
    const saveEdit = (key) => {
      if (!key) { return; }
      try {
        localStorage.setItem(key, uiStateGlobal.editingValue);
        props.showToast('저장되었습니다.', 'success');
        uiStateGlobal.editingKey = null;
        uiStateGlobal.editingValue = '';
        loadStorageData();
      } catch (e) {
        props.showToast('저장 실패: ' + e.message, 'error');
      }
    };

    /* cancelEdit — 취소 */
    const cancelEdit = () => {
      uiStateGlobal.editingKey = null;
      uiStateGlobal.editingValue = '';
    };

    /* ##### [04] 내장 사용 함수 (이벤트 핸들러 on* / handle*) #################### */

    /* handleDelete — 삭제 */
    const handleDelete = (key) => {
      if (!confirm(`'${key}'를 삭제하시겠습니까?`)) { return; }
      try {
        localStorage.removeItem(key);
        props.showToast('삭제되었습니다.', 'success');
        loadStorageData();
      } catch (e) {
        props.showToast('삭제 실패: ' + e.message, 'error');
      }
    };

    /* clearAllStorage — 비우기 */
    const clearAllStorage = () => {
      if (!confirm('localStorage의 모든 데이터를 삭제하시겠습니까?')) { return; }
      try {
        localStorage.clear();
        props.showToast('모든 데이터가 삭제되었습니다.', 'success');
        loadStorageData();
      } catch (e) {
        props.showToast('삭제 실패: ' + e.message, 'error');
      }
    };

    /* parseValue — 파싱 값 */
    const parseValue = (value) => {
      try {
        return JSON.stringify(JSON.parse(value), null, 2);
      } catch {
        return value;
      }
    };

    /* startResize — 시작 Resize */
    const startResize = (e) => {
      uiState.isResizing = true;
      uiStateGlobal.startX = e.clientX;
      uiStateGlobal.startWidth = uiStateGlobal.valueColWidth;
    };

    /* handleMouseMove — 처리 */
    const handleMouseMove = (e) => {
      if (!uiState.isResizing) { return; }
      const delta = e.clientX - uiStateGlobal.startX;
      const newWidth = Math.max(30, uiStateGlobal.startWidth + (delta / window.innerWidth * 100));
      const keyWidth = 25;
      const actionWidth = 10;
      const maxValue = 100 - keyWidth - actionWidth;
      uiStateGlobal.valueColWidth = Math.min(maxValue, newWidth);
    };

    /* stopResize — 중지 Resize */
    const stopResize = () => {
      uiState.isResizing = false;
    };
    // ★ onMounted
    /* initPage — 화면 로드 시퀀스. 마운트 시 실행한다. */
    const initPage = async () => {
      window.addEventListener('mouseup', stopResize);
    };
    onMounted(initPage);

    onUnmounted(() => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', stopResize);
    });

    loadStorageData();

    /* ##### [06] return (템플릿 노출) ############################################## */

    return {
      uiStateGlobal, uiState,       // 상태 / 데이터
      handleBtnAction, handleSelectAction, // dispatch
      cfFilteredData,
      // ===== shared (헬퍼) ====================================================
      parseValue,
    };
  },
  template: `
<div style="padding: 20px;">
  <!-- ===== ■. 본문 영역 =================================================== -->
  <div style="margin-bottom: 24px;">
    <h1 style="margin: 0 0 8px 0; font-size: 24px; font-weight: 700; color: #1a1a1a;">
      localStorage 정보 관리
    </h1>
    <p style="margin: 0; font-size: 13px; color: #666;">
      브라우저 로컬 저장소 데이터 조회 및 편집
    </p>
  </div>
  <!-- ===== □. 본문 영역 =================================================== -->
  <!-- ===== ■. 검색 및 액션 바 =============================================== -->
  <div style="background: white; border: 1px solid #e5e7eb; border-radius: 8px; padding: 16px; margin-bottom: 20px;">
    <div style="display: flex; gap: 16px; align-items: flex-end;">
      <div style="flex: 1;">
        <label style="display: block; margin-bottom: 8px; font-weight: 600; font-size: 13px; color: #333;">
          키 검색
        </label>
        <input
          v-model="uiStateGlobal.filterKey"
          type="text"
          placeholder="키로 검색..."
          style="width: 100%; padding: 10px 12px; border: 1px solid #e5e7eb; border-radius: 6px; font-size: 13px; background: white; color: #333; transition: all 0.2s;">
      </div>
      <div style="display: flex; gap: 8px;">
        <button @click="handleBtnAction('lsItems-reload')" style="padding: 10px 16px; font-size: 12px; border: 1px solid #e5e7eb; background: white; color: #666; cursor: pointer; border-radius: 6px; font-weight: 500; transition: all 0.2s;">
          🔄 새로고침
        </button>
        <button @click="handleBtnAction('lsItems-clearAll')" style="padding: 10px 16px; font-size: 12px; border: 1px solid #ffb3c1; background: #fff5f7; color: #d63384; cursor: pointer; border-radius: 6px; font-weight: 500; transition: all 0.2s;">
          🗑️ 전체 삭제
        </button>
      </div>
    </div>
  </div>
  <!-- ===== □. 검색 및 액션 바 =============================================== -->
  <!-- ===== ■. 테이블 ===================================================== -->
  <div style="background: white; border: 1px solid #e5e7eb; border-radius: 8px; overflow: hidden;">
    <div style="overflow-x: auto; position: relative; user-select: none;" :style="{ cursor: uiState.isResizing ? 'col-resize' : 'auto' }">
      <!-- ===== ■.■.■. 테이블 ================================================= -->
      <table style="width: 100%; border-collapse: collapse;">
        <thead>
          <tr style="background: #fafafa; border-bottom: 1px solid #e5e7eb;">
            <th style="width: 25%; text-align: left; padding: 12px 16px; font-weight: 600; font-size: 13px; color: #666;">
              Key
            </th>
            <th :style="{ width: uiStateGlobal.valueColWidth + '%', textAlign: 'left', padding: '12px 16px', fontWeight: '600', fontSize: '13px', color: '#666', position: 'relative' }">
              Value
              <div
                @mousedown="handleSelectAction('lsItems-resize', $event)"
                style="position: absolute; right: -5px; top: 0; width: 10px; height: 100%; cursor: col-resize; background: transparent; display: flex; align-items: center;">
                <div style="width: 1px; height: 80%; background: #ff6b9d; opacity: 0; transition: opacity 0.2s;">
                </div>
              </div>
            </th>
            <th :style="{ width: (100 - 25 - uiStateGlobal.valueColWidth) + '%', textAlign: 'center', padding: '12px 16px', fontWeight: '600', fontSize: '13px', color: '#666' }">
              작업
            </th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="item in cfFilteredData" :key="item.key" style="border-bottom: 1px solid #e5e7eb; transition: all 0.2s;">
            <td style="padding: 12px 16px; word-break: break-all; font-family: 'Monaco', 'Menlo', monospace; font-size: 12px; color: #333;">
              {{ item.key }}
            </td>
            <td style="padding: 12px 16px;">
              <template v-if="uiStateGlobal.editingKey === item.key">
                <textarea
                  :value="uiStateGlobal.editingValue"
                  @input="uiStateGlobal.editingValue = $event.target.value"
                  style="width: 100%; height: 80px; padding: 10px; border: 1.5px solid #ff6b9d; border-radius: 4px; font-family: 'Monaco', 'Menlo', monospace; font-size: 12px; resize: vertical; color: #333;">
                </textarea>
                  <div style="display: flex; gap: 8px; margin-top: 8px;">
                    <button @click="handleSelectAction('lsItems-rowSave', item.key)" style="flex: 1; padding: 6px 12px; font-size: 12px; border: none; background: linear-gradient(135deg, #ff6b9d, #c44569); color: white; cursor: pointer; border-radius: 4px; font-weight: 600; transition: all 0.2s;">
                      저장
                    </button>
                    <button @click="handleBtnAction('lsItems-editCancel')" style="flex: 1; padding: 6px 12px; font-size: 12px; border: 1px solid #e5e7eb; background: white; color: #666; cursor: pointer; border-radius: 4px; font-weight: 500; transition: all 0.2s;">
                      취소
                    </button>
                  </div>
                </template>
                <template v-else>
                  <div style="max-height: 60px; overflow-y: auto; background: #f9f9f9; padding: 10px; border-radius: 4px; font-family: 'Monaco', 'Menlo', monospace; font-size: 11px; white-space: pre-wrap; word-break: break-all; border: 1px solid #e5e7eb; color: #333;">
                    {{ parseValue(item.value) }}
                  </div>
                </template>
              </td>
              <!-- ===== ■.■.■.■.■.■. 영역 ============================================ -->
              <td style="padding: 12px 16px; text-align: center; white-space: nowrap;">
                <button @click="handleSelectAction('lsItems-rowCopy', item.value)" style="padding: 6px 10px; font-size: 11px; border: 1px solid #e5e7eb; background: white; color: #666; cursor: pointer; border-radius: 4px; font-weight: 500; margin-right: 4px; transition: all 0.2s;">
                  복사
                </button>
                <button v-if="uiStateGlobal.editingKey !== item.key" class="btn_row_edit" @click="handleSelectAction('lsItems-rowEdit', { key: item.key, value: item.value })" style="margin-right: 4px;">
                  수정
                </button>
                <button class="btn_row_delete" @click="handleSelectAction('lsItems-rowDelete', item.key)">
                  삭제
                </button>
              </td>
            </tr>
            <tr v-if="cfFilteredData.length === 0">
              <td colspan="3" style="text-align: center; padding: 40px; color: #999; font-size: 13px;">
                데이터가 없습니다.
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <!-- ===== ■.■. 푸터: 항목 수 ============================================== -->
      <div style="padding: 12px 16px; border-top: 1px solid #e5e7eb; background: #fafafa; font-size: 12px; color: #666;">
        총
        <strong>
          {{ cfFilteredData.length }}
        </strong>
        개 항목
      </div>
    </div>
  </div>
  <!-- ===== □.□. 푸터: 항목 수 ============================================== -->
  <!-- ===== □. 테이블 ===================================================== -->
`
};
