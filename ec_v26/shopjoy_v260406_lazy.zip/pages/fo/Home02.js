/* ShopJoy - Home */
window.Home02 = {
  name: 'Home',
  props: {
    navigate:      { type: Function, required: true },        // 페이지 이동
  },
  emits: [],
  setup(props) {

    /* ##### [01] 초기 변수 정의 #################################################### */

    const { reactive, computed, onMounted, onBeforeUnmount } = Vue;
    const prods             = window.foApp.prods;  // 상품 목록
    const selectProd        = (p) => window.foApp.selectProd(p);
    const toggleLike        = (id) => window.foApp.toggleLike(id);
    const isLiked           = (id) => window.foApp.isLiked?.(id) ?? false;
    const addToCart         = window.foApp.addToCart; // 장바구니 추가 (product-modal 전달용)
    const likeShake         = coUtil.cofShakeCtl();    // 좋아요 토글 흔들기 이펙트 (2초)

    const uiState = reactive({ loading: false, error: null, quickViewProduct: null, bannerIdx: 0, cartModalMode: false});


    /* -- 배너 슬라이더 -- */
    const banners = [
      { img: 'assets/cdn/prod/img/slider/slider-1.jpg', title: '나만의 스타일을', sub: '완성하세요', desc: '트렌디한 의류를 합리적인 가격으로. 색상과 사이즈를 직접 선택해 나만의 스타일을 만들어보세요.' },
      { img: 'assets/cdn/prod/img/slider/slider-2.jpg', title: '2026 S/S', sub: '신상품 컬렉션', desc: '올 봄·여름 시즌을 빛낼 새로운 컬렉션이 도착했습니다. 지금 만나보세요.' },
      { img: 'assets/cdn/prod/img/slider/slider-3.jpg', title: '특별한 혜택', sub: '시즌 세일 진행중', desc: '인기 상품 최대 50% 할인! 한정 수량으로 준비된 특별 혜택을 놓치지 마세요.' },
    ];
    /* 배너 자동 슬라이드 타이머 — coUtil.cofBannerTimer 팩토리 (start/set/stop) */
    const bannerCtl = coUtil.cofBannerTimer(i => { uiState.bannerIdx = i; }, () => uiState.bannerIdx, banners.length, 20000);

    const siteConfig = window.SITE_CONFIG || {};

    /* ##### [02] 액션 모음 (dispatch) ############################################## */

    /* handleBtnAction — 버튼 액션 dispatch (cmd: '{영역명}-기능명'). 5줄 이하 짧은 로직은 인라인 */
    const handleBtnAction = (cmd, param = {}) => {
      console.log(' ■■ Home02.js : handleBtnAction -> ', cmd, param);
      // 페이지 이동: 홈
      if (cmd === 'page-goHome') {
        return props.navigate('home');
      // 페이지 이동: 상품목록
      } else if (cmd === 'page-goProdList') {
        return props.navigate('prodList');
      // 페이지 이동: 블로그
      } else if (cmd === 'page-goBlog') {
        return props.navigate('blog');
      // 히어로 배너 인디케이터 클릭
      } else if (cmd === 'hero-set') {
        return setBanner(param);
      // 빠른보기 모달: 장바구니 모드 열기
      } else if (cmd === 'quickViewModal-openCart') {
        uiState.quickViewProduct = param; uiState.cartModalMode = true;
        return;
      // 빠른보기 모달: 미리보기 모드 열기
      } else if (cmd === 'quickViewModal-openView') {
        uiState.quickViewProduct = param; uiState.cartModalMode = false;
        return;
      // 빠른보기 모달: 닫기
      } else if (cmd === 'quickViewModal-close') {
        uiState.quickViewProduct = null; uiState.cartModalMode = false;
        return;
      } else {
        console.warn('[handleBtnAction] unknown cmd:', cmd);
      }
    };

    /* handleSelectAction — 행/선택 액션 dispatch (cmd: '{영역명}-기능명'). 5줄 이하 짧은 로직은 인라인 */
    const handleSelectAction = (cmd, param = {}, e = {}) => {
      console.log(' ■■ Home02.js : handleSelectAction -> ', cmd, param);
      // 카테고리 선택 → 상품목록 이동
      if (cmd === 'categories-rowSelect') {
        return props.navigate('prodList');
      // 상품 카드 선택
      } else if (cmd === 'prods-rowSelect') {
        if (e.ctrlKey || e.metaKey || e.button === 1) { return window.foApp.openNewWindow('prodView', param.prodId); }
        return selectProd(param);
      // 좋아요 토글
      } else if (cmd === 'prods-rowLike') {
        likeShake.fire(param);
        return toggleLike(param);
      } else {
        console.warn('[handleSelectAction] unknown cmd:', cmd);
      }
    };


    /* fnCallbackModal — 모든 모달 통합 dispatch. cmd=모달명, param=호출 시 파라미터, result=응답 결과 */
    const fnCallbackModal = (popCmd, param, result) => {
      console.log(' ■■ Home02 : fnCallbackModal -> ', popCmd, param, result);
      if (popCmd === 'quick-view') {
        if (result == null) {
          uiState.quickViewProduct = null; uiState.cartModalMode = false;
          return;
        }
        return;
      } else {
        console.warn('[fnCallbackModal] unknown popCmd:', popCmd);
      }
    };

    /* ##### [04] 내장 사용 함수 (이벤트 핸들러 on* / handle*) #################### */


    /* setBanner — 인디케이터 클릭 시 해당 배너로 + 타이머 리셋 */
    const setBanner = (i) => bannerCtl.set(i);

    // ★ onMounted — 진입 시 코드 로드 + 목록 초기 조회
    /* initPage — 화면 로드 시퀀스. 마운트 시 실행한다. */
    const initPage = async () => {
      if (!document.getElementById('home-grid-styles')) {
        const s = document.createElement('style');
        s.id = 'home-grid-styles';
        s.textContent = `
          .home-cat-grid  { display:grid; grid-template-columns:repeat(auto-fill,minmax(240px,1fr)); gap:16px; }
          .home-prod-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(220px,1fr)); gap:20px; }
          .home-sale-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(220px,1fr)); gap:20px; }
          .home-blog-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(300px,1fr)); gap:20px; }
        `;
        document.head.appendChild(s);
      }
      bannerCtl.start();
    };
    onMounted(initPage);
    onBeforeUnmount(() => bannerCtl.stop());

    /* ##### [05] 사용자 함수 (헬퍼 / 카운트 / 렌더 / 컬럼정의) #################### */



    /* -- 할인 상품 -- */
    const cfSaleProds = computed(() =>
      (prods || []).filter(p => p.originalPrice && p.priceNum && p.originalPrice > p.priceNum).slice(0, 4)
    );

    /* -- 홈 상품 8개 -- */
    const cfAllHomeProds = computed(() => {
      const all = prods || [];
      return all.slice(0, 8);
    });

    /* ##### [06] return (템플릿 노출) ############################################## */

    return {
      uiState, banners, siteConfig,       // 상태 / 데이터
      handleBtnAction, handleSelectAction, fnCallbackModal, // dispatch
      cfAllHomeProds, cfSaleProds,                         // computed
      isLiked, likeShake,                  // 헬퍼
      selectProd, toggleLike, addToCart, // 모달 전달용
    };
  },
  template: /* html */ `
<fo-page bare>
  <!-- ===== ■. ══ Site 02 Edition Ribbon ══ ============================ -->
  <div style="background:linear-gradient(135deg,#2e7d6b 0%,#4a9b7e 50%,#5b9279 100%);color:#fff;padding:14px 24px;display:flex;align-items:center;gap:14px;flex-wrap:wrap;">
    <span style="font-size:10px;letter-spacing:3px;padding:3px 10px;border:1px solid rgba(255,255,255,0.4);border-radius:2px;">
      MINT EDITION
    </span>
    <span style="font-size:13px;font-weight:600;letter-spacing:0.5px;">
      🌿 자연에서 영감받은 세이지 그린 컬렉션
    </span>
    <span style="margin-left:auto;font-size:11px;opacity:0.85;">
      FO_SITE_NO=02
    </span>
  </div>
  <!-- ===== □. ══ Site 02 Edition Ribbon ══ ============================ -->
  <!-- ===== ■. ══ Hero Banner Slider ══ ================================ -->
  <section style="position:relative;overflow:hidden;background:#f5f3f0;min-height:320px;display:flex;align-items:center;flex-wrap:wrap;">
    <!-- ===== ■.■. 좌: 텍스트 (슬라이드별) ======================================== -->
    <div style="position:relative;z-index:2;flex:1 1 260px;padding:clamp(28px,6vw,80px) clamp(20px,5vw,60px) clamp(28px,6vw,80px) clamp(20px,5vw,48px);min-width:0;">
      <h1 style="font-size:clamp(1.4rem,3.5vw,2.6rem);font-weight:300;line-height:1.3;color:#1a1a1a;margin-bottom:16px;letter-spacing:-0.5px;">
        {{ banners[uiState.bannerIdx].title }}
        <br>
        <span style="font-weight:700;">
          {{ banners[uiState.bannerIdx].sub }}
        </span>
      </h1>
      <p style="font-size:0.85rem;color:#888;line-height:1.8;margin-bottom:28px;max-width:360px;">
        {{ banners[uiState.bannerIdx].desc }}
      </p>
      <button @click="handleBtnAction('page-goProdList')"
        style="padding:12px 28px;font-size:0.82rem;font-weight:600;letter-spacing:1px;text-transform:uppercase;border:1.5px solid #1a1a1a;background:transparent;color:#1a1a1a;cursor:pointer;transition:all .25s;"
        @mouseenter="$event.target.style.background='#1a1a1a';$event.target.style.color='#fff'"
        @mouseleave="$event.target.style.background='transparent';$event.target.style.color='#1a1a1a'">
        쇼핑 시작하기
      </button>
      <!-- ===== ■.■.■. 인디케이터 (클릭 가능) ======================================= -->
      <div style="display:flex;gap:8px;margin-top:28px;">
        <span v-for="(b, i) in banners" :key="i" @click="handleBtnAction('hero-set', i)"
          :style="{
          width: '24px', height: '3px', borderRadius: '2px', cursor: 'pointer', transition: 'background .3s',
          background: uiState.bannerIdx === i ? '#1a1a1a' : '#ccc',
          }">
        </span>
      </div>
    </div>
    <!-- ===== □.□. 좌: 텍스트 (슬라이드별) ======================================== -->
    <!-- ===== ■.■. 우: 이미지 (페이드 전환) ======================================= -->
    <div style="flex:1 1 160px;position:relative;min-height:280px;display:flex;align-items:center;justify-content:center;overflow:hidden;">
      <img v-for="(b, i) in banners" :key="i" :src="b.img" :alt="b.title"
        :style="{
        position: i === 0 ? 'relative' : 'absolute',
        maxHeight: '420px', maxWidth: '100%', objectFit: 'contain', zIndex: 1,
        opacity: uiState.bannerIdx === i ? '1' : '0',
        transition: 'opacity 0.8s ease',
        }" />
    </div>
  </section>
  <!-- ===== □.□. 우: 이미지 (페이드 전환) ======================================= -->
  <!-- ===== □. ══ Hero Banner Slider ══ ================================ -->
  <!-- ===== ■. ══ Category Cards (Outstock 스타일) ══ ===================== -->
  <div style="padding:0 clamp(12px,3vw,32px);margin:-40px auto 0;max-width:820px;position:relative;z-index:3;">
    <div class="home-cat-grid">
      <div v-for="(cat, ci) in (siteConfig.categorys || []).slice(0,3)" :key="cat.categoryId"
        @click="handleSelectAction('categories-rowSelect', cat)"
        style="background:#fff;border-radius:14px;padding:clamp(14px,3vw,24px);cursor:pointer;box-shadow:0 4px 24px rgba(0,0,0,0.09);display:flex;align-items:center;gap:clamp(10px,2vw,20px);transition:transform .2s,box-shadow .2s;"
        @mouseenter="$event.currentTarget.style.transform='translateY(-3px)';$event.currentTarget.style.boxShadow='0 8px 30px rgba(0,0,0,0.14)'"
        @mouseleave="$event.currentTarget.style.transform='';$event.currentTarget.style.boxShadow='0 4px 24px rgba(0,0,0,0.09)'">
        <div style="width:clamp(56px,8vw,88px);height:clamp(56px,8vw,88px);border-radius:50%;overflow:hidden;flex-shrink:0;background:var(--bg-base);">
          <img :src="'assets/cdn/prod/img/shop/prod/sm/pro-sm-' + (ci*3+1) + '.jpg'" style="width:100%;height:100%;object-fit:cover;" />
        </div>
        <div>
          <div style="font-size:clamp(0.88rem,2vw,1.05rem);font-weight:700;color:#1a1a1a;margin-bottom:4px;">
            {{ cat.categoryNm }}
          </div>
          <div style="font-size:clamp(0.7rem,1.5vw,0.8rem);color:#999;">
            바로가기 →
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- ===== □. ══ Category Cards (Outstock 스타일) ══ ===================== -->
  <!-- ===== ■. ══ 인기 상품 (8개) ══ ======================================== -->
  <div style="max-width:1080px;margin:0 auto;padding:48px clamp(12px,3vw,32px) 40px;">
    <div style="text-align:center;margin-bottom:28px;">
      <h2 style="font-size:1.5rem;font-weight:700;color:#1a1a1a;margin-bottom:8px;">
        인기 상품
      </h2>
      <p style="font-size:0.85rem;color:#999;">
        고객들이 사랑하는 트렌디한 아이템을 만나보세요
      </p>
    </div>
    <div class="home-prod-grid">
      <div v-for="p in cfAllHomeProds" :key="p.prodId"
        style="cursor:pointer;transition:transform .25s,box-shadow .25s;" title="Ctrl+클릭: 새창"
        @mouseenter="$event.currentTarget.style.transform='translateY(-6px)';$event.currentTarget.style.boxShadow='0 8px 24px rgba(0,0,0,0.1)'"
        @mouseleave="$event.currentTarget.style.transform='';$event.currentTarget.style.boxShadow=''"
        @click="handleSelectAction('prods-rowSelect', p, $event)"
        @auxclick="$event.button===1 ? handleSelectAction('prods-rowSelect', p, $event) : null">
        <div style="background:#f5f5f5;padding:24px;margin-bottom:14px;overflow:hidden;position:relative;aspect-ratio:1;"
          @mouseenter="$event.currentTarget.querySelector('.prod-hover').style.opacity='1'"
          @mouseleave="$event.currentTarget.querySelector('.prod-hover').style.opacity='0'">
          <img :src="p.image || window.NO_IMAGE" :alt="p.prodNm" style="width:100%;height:100%;object-fit:contain;" />
          <span v-if="p.badge" style="position:absolute;top:10px;left:10px;font-size:0.68rem;font-weight:600;padding:3px 8px;border-radius:2px;"
            :style="{ background: p.badge==='NEW' ? '#1a1a1a' : '#8b7355', color:'#fff' }">
            {{ p.badge }}
          </span>
          <!-- ===== ■.■.■.■.■. 좋아요 (좋아요 상태면 항상 표시) ============================= -->
          <button @click.stop="handleSelectAction('prods-rowLike', p.prodId)"
            :class="{ 'fo-shake': likeShake.isActive(p.prodId) }"
            :style="{ position:'absolute', right:'12px', top:'12px', width:'32px', height:'32px', borderRadius:'50%', border:'none', background:'transparent', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', zIndex:2 }"
            class="prod-like" title="위시리스트">
            <svg width="16" height="16" viewBox="0 0 24 24" :fill="isLiked(p.prodId)?'#ef4444':'none'" :stroke="isLiked(p.prodId)?'#ef4444':'#555'" stroke-width="2">
              <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z">
              </path>
            </svg>
          </button>
          <!-- ===== ■.■.■.■.■. 장바구니 + 빠른보기 (hover 시에만) ========================= -->
          <div class="prod-hover" style="opacity:0;transition:opacity .25s;position:absolute;right:12px;top:48px;display:flex;flex-direction:column;gap:6px;">
            <button @click.stop="handleBtnAction('quickViewModal-openCart', p)" style="width:32px;height:32px;border-radius:50%;border:none;background:transparent;cursor:pointer;display:flex;align-items:center;justify-content:center;" title="장바구니">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#555" stroke-width="2">
                <circle cx="9" cy="21" r="1">
                </circle>
                <circle cx="20" cy="21" r="1">
                </circle>
                <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6">
                </path>
              </svg>
            </button>
            <button @click.stop="handleBtnAction('quickViewModal-openView', p)" style="width:32px;height:32px;border-radius:50%;border:none;background:transparent;cursor:pointer;display:flex;align-items:center;justify-content:center;" title="빠른보기">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#555" stroke-width="2">
                <circle cx="11" cy="11" r="8">
                </circle>
                <line x1="21" y1="21" x2="16.65" y2="16.65">
                </line>
              </svg>
            </button>
          </div>
        </div>
        <div style="font-size:0.88rem;font-weight:500;color:#1a1a1a;margin-bottom:4px;">
          {{ p.prodNm }}
        </div>
        <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;">
          <span style="font-size:0.88rem;font-weight:700;color:#1a1a1a;">
            {{ p.price }}
          </span>
          <span v-if="p.originalPrice" style="font-size:0.78rem;color:#bbb;text-decoration:line-through;">
            {{ p.originalPrice.toLocaleString ? p.originalPrice.toLocaleString() + '원' : p.originalPrice }}
          </span>
          <span v-if="p.originalPrice ? p.priceNum : false" style="font-size:0.75rem;font-weight:700;color:#ef4444;">
          {{ Math.round((1 - p.priceNum / p.originalPrice) * 100) }}%
        </span>
      </div>
    </div>
  </div>
  <div style="text-align:center;margin-top:32px;">
    <button @click="handleBtnAction('page-goProdList')"
        style="padding:12px 40px;font-size:0.82rem;font-weight:600;letter-spacing:0.5px;border:1.5px solid #ddd;background:transparent;color:#666;cursor:pointer;transition:all .2s;"
        @mouseenter="$event.target.style.borderColor='#1a1a1a';$event.target.style.color='#1a1a1a'"
        @mouseleave="$event.target.style.borderColor='#ddd';$event.target.style.color='#666'">
      더 보기
    </button>
  </div>
</div>
<!-- ===== □. ══ 인기 상품 (8개) ══ ======================================== -->
<!-- ===== ■. ══ 2열 프로모션 배너 ══ ======================================== -->
<div style="max-width:1100px;margin:0 auto;padding:0 clamp(12px,3vw,32px) 48px;">
  <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:clamp(12px,2vw,24px);">
    <!-- ===== ■.■.■. 배너 1 ================================================ -->
    <div style="position:relative;overflow:hidden;border-radius:4px;display:flex;align-items:flex-end;min-height:300px;">
      <img src="assets/cdn/prod/img/shop/banner/banner-big-1.jpg" alt="프로모션"
          style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;" />
      <div style="position:relative;z-index:1;padding:40px;background:linear-gradient(to top,rgba(0,0,0,0.55) 0%,transparent 100%);width:100%;">
        <div style="font-size:0.72rem;color:rgba(255,255,255,0.7);margin-bottom:8px;letter-spacing:1px;text-transform:uppercase;">
          프리미엄 컬렉션
        </div>
        <h3 style="font-size:1.5rem;font-weight:700;color:#fff;margin-bottom:10px;line-height:1.3;">
          핸드메이드
          <br>
          프리미엄 아이템
        </h3>
        <p style="font-size:0.85rem;color:rgba(255,255,255,0.8);margin-bottom:20px;line-height:1.6;">
          장인의 손길이 담긴
          <br>
          특별한 컬렉션을 만나보세요.
        </p>
        <button @click="handleBtnAction('page-goProdList')"
            style="padding:10px 24px;font-size:0.8rem;font-weight:600;border:1.5px solid #fff;background:transparent;color:#fff;cursor:pointer;transition:all .2s;"
            @mouseenter="$event.target.style.background='#fff';$event.target.style.color='#1a1a1a'"
            @mouseleave="$event.target.style.background='transparent';$event.target.style.color='#fff'">
          쇼핑하기 →
        </button>
      </div>
    </div>
    <!-- ===== ■.■.■. 배너 2 ================================================ -->
    <div style="position:relative;overflow:hidden;border-radius:4px;display:flex;align-items:flex-end;min-height:300px;">
      <img src="assets/cdn/prod/img/shop/banner/banner-big-2.jpg" alt="프로모션"
          style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;" />
      <div style="position:relative;z-index:1;padding:40px;background:linear-gradient(to top,rgba(0,0,0,0.55) 0%,transparent 100%);width:100%;">
        <div style="font-size:0.72rem;color:rgba(255,255,255,0.7);margin-bottom:8px;letter-spacing:1px;text-transform:uppercase;">
          시즌 한정 상품
        </div>
        <h3 style="font-size:1.5rem;font-weight:700;color:#fff;margin-bottom:10px;line-height:1.3;">
          2026 S/S
          <br>
          신상품 컬렉션
        </h3>
        <p style="font-size:0.85rem;color:rgba(255,255,255,0.8);margin-bottom:20px;line-height:1.6;">
          올 봄·여름 시즌을 빛낼
          <br>
          새로운 아이템이 도착했습니다.
        </p>
        <button @click="handleBtnAction('page-goProdList')"
            style="padding:10px 24px;font-size:0.8rem;font-weight:600;border:1.5px solid #fff;background:transparent;color:#fff;cursor:pointer;transition:all .2s;"
            @mouseenter="$event.target.style.background='#fff';$event.target.style.color='#1a1a1a'"
            @mouseleave="$event.target.style.background='transparent';$event.target.style.color='#fff'">
          쇼핑하기 →
        </button>
      </div>
    </div>
  </div>
</div>
<!-- ===== □. ══ 2열 프로모션 배너 ══ ======================================== -->
<!-- ===== ■. ══ 할인 상품 (Sale Off) ══ ================================== -->
<div style="max-width:1080px;margin:0 auto;padding:0 clamp(12px,3vw,32px) 40px;">
  <div style="text-align:center;margin-bottom:28px;">
    <h2 style="font-size:1.5rem;font-weight:700;color:#1a1a1a;font-style:italic;margin-bottom:8px;">
      할인 상품
    </h2>
    <p style="font-size:0.85rem;color:#999;">
      특별 할인 중인 인기 상품을 놓치지 마세요
    </p>
  </div>
  <div class="home-sale-grid">
    <div v-for="p in cfSaleProds" :key="'sale'+p.prodId"
        style="cursor:pointer;text-align:center;transition:transform .25s;" title="Ctrl+클릭: 새창"
        @mouseenter="$event.currentTarget.style.transform='translateY(-4px)'"
        @mouseleave="$event.currentTarget.style.transform=''"
        @click="handleSelectAction('prods-rowSelect', p, $event)"
        @auxclick="$event.button===1 ? handleSelectAction('prods-rowSelect', p, $event) : null">
      <div style="background:#f5f5f5;padding:20px;margin-bottom:12px;position:relative;aspect-ratio:1;overflow:hidden;">
        <img :src="p.image || window.NO_IMAGE" :alt="p.prodNm" style="width:100%;height:100%;object-fit:contain;" />
        <span v-if="p.originalPrice ? p.priceNum : false" style="position:absolute;top:8px;left:8px;font-size:0.68rem;font-weight:700;padding:3px 8px;border-radius:2px;background:#ef4444;color:#fff;">
        -{{ Math.round((1 - p.priceNum / p.originalPrice) * 100) }}%
      </span>
    </div>
    <div style="font-size:0.85rem;font-weight:500;color:#1a1a1a;margin-bottom:4px;">
      {{ p.prodNm }}
    </div>
    <div style="display:flex;align-items:center;justify-content:center;gap:6px;">
      <span style="font-size:0.85rem;font-weight:700;color:#1a1a1a;">
        {{ p.price }}
      </span>
      <span style="font-size:0.75rem;color:#bbb;text-decoration:line-through;">
        {{ p.originalPrice.toLocaleString ? p.originalPrice.toLocaleString() + '원' : p.originalPrice }}
      </span>
    </div>
  </div>
</div>
</div>
<!-- ===== □. ══ 할인 상품 (Sale Off) ══ ================================== -->
<!-- ===== ■. ══ 브랜드 로고 ══ ============================================ -->
<div style="max-width:900px;margin:0 auto;padding:20px clamp(12px,3vw,32px) 40px;border-top:1px solid #eee;border-bottom:1px solid #eee;">
  <div style="display:flex;align-items:center;justify-content:center;gap:clamp(20px,5vw,48px);flex-wrap:wrap;opacity:0.45;">
    <img v-for="i in 5" :key="i" :src="'assets/cdn/prod/img/client/brand-' + i + '.webp'" style="height:30px;object-fit:contain;filter:grayscale(1);" />
  </div>
</div>
<!-- ===== □. ══ 브랜드 로고 ══ ============================================ -->
<!-- ===== ■. ══ 블로그 포스트 ══ =========================================== -->
<div style="max-width:1080px;margin:0 auto;padding:40px clamp(12px,3vw,32px) 48px;">
  <div style="text-align:center;margin-bottom:28px;">
    <h2 style="font-size:1.5rem;font-weight:700;color:#1a1a1a;font-style:italic;margin-bottom:8px;">
      블로그
    </h2>
    <p style="font-size:0.85rem;color:#999;">
      스타일링 팁과 패션 트렌드를 확인해보세요
    </p>
  </div>
  <div class="home-blog-grid">
    <div v-for="i in 3" :key="'blog'+i"
        style="cursor:pointer;transition:transform .25s;"
        @mouseenter="$event.currentTarget.style.transform='translateY(-4px)'"
        @mouseleave="$event.currentTarget.style.transform=''"
        @click="handleBtnAction('page-goBlog')">
      <div style="aspect-ratio:4/3;overflow:hidden;border-radius:4px;margin-bottom:14px;">
        <img :src="'assets/cdn/prod/img/blog/blog-' + i + '.jpg'" :alt="'블로그 ' + i"
            style="width:100%;height:100%;object-fit:cover;transition:transform .3s;"
            @mouseenter="$event.target.style.transform='scale(1.05)'"
            @mouseleave="$event.target.style.transform=''" />
      </div>
      <div style="font-size:0.72rem;color:#999;margin-bottom:6px;">
        {{ ['2026.04.10', '2026.04.08', '2026.04.05'][i-1] }}
      </div>
      <h3 style="font-size:0.95rem;font-weight:600;color:#1a1a1a;margin-bottom:8px;line-height:1.4;">
        {{ ['봄 시즌 스타일링 가이드', '트렌드 컬러 활용법', '미니멀 옷장 정리법'][i-1] }}
      </h3>
      <p style="font-size:0.8rem;color:#888;line-height:1.6;margin-bottom:12px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;">
        {{ ['올봄 트렌디한 코디를 완성하는 핵심 아이템과 스타일링 팁을 소개합니다.', '시즌 컬러를 활용한 다양한 코디 방법을 알아봅니다.', '효율적인 옷장 정리법과 캡슐 워드로브 구성 팁을 공개합니다.'][i-1] }}
      </p>
      <span style="font-size:0.78rem;font-weight:600;color:#1a1a1a;text-decoration:underline;">
        자세히 보기 →
      </span>
    </div>
  </div>
</div>
<!-- ===== □. ══ 블로그 포스트 ══ =========================================== -->
<!-- ===== ■. ══ 빠른보기 모달 (ProductModal 컴포넌트) ══ ======================= -->
<product-modal :show="!!uiState.quickViewProduct" :product="uiState.quickViewProduct" :cart-mode="uiState.cartModalMode" :navigate="(page, opts) => { if(opts?.instantOrder){ navigate('order',opts); uiState.quickViewProduct=null; } else { selectProd(uiState.quickViewProduct); uiState.quickViewProduct=null; } }" :toggle-like="toggleLike" :is-liked="isLiked" :add-to-cart="addToCart" modal-name="quick-view" :on-callback="fnCallbackModal" />
</fo-page>
<!-- ===== □. ══ 빠른보기 모달 (ProductModal 컴포넌트) ══ ======================= -->
`
};
