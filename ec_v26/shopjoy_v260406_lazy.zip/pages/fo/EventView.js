﻿/* ShopJoy - EventView (이벤트 상세) */
window.EventView = {
  name: 'EventView',
  props: {
    navigate: { type: Function, required: true },        // 페이지 이동
    dtlId:    { type: String,   default: null },          // 대상 ID
  },
  setup(props) {

    /* ##### [01] 초기 변수 정의 ################################################## */

    const { reactive, computed, onMounted } = Vue;

    const uiState = reactive({ loading: false, error: null });

    /* -- 이벤트 데이터 -- */
    const events = reactive([]);

    /* ##### [02] 액션 모음 (dispatch) ############################################## */

    /* handleBtnAction — 버튼 액션 dispatch (cmd: '{영역명}-기능명'). 5줄 이하 짧은 로직은 인라인 */
    const handleBtnAction = (cmd, param = {}) => {
      console.log(' ■■ EventView.js : handleBtnAction -> ', cmd, param);
      // 이벤트 목록으로 이동
      if (cmd === 'page-goEventList') {
        return props.navigate('event');
      // 탭 변경 (param: 탭 인덱스)
      } else if (cmd === 'tab-change') {
        uiState.activeTab = param;
        return;
      } else {
        console.warn('[handleBtnAction] unknown cmd:', cmd);
      }
    };

    /* handleSelectAction — 행/선택 액션 dispatch (cmd: '{영역명}-기능명'). 5줄 이하 짧은 로직은 인라인 */
    const handleSelectAction = (cmd, param = {}) => {
      console.log(' ■■ EventView.js : handleSelectAction -> ', cmd, param);
      // 관련 이벤트 카드 클릭 (param: eventId)
      if (cmd === 'relatedEvents-rowView') {
        return props.navigate('eventView', { eventId: param });
      } else {
        console.warn('[handleSelectAction] unknown cmd:', cmd);
      }
    };

    /* ##### [04] 내장 사용 함수 (이벤트 핸들러 on* / handle*) #################### */

    /* handleSearchData — 처리 */
    const handleSearchData = async (searchType = 'DEFAULT') => {
      try {
        const res = await foApiSvc.pmEvent.getById(props.dtlId, '이벤트상세', '상세조회');
        const raw = res.data?.data || null;
        events.splice(0, events.length, ...(raw ? [raw] : []));
        /* 구글봇은 JS 실행 후 최종 DOM 을 읽으므로, 이벤트/기획전별 title/description 을
           렌더에 맞춰 교체해 둔다 — 페이지 이탈 시 foAppBase.js 의 watch(page) 가 공통값으로 되돌린다 */
        if (raw) {
          const nm = raw.eventTitle || raw.eventNm || '';
          foUtil.fofSetPageMeta({
            title: nm ? nm + ' | ShopJoy' : undefined,
            description: raw.eventDesc || (nm ? nm + ' - ShopJoy 이벤트/기획전' : undefined),
          });
        }
      } catch (e) {
        console.error('[handleSearchData]', e);
        events.splice(0, events.length);
      }
    };



    /* 백엔드 PmEventDto.Item → 화면 표준 형태로 정규화 (benefits/eventItems 연관정보 포함) */
    const cfEvent    = computed(() => {
      const raw = events.length > 0 ? events[0] : null;
      if (!raw) { return null; }
      return {
        id:            raw.eventId,
        title:         raw.eventTitle || raw.eventNm || '',
        heroEyebrow:   raw.eventTypeCd || 'EVENT',
        heroSub:       raw.eventDesc || '',
        heroBg:        'linear-gradient(135deg,#5b6cff 0%,#8a4fff 100%)',
        heroTextColor: '#ffffff',
        startDate:     (raw.startDate || '').toString().slice(0, 10),
        endDate:       (raw.endDate || '').toString().slice(0, 10),
        body:          raw.eventContent || '',
        /* PmEventBenefitDto.Item → 카드 표시 */
        benefits:      (raw.benefits || []).map(b => ({
                         label: b.benefitNm || b.benefitTypeCd || '혜택',
                         value: b.benefitValue || '',
                         desc:  b.conditionDesc || '',
                         btn:   '자세히',
                       })),
        /* PmEventItemDto.Item → 대상 상품/대상 목록 */
        eventItems:    (raw.eventItems || []).map(it => ({
                         id:         it.eventItemId,
                         targetType: it.targetTypeCd || '',
                         targetId:   it.targetId || '',
                       })),
        notice:        (raw.eventDesc || '').split('\n').filter(Boolean),
      };
    });


    /* initPage — 화면 로드 시퀀스. 마운트 시 실행한다. */
    /* initPage — 화면 로드 시퀀스.
       ID 없이 진입하면(직접 URL 입력 등) 조회가 실패해 본문이 통째로 빈 화면이 된다.
       빈 껍데기를 보여주는 대신 목록으로 돌려보낸다. */
    const initPage = async () => {
      if (!props.dtlId) { props.navigate('event'); return; }
      await handleSearchData();
    };
    onMounted(initPage);

    /* ##### [06] return (템플릿 노출) ############################################## */

    return {
      handleBtnAction, handleSelectAction, // dispatch
      cfEvent, // computed
    };
  },

  template: /* html */ `
<fo-page v-if="cfEvent" bare style="background:var(--bg-base);"
  @nav="p => navigate(p)">
  <!-- ===== ■. ① 히어로 배너 (동적 데이터 → #banner 슬롯 유지) ================ -->
  <template #banner>
  <div :style="{
    background: cfEvent.heroBg,
    minHeight: '400px',
    display:'flex', flexDirection:'column',
    alignItems:'center', justifyContent:'center',
    textAlign:'center', padding:'clamp(40px,8vw,72px) clamp(16px,4vw,24px) clamp(32px,6vw,60px)',
    position:'relative', overflow:'hidden',
    }">
    <!-- ===== ■.■. 장식 원 ================================================== -->
    <div style="position:absolute;top:-60px;right:-60px;width:240px;height:240px;border-radius:50%;background:rgba(255,255,255,0.18);">
    </div>
    <div style="position:absolute;bottom:-40px;left:-40px;width:160px;height:160px;border-radius:50%;background:rgba(255,255,255,0.12);">
    </div>
    <div style="position:relative;z-index:1;max-width:700px;">
      <div style="display:inline-block;padding:4px 16px;border-radius:20px;border:1px solid currentColor;font-size:0.72rem;font-weight:700;letter-spacing:2px;margin-bottom:20px;opacity:0.8;"
        :style="{ color: cfEvent.heroTextColor }">
        {{ cfEvent.heroEyebrow }}
      </div>
      <h1 style="font-size:2.6rem;font-weight:900;line-height:1.25;margin-bottom:18px;letter-spacing:-0.5px;"
        :style="{ color: cfEvent.heroTextColor }">
        {{ cfEvent.title }}
      </h1>
      <p style="font-size:0.95rem;line-height:1.7;opacity:0.8;margin-bottom:24px;"
        :style="{ color: cfEvent.heroTextColor }">
        {{ cfEvent.heroSub }}
      </p>
      <div style="font-size:0.82rem;font-weight:600;opacity:0.65;"
        :style="{ color: cfEvent.heroTextColor }">
        {{ cfEvent.startDate }} ~ {{ cfEvent.endDate }}
      </div>
    </div>
  </div>
  </template>
  <!-- ===== □.□. 장식 원 ================================================== -->
  <!-- ===== □. ① 히어로 배너 ================================================ -->
  <!-- ===== ■. 영역 ====================================================== -->
  <div class="page-wrap" style="max-width:960px;">
    <!-- ===== ■.■. ② 뒤로 ================================================== -->
    <button @click="handleBtnAction('page-goEventList')"
      style="display:flex;align-items:center;gap:6px;background:none;border:none;cursor:pointer;color:var(--text-muted);font-size:0.82rem;margin-bottom:32px;padding:0;"
      @mouseenter="$event.currentTarget.style.color='var(--blue)'"
      @mouseleave="$event.currentTarget.style.color='var(--text-muted)'">
      ← 이벤트 목록으로
    </button>
    <!-- ===== □.□. ② 뒤로 ================================================== -->
    <!-- ===== ■.■. ③ 혜택 카드 =============================================== -->
    <div style="background:var(--bg-card);border:1px solid var(--border);border-radius:16px;padding:clamp(20px,4vw,36px) clamp(16px,3vw,32px);margin-bottom:36px;text-align:center;">
      <div style="font-size:0.72rem;font-weight:700;color:var(--blue);letter-spacing:2px;margin-bottom:10px;">
        SHOPJOY BENEFIT
      </div>
      <h2 style="font-size:1.4rem;font-weight:900;color:var(--text-primary);margin-bottom:6px;">
        이벤트 혜택
      </h2>
      <p style="font-size:0.85rem;color:var(--text-muted);margin-bottom:28px;">
        {{ cfEvent.heroSub }}
      </p>
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:16px;">
        <div v-for="(b, bi) in cfEvent.benefits" :key="bi"
          style="border:1px solid var(--border);border-radius:12px;padding:24px 16px;">
          <div style="font-size:0.75rem;color:var(--text-muted);margin-bottom:10px;">
            {{ b.label }}
          </div>
          <div style="font-size:1.45rem;font-weight:900;color:var(--text-primary);margin-bottom:8px;">
            {{ b.value }}
          </div>
          <div v-if="b.desc" style="font-size:0.74rem;color:var(--text-muted);margin-bottom:16px;line-height:1.5;">
            {{ b.desc }}
          </div>
          <button class="btn-blue" style="padding:9px 28px;font-size:0.82rem;border-radius:6px;border:none;cursor:pointer;">
            {{ b.btn }}
          </button>
        </div>
      </div>
    </div>
    <!-- ===== □.□. ③ 혜택 카드 =============================================== -->
    <!-- ===== ■.■. ④ 이벤트 대상 (eventItems) ================================= -->
    <div v-if="cfEvent.eventItems?.length" style="margin-bottom:36px;">
    <h2 style="font-size:1.1rem;font-weight:800;color:var(--text-primary);margin-bottom:18px;">
      이벤트 대상
    </h2>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:14px;">
      <div v-for="it in cfEvent.eventItems" :key="it.id"
          style="background:var(--bg-card);border:1px solid var(--border);border-radius:6px;padding:16px;">
        <div style="font-size:0.72rem;color:var(--text-muted);margin-bottom:6px;">
          {{ it.targetType }}
        </div>
        <div style="font-size:0.88rem;font-weight:700;color:var(--text-primary);word-break:break-all;">
          {{ it.targetId }}
        </div>
      </div>
    </div>
  </div>
  <!-- ===== □.□. ④ 이벤트 대상 (eventItems) ================================= -->
  <!-- ===== □.□. ⑤ 더 많은 프로모션 (단건 상세만 제공, 미사용) =================== -->
  <!-- ===== ■.■. ⑥ 유의사항 ================================================ -->
  <div style="background:var(--bg-base);border:1px solid var(--border);border-radius:12px;padding:clamp(16px,3vw,24px) clamp(16px,3vw,28px);margin-bottom:32px;">
    <h3 style="font-size:0.85rem;font-weight:700;color:var(--text-secondary);margin-bottom:14px;">
      유의사항
    </h3>
    <ul style="list-style:none;padding:0;margin:0;">
      <li v-for="(line, li) in cfEvent.notice" :key="li"
          style="font-size:0.8rem;color:var(--text-muted);line-height:1.9;padding-left:14px;position:relative;">
        <span style="position:absolute;left:0;">
          ·
        </span>
        {{ line }}
      </li>
    </ul>
  </div>
  <!-- ===== □.□. ⑥ 유의사항 ================================================ -->
  <!-- ===== ■.■. 목록으로 (하단) ============================================= -->
  <div style="text-align:center;padding-bottom:8px;">
    <button @click="handleBtnAction('page-goEventList')"
        style="padding:11px 32px;border:1px solid var(--border);border-radius:8px;background:var(--bg-card);color:var(--text-secondary);font-size:0.85rem;cursor:pointer;font-weight:600;"
        @mouseenter="$event.currentTarget.style.borderColor='var(--blue)';$event.currentTarget.style.color='var(--blue)'"
        @mouseleave="$event.currentTarget.style.borderColor='var(--border)';$event.currentTarget.style.color='var(--text-secondary)'">
      ← 이벤트 목록으로
    </button>
  </div>
</div>
</fo-page>
<!-- ===== □.□. 목록으로 (하단) ============================================= -->
<!-- ===== □. 영역 ====================================================== -->
`,
};
