/* ShopJoy - My 쿠폰 페이지 (?page=myCoupon) */
window.MyCoupon = {
  name: 'MyCoupon',
  props: {
    navigate:  { type: Function, required: true },        // 페이지 이동
  },
  setup(props) {

    /* ##### [01] 초기 변수 정의 ################################################## */

    const { reactive, computed, onMounted, watch } = Vue;
    const showToast            = window.foApp.showToast;  // 토스트 알림
    const cart                 = window.foApp.cart;  // 장바구니

    const uiState = reactive({ loading: false, error: null, activeTab: 'unused'});


    /* ##### [02] 액션 모음 (dispatch) ############################################## */

    /* handleBtnAction — 버튼 액션 dispatch (cmd: '{영역명}-기능명'). 5줄 이하 짧은 로직은 인라인 */
    const handleBtnAction = (cmd, param = {}) => {
      console.log(' ■■ MyCoupon.js : handleBtnAction -> ', cmd, param);
      // 쿠폰 등록
      if (cmd === 'coupons-add') {
        return addCoupon();
      // 탭 변경 (미사용/사용)
      } else if (cmd === 'coupons-tabChange') {
        return onTabChange(param);
      } else {
        console.warn('[handleBtnAction] unknown cmd:', cmd);
      }
    };

    /* ##### [03] 초기 함수 (마운트 / 코드 로드 / watch) ############################## */


    const myStore = window.useFoMyStore();
    const { coupons, couponCode } = Pinia.storeToRefs(myStore);

    const pager = reactive({ pageType: 'PAGE', pageNo: 1, pageSize: 50, pageTotalCount: 0, pageTotalPage: 1, pageSizes: [5, 10, 20, 30, 50, 100, 200, 500], pageCond: {} });

    /* -- 탭: 미사용 | 사용 -- */
     // 'unused' | 'used'

    /* -- 날짜 필터 (서버 처리) -- */
    const { dateRange, onDateSearch } = window.myDateFilterHelper();

    /* 미사용/사용 탭 — 현재 페이지(서버 응답) 안에서의 표시 구분.
     *   ⚠️ used 플래그는 쿠폰 마스터(couponStatusCd ACTIVE/INACTIVE/EXPIRED) 기반 파생값이며
     *   쿠폰 목록 API 가 회원별 사용여부(pm_coupon_usage)를 join 하지 않으므로 서버 단일 코드로
     *   정밀 필터가 불가. 따라서 탭은 서버 페이지를 받은 뒤의 클라이언트 표시 구분으로만 사용한다
     *   (페이징/검색은 서버사이드, 탭 전환 시에도 1페이지부터 서버 재조회). */
    const cfPageCoupons = computed(() =>
      coupons.value.filter(c => uiState.activeTab === 'unused' ? !c.used : c.used)
    );
    const cfUnusedCount = computed(() => coupons.value.filter(c => !c.used).length);
    const cfUsedCount   = computed(() => coupons.value.filter(c => c.used).length);

    /* addCoupon — 추가 */
    const addCoupon = () => {
      const code = couponCode.value.trim().toUpperCase();
      if (!code) { showToast('쿠폰 코드를 입력하세요.', 'error'); return; }
      if (coupons.value.find(c => c.code === code)) { showToast('이미 등록된 쿠폰입니다.', 'error'); return; }
      coupons.value.unshift({
        couponId: Date.now(), code, name: '추가 쿠폰 (' + code + ')',
        discountType: 'amount', discountValue: 3000, minOrder: 30000,
        expiry: '2026-12-31', used: false,
        regDate: coUtil.cofToYmd(new Date()), regSource: '쿠폰 코드 입력', regMethod: '수동',
      });
      couponCode.value = ''; pager.pageNo = 1;
      showToast('쿠폰이 등록되었습니다!', 'success');
    };

    /* ##### [04] 내장 사용 함수 (이벤트 핸들러 on* / handle*) #################### */

    /* fnBuildParams — 현재 검색조건(기간) → 서버 파라미터 */
    const fnBuildParams = () => ({ dateRangeType: 'reg_date', dateRangeStart: dateRange.start, dateRangeEnd: dateRange.end });

    /* handleLoadPage — 서버사이드 페이징 조회 (현재 pager.pageNo/pageSize 기준) */
    const handleLoadPage = async () => {
      await myStore.handleLoadCouponsPage(fnBuildParams(), pager);
    };

    /* onTabChange — 탭 변경 → 1페이지로 리셋 후 서버 재조회 (검색/페이징 정책) */
    const onTabChange = async (tab) => { uiState.activeTab = tab; pager.pageNo = 1; await handleLoadPage(); };

    /* onSearch — 조회 (기간 변경 시) → 1페이지로 리셋 후 서버 재조회 */
    const onSearch = async (dateParams) => {
      if (dateParams) { onDateSearch(dateParams); }
      pager.pageNo = 1;
      await handleLoadPage();
      myStore.handleLoadOrders();
    };

    /* onPageChange — 페이지 버튼 클릭 → 서버 재조회 (페이징 정책) */
    const onPageChange = async () => { await handleLoadPage(); };

    /* onSizeChange — 페이지크기 변경 → 서버 재조회 */
    const onSizeChange = async () => { await handleLoadPage(); };


    /* initPage — 화면 로드 시퀀스. 마운트 시 실행한다. */
    const initPage = async () => {
      await handleLoadPage();
      myStore.handleLoadOrders();
    };
    onMounted(initPage);

    /* ##### [06] return (템플릿 노출) ############################################## */

    const cartCount = computed(() => cart.length);

    return {
      uiState,       // 상태 / 데이터
      handleBtnAction, // dispatch
      myStore, coupons, couponCode, pager,
      cfPageCoupons, cfUnusedCount, cfUsedCount,
      onSearch, onPageChange, onSizeChange, cartCount,
    };
  },
  template: /* html */ `
<fo-page bare>
<fo-my-layout :navigate="navigate" :cart-count="cartCount" active-page="myCoupon">
  <!-- ===== ■. 영역 ====================================================== -->
  <MyDateFilter @search="onSearch" />
  <!-- ===== ■. 쿠폰 등록 =================================================== -->
  <div style="background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius);padding:16px;margin-bottom:20px;display:flex;gap:10px;align-items:center;">
    <input v-model="couponCode" type="text" placeholder="쿠폰 코드 입력 (예: SPRING5000)" @keyup.enter="handleBtnAction('coupons-add')"
      style="flex:1;padding:10px 14px;border:1.5px solid var(--border);border-radius:8px;background:var(--bg-base);color:var(--text-primary);font-size:0.9rem;outline:none;text-transform:uppercase;">
    <button @click="handleBtnAction('coupons-add')" class="btn-blue" style="padding:10px 20px;white-space:nowrap;">
      쿠폰 등록
    </button>
  </div>
  <!-- ===== □. 쿠폰 등록 =================================================== -->
  <!-- ===== ■. 탭 ======================================================= -->
  <div style="display:flex;border-bottom:2px solid var(--border);margin-bottom:20px;">
    <button @click="handleBtnAction('coupons-tabChange', 'unused')"
      :style="{
      padding:'10px 24px', background:'none', border:'none', cursor:'pointer',
      fontSize:'0.88rem', fontWeight: uiState.activeTab==='unused' ? '700' : '500',
      color: uiState.activeTab==='unused' ? 'var(--text-primary)' : 'var(--text-muted)',
      borderBottom: uiState.activeTab==='unused' ? '2px solid var(--text-primary)' : '2px solid transparent',
      marginBottom: '-2px',
      }">
      미사용
      <span style="font-size:0.8rem;margin-left:2px;">
        ({{ cfUnusedCount }})
      </span>
    </button>
    <button @click="handleBtnAction('coupons-tabChange', 'used')"
      :style="{
      padding:'10px 24px', background:'none', border:'none', cursor:'pointer',
      fontSize:'0.88rem', fontWeight: uiState.activeTab==='used' ? '700' : '500',
      color: uiState.activeTab==='used' ? 'var(--text-primary)' : 'var(--text-muted)',
      borderBottom: uiState.activeTab==='used' ? '2px solid var(--text-primary)' : '2px solid transparent',
      marginBottom: '-2px',
      }">
      사용
      <span style="font-size:0.8rem;margin-left:2px;">
        ({{ cfUsedCount }})
      </span>
    </button>
  </div>
  <!-- ===== □. 탭 ======================================================= -->
  <!-- ===== ■. 영역 ====================================================== -->
  <PagerHeader :total="pager.pageTotalCount" :pager="pager" @size-change="onSizeChange" />
  <!-- ===== ■. 조건부 영역 ================================================== -->
  <div v-if="!cfPageCoupons.length" style="text-align:center;padding:60px 0;color:var(--text-muted);">
    {{ uiState.activeTab==='unused' ? '사용 가능한 쿠폰이 없습니다.' : '사용된 쿠폰이 없습니다.' }}
  </div>
  <!-- ===== □. 조건부 영역 ================================================== -->
  <!-- ===== ■. 영역 ====================================================== -->
  <div v-for="c in cfPageCoupons" :key="c.couponId"
    style="background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius);padding:16px;margin-bottom:10px;display:flex;align-items:flex-start;gap:14px;">
    <!-- ===== ■.■. 쿠폰 아이콘 ================================================ -->
    <div style="font-size:2rem;flex-shrink:0;margin-top:2px;">
      🎟️
    </div>
    <!-- ===== ■.■. 메인 정보 ================================================= -->
    <div style="flex:1;min-width:0;">
      <div style="font-weight:700;color:var(--text-primary);margin-bottom:4px;">
        {{ c.name }}
      </div>
      <!-- ===== ■.■.■. 배지 ================================================== -->
      <div style="display:flex;gap:5px;flex-wrap:wrap;margin-bottom:8px;">
        <span style="font-size:0.72rem;padding:2px 8px;border-radius:10px;font-weight:600;"
          :style="c.discountType==='shipping' ? 'background:#dbeafe;color:#1d4ed8;' : 'background:#dcfce7;color:#15803d;'">
          {{ c.discountType==='shipping' ? '배송비 할인' : '상품 할인' }}
        </span>
        <span v-if="c.applicableTo ? c.discountType!=='shipping' : false" style="font-size:0.72rem;padding:2px 8px;border-radius:10px;font-weight:600;background:var(--bg-base);color:var(--text-secondary);border:1px solid var(--border);">
        {{ c.applicableTo }}
      </span>
      <span style="font-size:0.72rem;padding:2px 8px;border-radius:10px;font-weight:600;"
          :style="c.regMethod==='자동' ? 'background:#ede9fe;color:#6d28d9;' : 'background:#fef3c7;color:#92400e;'">
        {{ c.regMethod || '수동' }}
      </span>
    </div>
    <!-- ===== ■.■.■. 기본 정보 =============================================== -->
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:3px 16px;margin-bottom:6px;">
      <div style="font-size:0.78rem;color:var(--text-muted);">
        쿠폰코드
        <span style="font-weight:600;color:var(--text-secondary);margin-left:4px;font-family:monospace;letter-spacing:.5px;">
          {{ c.code }}
        </span>
      </div>
      <div style="font-size:0.78rem;color:var(--text-muted);">
        쿠폰발급번호
        <span style="font-weight:600;color:var(--text-secondary);margin-left:4px;">
          {{ String(c.couponId).padStart(8, '0') }}
        </span>
      </div>
      <div style="font-size:0.78rem;color:var(--text-muted);">
        만료
        <span style="font-weight:600;color:var(--text-secondary);margin-left:4px;">
          {{ c.expiry }}
        </span>
      </div>
      <div v-if="c.minOrder>0" style="font-size:0.78rem;color:var(--text-muted);">
        최소주문
        <span style="font-weight:600;color:var(--text-secondary);margin-left:4px;">
          {{ c.minOrder.toLocaleString() }}원 이상
        </span>
      </div>
      <div v-if="c.regDate" style="font-size:0.78rem;color:var(--text-muted);">
        등록일
        <span style="font-weight:600;color:var(--text-secondary);margin-left:4px;">
          {{ c.regDate }}
        </span>
      </div>
      <div v-if="c.regSource" style="font-size:0.78rem;color:var(--text-muted);">
        등록출처
        <span style="font-weight:600;color:var(--text-secondary);margin-left:4px;">
          {{ c.regSource }}
        </span>
      </div>
    </div>
    <!-- ===== ■.■.■. 사용 정보 (사용됨 탭) ======================================= -->
    <div v-if="c.used" style="margin-top:6px;padding:8px 12px;background:var(--bg-base);border-radius:6px;border:1px solid var(--border);display:flex;flex-wrap:wrap;gap:8px 20px;">
      <div v-if="c.usedOrderId" style="font-size:0.78rem;color:var(--text-muted);">
        주문id
        <span style="font-weight:600;color:var(--blue);margin-left:4px;">
          {{ c.usedOrderId }}
        </span>
      </div>
      <div v-if="c.usedOrderItemId" style="font-size:0.78rem;color:var(--text-muted);">
        주문상품id
        <span style="font-weight:600;color:var(--text-secondary);margin-left:4px;">
          {{ c.usedOrderItemId }}
        </span>
      </div>
      <div v-if="c.usedProductId" style="font-size:0.78rem;color:var(--text-muted);">
        상품id
        <span style="font-weight:600;color:var(--text-secondary);margin-left:4px;">
          {{ c.usedProductId }}
        </span>
      </div>
      <div v-if="c.usedClaimId" style="font-size:0.78rem;color:var(--text-muted);">
        클레임id
        <span style="font-weight:600;color:var(--text-secondary);margin-left:4px;">
          {{ c.usedClaimId }}
        </span>
      </div>
      <div v-if="myStore.getCouponUsedOrderItems(c)" style="width:100%;display:flex;flex-wrap:wrap;gap:4px;margin-top:2px;">
        <span v-for="(item, ii) in myStore.getCouponUsedOrderItems(c)" :key="ii"
            style="font-size:0.68rem;padding:1px 6px;border-radius:8px;background:var(--bg-card);color:var(--text-muted);border:1px solid var(--border);">
          {{ item.emoji }} {{ item.prodNm }}
        </span>
      </div>
    </div>
  </div>
  <!-- ===== □.□. 메인 정보 ================================================= -->
  <!-- ===== ■.■. 할인금액 + 상태 ============================================= -->
  <div style="text-align:right;flex-shrink:0;">
    <div style="font-size:1.1rem;font-weight:800;color:var(--blue);">
      {{ myStore.discountLabel(c) }}
    </div>
    <div style="font-size:0.75rem;font-weight:600;margin-top:4px;"
        :style="c.used ? 'color:#9ca3af;' : 'color:#22c55e;'">
      {{ c.used ? '사용됨' : '사용 가능' }}
    </div>
  </div>
</div>
<!-- ===== □.□. 할인금액 + 상태 ============================================= -->
<!-- ===== □. 영역 ====================================================== -->
<!-- ===== ■. 영역 ====================================================== -->
<Pagination :total="pager.pageTotalCount" :pager="pager" @set-page="onPageChange" />
</fo-my-layout>
</fo-page>
<!-- ===== □. 영역 ====================================================== -->
`,
  components: {
    FoMyLayout:    window.foMyLayout,
    PagerHeader: window.PagerHeader,
    Pagination:  window.Pagination,
  }
};
