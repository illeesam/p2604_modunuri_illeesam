﻿/* ShopJoy - Order */
window.Order = {
  name: 'Order',
  props: {
    navigate:     { type: Function, required: true },        // 페이지 이동
  },
  setup(props) {

    /* ##### [01] 초기 변수 정의 ################################################## */

    const { reactive, computed, onMounted, watch } = Vue;
    const showToast            = window.foApp.showToast;  // 토스트 알림
    const clearCart            = window.foApp.clearCart;  // 장바구니 비우기
    const cart                 = window.foApp.cart;  // 장바구니 목록
    const modals = reactive({ isAddrSearchModal: false });   // 주소검색 모달 (카카오 우편번호, 인라인 레이어)
    const uiState = reactive({ loading: false, error: null, view: 'order', resultData: null, selectedShipCoupon: null, cashBalance: 0, cashInput: 0, shipCouponPopup: false });
    const codes = reactive({
      dliv_req_opts: [
        { value: '문 앞에 놔주세요',    label: '문 앞에 놔주세요' },
        { value: '경비실에 맡겨주세요', label: '경비실에 맡겨주세요' },
        { value: '택배함에 넣어주세요', label: '택배함에 넣어주세요' },
        { value: '연락 후 배송해주세요', label: '연락 후 배송해주세요' },
      ],
    });

    /* ##### [02] 액션 모음 (dispatch) ############################################## */

    /* handleBtnAction — 버튼 액션 dispatch (cmd: '{영역명}-기능명'). 5줄 이하 짧은 로직은 인라인 */
    const handleBtnAction = (cmd, param = {}) => {
      console.log(' ■■ Order.js : handleBtnAction -> ', cmd, param);
      // 홈으로 이동
      if (cmd === 'page-goHome') {
        return props.navigate('home');
      // 상품목록으로 이동
      } else if (cmd === 'page-goProdList') {
        return props.navigate('prodList');
      // 마이페이지 주문 내역 이동
      } else if (cmd === 'page-goMyOrder') {
        return props.navigate('myOrder');
      // 문의하기 이동
      } else if (cmd === 'page-goContact') {
        return props.navigate('contact');
      // 주소 검색 모달 열기 (카카오 우편번호, 인라인 레이어)
      } else if (cmd === 'form-openAddr') {
        modals.isAddrSearchModal = true;
        return;
      // 주문 제출
      } else if (cmd === 'form-submit') {
        return handleSubmit();
      // 캐쉬 전액 사용
      } else if (cmd === 'cash-useAll') {
        uiState.cashInput = uiState.cashBalance;
        return;
      // 캐쉬 초기화
      } else if (cmd === 'cash-reset') {
        uiState.cashInput = 0;
        return;
      // 배송비 쿠폰 팝업 열기
      } else if (cmd === 'shipCoupon-open') {
        uiState.shipCouponPopup = true;
        return;
      // 배송비 쿠폰 제거
      } else if (cmd === 'shipCoupon-remove') {
        return removeShipCoupon();
      // 상품 쿠폰 팝업 열기 (param: idx)
      } else if (cmd === 'coupon-open') {
        return openCouponPopup(param);
      // 상품 쿠폰 제거 (param: idx)
      } else if (cmd === 'coupon-remove') {
        return removeCoupon(param);
      } else {
        console.warn('[handleBtnAction] unknown cmd:', cmd);
      }
    };

    /* handleSelectAction — 행/선택 액션 dispatch (cmd: '{영역명}-기능명'). 5줄 이하 짧은 로직은 인라인 */
    const handleSelectAction = (cmd, param = {}) => {
      console.log(' ■■ Order.js : handleSelectAction -> ', cmd, param);
      console.warn('[handleSelectAction] unknown cmd:', cmd);
    };

    /* fnCallbackModal — 모든 모달 통합 dispatch.
     *   cmd    = 모달명
     *   param  = 호출 파라미터 (미사용 시 null)
     *   result = 'close' → X닫기(선택 없음) / null → 쿠폰 해제(미선택) / 객체 → 쿠폰 적용
     */
    const fnCallbackModal = (popCmd, param, result) => {
      console.log(' ■■ Order.js : fnCallbackModal -> ', popCmd, param, result);
      // 상품 쿠폰 모달
      if (popCmd === 'coupon') {
        couponPopup.show = false;
        if (result === 'close') return;             // X 닫기 — 선택 그대로 유지
        return applyCoupon(result);                 // null=해제, 쿠폰객체=적용
      // 배송비 쿠폰 모달
      } else if (popCmd === 'shipCoupon') {
        uiState.shipCouponPopup = false;
        if (result === 'close') return;
        return applyShipCoupon(result);
      // 주소검색 모달 콜백 → 우편번호/주소 반영
      } else if (popCmd === 'addr-search') {
        modals.isAddrSearchModal = false;
        if (result == null) { return; }
        form.postcode = result.zonecode;
        form.address  = result.address;
        clearErr('address');   // 주소는 readonly(모달로만 채움) — 여기서 오류 라벨을 지워야 한다
        return;
      } else {
        console.warn('[fnCallbackModal] unknown popCmd:', popCmd);
      }
    };

    /* ##### [03] 초기 함수 (마운트 / 코드 로드 / watch) ############################## */


    /* parsePrice — 파싱 가격 */
    const parsePrice = s => parseInt(String(s || '').replace(/[^0-9]/g, ''), 10) || 0;

    /* fmt — 포맷 */
    const fmt        = n => Number(n).toLocaleString('ko-KR') + '원';

    /* -- 쿠폰 로드 -- */
    const allCoupons  = reactive([]);

    /* ##### [04] 내장 사용 함수 (이벤트 핸들러 on* / handle*) #################### */

    /* handleLoadCoupons — 처리 */
    const handleLoadCoupons = async () => {
      try {
        const res = await foApiSvc.myCoupon.getList({}, '주문', '쿠폰조회');
        allCoupons.splice(0, allCoupons.length, ...(res.data?.data || []).filter(c => !c.used));
      } catch (e) { allCoupons.length = 0; }
    };

    /* productCoupons — 상품 Coupons */
    const productCoupons = item => {
      const price = parsePrice(item.prod.price) * item.qty;
      return allCoupons.filter(c =>
        (c.discountType === 'rate' || c.discountType === 'amount') &&
        price >= (c.minOrder || 0)
      );
    };
    /* 배송비쿠폰: shipping 타입만 */
    const cfShippingCoupons = computed(() =>
      allCoupons.filter(c => c.discountType === 'shipping')
    );

    /* discountLabel — 할인 라벨 */
    const discountLabel = c => {
      if (!c) { return ''; }
      if (c.discountType === 'rate') { return c.discountValue + '% 할인'; }
      if (c.discountType === 'shipping') { return '무료배송'; }
      return fmt(c.discountValue) + ' 할인';
    };

    /* calcCouponDiscount — 계산 쿠폰 할인 */
    const calcCouponDiscount = (c, item) => {
      if (!c) { return 0; }
      const base = parsePrice(item.prod.price) * item.qty;
      if (c.discountType === 'rate') { return Math.floor(base * c.discountValue / 100); }
      if (c.discountType === 'amount') { return Math.min(c.discountValue, base); }
      return 0;
    };

    /* -- 상품 쿠폰 팝업 -- */
    const couponPopup     = reactive({ show: false, targetIdx: null });
    const selectedCoupons = reactive({});

    /* openCouponPopup — 열기 */
    const openCouponPopup  = idx => { couponPopup.targetIdx = idx; couponPopup.show = true; };

    /* applyCoupon — 적용 */
    const applyCoupon      = c => {
      selectedCoupons[couponPopup.targetIdx] = c;
      couponPopup.show = false;
    };

    /* removeCoupon — 제거 */
    const removeCoupon     = idx => {
      delete selectedCoupons[idx];
    };

    /* -- 배송비 쿠폰 팝업 -- */
        const applyShipCoupon = c => { uiState.selectedShipCoupon = c; uiState.shipCouponPopup = false; };

    /* removeShipCoupon — 제거 */
    const removeShipCoupon = () => { uiState.selectedShipCoupon = null; };

    /* handleLoadCash — 처리 */
    const handleLoadCash = async () => {
      try {
        const res = await foApiSvc.myCash.getInfo({}, '주문', '캐시조회');
        uiState.cashBalance = res.data?.data?.balance || 0;
      } catch (e) {}
    };

    /* -- 주문 대상: 바로구매 > 선택장바구니(cartIds) > 전체장바구니 -- */
    const cfOrderItems = computed(() => {
      if (window.foApp.instantOrder) { return [window.foApp.instantOrder]; }
      if (window.foApp.cartIds?.length) { return cart.filter(i => window.foApp.cartIds.includes(i.cartId)); }
      return cart;
    });

    /* -- 금액 계산 -- */
    const cfCartTotal = computed(() =>
      cfOrderItems.value.reduce((s, i) => s + parsePrice(i.prod.price) * i.qty, 0)
    );
    const cfTotalCouponDiscount = computed(() =>
      cfOrderItems.value.reduce((s, item, idx) =>
        s + calcCouponDiscount(selectedCoupons[idx], item), 0)
    );
    const cfAppliedCash = computed(() => {
      const v = parseInt(String(uiState.cashInput).replace(/[^0-9]/g, ''), 10) || 0;
      return Math.min(v, uiState.cashBalance, Math.max(0, cfCartTotal.value - cfTotalCouponDiscount.value));
    });
    const cfFinalPrice = computed(() =>
      Math.max(0, cfCartTotal.value - cfTotalCouponDiscount.value - cfAppliedCash.value)
    );

    /* -- 주문자 폼 + 카카오 주소 -- */
    const form = reactive({
      name: '', tel: '', email: '',
      postcode: '', address: '', addressDetail: '', deliveryReq: ''
    });

    /* handleSearchData — 처리 */
    const handleSearchData = async (searchType = 'DEFAULT') => {
      const u = window.foAuth?.state?.user;
      /* user 만 보면 토큰 없이 사용자 정보만 복원된 상태에서도 통과해
         쿠폰·캐시 조회가 401 로 실패한다 → 로그인 판정 단일 기준 사용 */
      if (u && (window.foAuth?.isLoggedIn ? window.foAuth.isLoggedIn() : true)) {
        await Promise.all([handleLoadCoupons(), handleLoadCash()]);
        form.name = u.memberNm || ''; form.tel = u.phone || ''; form.email = u.email || '';
      }
    };


    const errors   = reactive({});

    /* clearErr — 비우기 */
    const clearErr = k => { delete errors[k]; };

    /* validate — 검증 */
    const validate = () => {
      Object.keys(errors).forEach(k => delete errors[k]);
      let ok = true;
      if (!form.name.trim() || form.name.trim().length < 2) { errors.name = '이름을 2자 이상 입력해주세요.'; ok = false; }
      if (!form.tel.trim())    { errors.tel     = '연락처를 입력해주세요.'; ok = false; }
      else if (!coUtil.cofIsValidPhone(form.tel)) { errors.tel = '올바른 연락처 형식이 아닙니다. (예: 010-1234-5678)'; ok = false; }
      if (!form.email.trim() || !coUtil.cofIsValidEmail(form.email))
                               { errors.email   = '유효한 이메일을 입력해주세요.'; ok = false; }
      if (!form.address.trim()){ errors.address = '배송 주소를 입력해주세요.'; ok = false; }
      return ok;
    };

    /* handleSubmit — 처리 */
    const handleSubmit = async () => {
      if (!validate()) { return; }
      uiState.submitting = true;
      try {
        const orderId = 'ORD-' + new Date().getFullYear() + '-' + String(Date.now()).slice(-5);
        const payload = {
          orderId,
          orderDate: coUtil.cofToYmd(new Date()),
          form: { ...form },
          items: cfOrderItems.value.map((i, idx) => ({
            prodId:   i.prod.prodId,
            prodNm: i.prod.prodNm,
            image:       i.prod.image,
            color: i.color.name, size: i.size, qty: i.qty,
            price:    parsePrice(i.prod.price) * i.qty,
            coupon:   selectedCoupons[idx]?.name || null,
            discount: calcCouponDiscount(selectedCoupons[idx], i),
          })),
          shippingCoupon:     uiState.selectedShipCoupon?.name || null,
          cartTotal:          cfCartTotal.value,
          couponDiscount:     cfTotalCouponDiscount.value,
          cashUsed:           cfAppliedCash.value,
          finalPrice:         cfFinalPrice.value,
        };
        if (typeof foApiSvc !== 'undefined') { await foApiSvc.myOrder.create(payload, '주문', '저장').catch(() => {}); }
        uiState.resultData = payload;
        uiState.view = 'result';
        if (!window.foApp.instantOrder) clearCart(); // 바로구매는 장바구니 건드리지 않음
        uiState.cashBalance = Math.max(0, uiState.cashBalance - cfAppliedCash.value);
      } finally { uiState.submitting = false; }
    };

    /* initPage — 화면 로드 시퀀스. 마운트 시 실행한다. */
    const initPage = async () => {
      handleSearchData();
    };
    onMounted(initPage);

    /* ##### [05] 사용자 함수 (헬퍼 / 카운트 / 렌더 / 컬럼정의) #################### */

    /* FoFormArea columns 정의 — 배송 주소는 slot 탈출구 사용(카카오 우편번호 버튼+3 input) */
    // --- [컬럼 정의] ---
    const columns = {};
    columns.baseForm = [
      { key: 'name',  label: '이름',   type: 'text', required: true, placeholder: '홍길동' },
      { key: 'tel',   label: '연락처', type: 'tel',  required: true, placeholder: '010-1234-5678',
        validate: (v) => v && !coUtil.cofIsValidPhone(v) ? '올바른 연락처 형식이 아닙니다. (예: 010-1234-5678)' : null },
      { type: 'rowBreak' },
      { key: 'email', label: '이메일', type: 'email', required: true, colSpan: 2,
        placeholder: 'hello@example.com',
        validate: (v) => v && !coUtil.cofIsValidEmail(v) ? '유효한 이메일을 입력해주세요.' : null },
      { type: 'rowBreak' },
      { key: 'address', label: '배송 주소', type: 'slot', name: 'address', colSpan: 2, required: true },
      { type: 'rowBreak' },
      { key: 'deliveryReq', label: '배송 요청사항', type: 'select', colSpan: 2,
        options: () => codes.dliv_req_opts, nullLabel: '선택 없음' },
    ];

    /* ##### [06] return (템플릿 노출) ############################################## */

    return {

      modals,   // 모달 표시 상태 모음
      columns,
      uiState, // 상태
      handleBtnAction, handleSelectAction, fnCallbackModal, // dispatch
      form, errors, clearErr, // 폼
      cfOrderItems, cfCartTotal, cfTotalCouponDiscount, // computed - 주문
      cfAppliedCash, cfFinalPrice, cfShippingCoupons, // computed - 금액/쿠폰
      parsePrice, fmt, // 헬퍼
      productCoupons, discountLabel, calcCouponDiscount,            // 쿠폰
      couponPopup, selectedCoupons, // 쿠폰 상태
      config: window.SITE_CONFIG || {},
    };
  },

  template: /* html */ `
<fo-page eyebrow="Shopping" title="주문 · 결제"
  :banner-img="uiState.view==='result' ? '' : 'assets/cdn/prod/img/page-title/page-title-1.jpg'"
  banner-align="center 40%"
  :crumbs="[{ label:'홈', page:'home' }, { label:'주문하기' }]"
  @nav="() => handleBtnAction('page-goHome')">
  <!-- ===== ■. ══ 주문 결과 화면 ══ ========================================== -->
  <template v-if="uiState.view==='result' ? uiState.resultData : false">
  <div style="max-width:600px;margin:0 auto;padding:40px 20px;text-align:center;">
    <div style="font-size:4rem;margin-bottom:16px;">
      🎉
    </div>
    <h1 style="font-size:1.8rem;font-weight:900;color:var(--text-primary);margin-bottom:8px;">
      주문이 완료됐어요!
    </h1>
    <p style="color:var(--text-secondary);font-size:0.9rem;margin-bottom:4px;">
      주문번호:
      <strong style="color:var(--blue);">
        {{ uiState.resultData.orderId }}
      </strong>
    </p>
    <p style="color:var(--text-muted);font-size:0.85rem;margin-bottom:32px;">
      입금 확인 후 1~2 영업일 이내 발송됩니다.
    </p>
    <fo-container card-style="padding:20px;text-align:left;margin-bottom:20px;">
      <div style="font-size:0.88rem;font-weight:700;color:var(--text-primary);margin-bottom:14px;">
        📦 주문 상품
      </div>
      <div v-for="item in uiState.resultData.items" :key="item.prodId"
          style="display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid var(--border);">
        <div style="width:40px;height:40px;border-radius:6px;overflow:hidden;flex-shrink:0;background:var(--bg-base);">
          <img :src="item.image || window.NO_IMAGE" style="width:100%;height:100%;object-fit:cover;" />
        </div>
        <div style="flex:1;">
          <div style="font-size:0.88rem;font-weight:600;color:var(--text-primary);">
            {{ item.prodNm }}
          </div>
          <div style="font-size:0.78rem;color:var(--text-muted);">
            {{ item.color }} / {{ item.size }} × {{ item.qty }}
          </div>
          <div v-if="item.coupon" style="font-size:0.75rem;color:var(--blue);margin-top:2px;">
            🎟️ {{ item.coupon }} (-{{ fmt(item.discount) }})
          </div>
        </div>
        <div style="font-size:0.88rem;font-weight:700;color:var(--text-primary);">
          {{ fmt(item.price) }}
        </div>
      </div>
      <div style="margin-top:14px;display:flex;flex-direction:column;gap:6px;">
        <div style="display:flex;justify-content:space-between;font-size:0.85rem;color:var(--text-secondary);">
          <span>
            상품금액
          </span>
          <span>
            {{ fmt(uiState.resultData.cartTotal) }}
          </span>
        </div>
        <div v-if="uiState.resultData.couponDiscount>0" style="display:flex;justify-content:space-between;font-size:0.85rem;color:var(--blue);">
          <span>
            쿠폰 할인
          </span>
          <span>
            -{{ fmt(uiState.resultData.couponDiscount) }}
          </span>
        </div>
        <div v-if="uiState.resultData.shippingCoupon" style="display:flex;justify-content:space-between;font-size:0.85rem;color:var(--blue);">
          <span>
            배송비 쿠폰
          </span>
          <span>
            🎟️ {{ uiState.resultData.shippingCoupon }}
          </span>
        </div>
        <div v-if="uiState.resultData.cashUsed>0" style="display:flex;justify-content:space-between;font-size:0.85rem;color:#f97316;">
          <span>
            캐쉬 사용
          </span>
          <span>
            -{{ fmt(uiState.resultData.cashUsed) }}
          </span>
        </div>
        <div style="display:flex;justify-content:space-between;font-size:0.85rem;color:var(--text-secondary);">
          <span>
            배송비
          </span>
          <span style="color:#22c55e;">
            무료
          </span>
        </div>
        <div style="border-top:1px solid var(--border);padding-top:8px;display:flex;justify-content:space-between;font-size:1rem;font-weight:800;">
          <span style="color:var(--text-primary);">
            최종 결제금액
          </span>
          <span style="color:var(--blue);">
            {{ fmt(uiState.resultData.finalPrice) }}
          </span>
        </div>
      </div>
    </fo-container>
    <!-- ===== ■.■.■. 카드 영역 =============================================== -->
    <fo-container card-style="padding:18px;text-align:left;margin-bottom:28px;background:var(--blue-dim);">
      <div style="font-size:0.85rem;font-weight:700;color:var(--blue);margin-bottom:10px;">
        💳 입금 안내
      </div>
      <div style="font-size:0.85rem;color:var(--text-secondary);line-height:1.8;">
        {{ config.bank && config.bank.name }} {{ config.bank?.account }}
        <br>
        예금주: {{ config.bank && config.bank.holder }}
        <br>
        <strong style="color:var(--blue);">
          입금액: {{ fmt(uiState.resultData.finalPrice) }}
        </strong>
        <br>
        입금자명: {{ uiState.resultData.form.name }}
      </div>
    </fo-container>
    <div style="display:flex;flex-direction:column;gap:12px;">
      <button @click="handleBtnAction('page-goMyOrder')"
          style="padding:14px;font-size:1rem;font-weight:700;border:none;border-radius:10px;background:linear-gradient(135deg,#1a1a1a,#404040);color:#fff;cursor:pointer;box-shadow:0 2px 8px rgba(0,0,0,0.15);transition:all .15s;"
          @mouseenter="$event.currentTarget.style.transform='translateY(-1px)'"
          @mouseleave="$event.currentTarget.style.transform=''">
        📋 마이페이지에서 주문 확인
      </button>
      <button @click="handleBtnAction('page-goHome')"
          style="padding:14px;border:1.5px solid #e4e7ec;border-radius:10px;background:#fff;color:#555;font-weight:600;cursor:pointer;transition:all .15s;"
          @mouseenter="$event.currentTarget.style.background='#f8f9fb'"
          @mouseleave="$event.currentTarget.style.background='#fff'">
        🛍 계속 쇼핑하기
      </button>
    </div>
  </div>
</template>
<!-- ===== □. ══ 주문 결과 화면 ══ ========================================== -->
<!-- ===== ■. ══ 주문 입력 화면 ══ ========================================== -->
<template v-else>
  <div v-if="cfOrderItems.length===0" style="text-align:center;padding:80px 20px;">
    <div style="font-size:4rem;margin-bottom:20px;">
      📦
    </div>
    <p style="color:var(--text-muted);font-size:1rem;margin-bottom:24px;">
      주문할 상품이 없어요.
    </p>
    <button class="btn-blue" @click="handleBtnAction('page-goProdList')" style="padding:12px 28px;">
      상품 보러가기
    </button>
  </div>
  <template v-else>
    <!-- ===== ■.■.■. 주문 상품 + 쿠폰 ========================================== -->
    <fo-container card-style="padding:20px;margin-bottom:20px;">
      <h2 style="font-size:0.95rem;font-weight:700;margin-bottom:14px;color:var(--text-primary);">
        🛍️ 주문 상품 ({{ cfOrderItems.length }})
      </h2>
      <div style="display:flex;flex-direction:column;gap:14px;">
        <div v-for="(item, idx) in cfOrderItems" :key="idx"
            style="padding-bottom:14px;"
            :style="idx<cfOrderItems.length-1?'border-bottom:1px solid var(--border);':''">
          <!-- ===== ■.■.■.■.■.■. 상품 행 ========================================== -->
          <div style="display:flex;gap:12px;align-items:center;margin-bottom:10px;">
            <div style="width:52px;height:52px;border-radius:10px;flex-shrink:0;overflow:hidden;background:var(--bg-base);">
              <img v-if="item.prod.image" :src="item.prod.image" :alt="item.prod.prodNm" style="width:100%;height:100%;object-fit:cover;" />
            </div>
            <div style="flex:1;min-width:0;">
              <div style="font-weight:700;font-size:0.9rem;color:var(--text-primary);">
                {{ item.prod.prodNm }}
              </div>
              <div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:3px;">
                <span v-if="item.color" style="font-size:0.75rem;padding:1px 8px;border-radius:10px;background:var(--blue-dim);color:var(--blue);font-weight:600;">
                  {{ item.color.name }}
                </span>
                <span style="font-size:0.75rem;padding:1px 8px;border-radius:10px;background:var(--purple-dim);color:var(--purple);font-weight:600;">
                  {{ item.size }}
                </span>
                <span style="font-size:0.75rem;padding:1px 8px;border-radius:10px;background:var(--bg-base);color:var(--text-secondary);font-weight:600;">
                  × {{ item.qty }}
                </span>
              </div>
            </div>
            <div style="text-align:right;flex-shrink:0;">
              <div style="font-weight:800;color:var(--text-primary);font-size:0.9rem;">
                {{ fmt(parsePrice(item.prod.price)*item.qty) }}
              </div>
              <div v-if="selectedCoupons[idx]" style="font-size:0.78rem;color:var(--blue);margin-top:2px;">
                -{{ fmt(calcCouponDiscount(selectedCoupons[idx],item)) }}
              </div>
            </div>
          </div>
          <!-- ===== ■.■.■.■.■.■. 상품 쿠폰 (rate/amount 만) ========================= -->
          <div style="display:flex;align-items:center;gap:8px;padding:10px 12px;border-radius:8px;background:var(--bg-base);">
            <span style="font-size:0.82rem;color:var(--text-muted);flex-shrink:0;">
              🎟️ 상품쿠폰
            </span>
            <template v-if="selectedCoupons[idx]">
              <div style="flex:1;min-width:0;">
                <span style="font-size:0.82rem;font-weight:700;color:var(--blue);">
                  {{ selectedCoupons[idx].name }}
                </span>
                <span style="font-size:0.78rem;color:var(--blue);margin-left:6px;">
                  ({{ discountLabel(selectedCoupons[idx]) }})
                </span>
              </div>
              <button @click="handleBtnAction('coupon-remove', idx)"
                  style="padding:6px 12px;border:1px solid #ffcdd2;border-radius:6px;background:#ffebee;color:#c62828;font-size:0.8rem;cursor:pointer;font-weight:600;transition:all .15s;"
                  @mouseenter="$event.currentTarget.style.background='#ffcdd2'"
                  @mouseleave="$event.currentTarget.style.background='#ffebee'">
                ✕ 제거
              </button>
              <button @click="handleBtnAction('coupon-open', idx)"
                  style="padding:6px 12px;border:1px solid #bbdefb;border-radius:6px;background:#e3f2fd;color:#1565c0;font-size:0.8rem;cursor:pointer;font-weight:600;transition:all .15s;"
                  @mouseenter="$event.currentTarget.style.background='#bbdefb'"
                  @mouseleave="$event.currentTarget.style.background='#e3f2fd'">
                ↻ 변경
              </button>
            </template>
            <template v-else>
              <span style="flex:1;font-size:0.82rem;color:var(--text-muted);">
                {{ productCoupons(item).length ? '적용 가능 ' + productCoupons(item).length + '개' : '적용 가능 쿠폰 없음' }}
              </span>
              <button v-if="productCoupons(item).length" @click="handleBtnAction('coupon-open', idx)"
                  style="padding:6px 14px;border:1px solid #bbdefb;border-radius:8px;background:#e3f2fd;color:#1565c0;font-size:0.8rem;cursor:pointer;font-weight:600;transition:all .15s;"
                  @mouseenter="$event.currentTarget.style.background='#bbdefb'"
                  @mouseleave="$event.currentTarget.style.background='#e3f2fd'">
                🎟 선택
              </button>
            </template>
          </div>
        </div>
      </div>
      <!-- ===== ■.■.■.■. 캐쉬 적용 ============================================= -->
      <div style="border-top:1px solid var(--border);margin-top:16px;padding-top:16px;">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;">
          <span style="font-size:0.88rem;font-weight:700;color:var(--text-primary);">
            💰 캐쉬 사용
          </span>
          <span style="font-size:0.82rem;color:var(--text-muted);">
            잔액
            <strong style="color:var(--text-primary);">
              {{ fmt(uiState.cashBalance) }}
            </strong>
          </span>
        </div>
        <div style="display:flex;gap:8px;align-items:center;">
          <input v-model="uiState.cashInput" type="number" min="0" :max="uiState.cashBalance" placeholder="사용할 캐쉬 금액"
              style="flex:1;padding:9px 12px;border:1.5px solid var(--border);border-radius:8px;background:var(--bg-card);color:var(--text-primary);font-size:0.88rem;outline:none;">
          <button @click="handleBtnAction('cash-useAll')"
              style="padding:8px 16px;border:1px solid #ffcc80;border-radius:8px;background:#fff3e0;color:#e65100;font-size:0.82rem;cursor:pointer;font-weight:600;white-space:nowrap;transition:all .15s;"
              @mouseenter="$event.currentTarget.style.background='#ffe0b2'"
              @mouseleave="$event.currentTarget.style.background='#fff3e0'">
            💰 전액사용
          </button>
          <button @click="handleBtnAction('cash-reset')"
              style="padding:8px 14px;border:1px solid #e0e0e0;border-radius:8px;background:#fafafa;color:#888;font-size:0.82rem;cursor:pointer;font-weight:500;transition:all .15s;"
              @mouseenter="$event.currentTarget.style.background='#f0f0f0';$event.currentTarget.style.color='#555'"
              @mouseleave="$event.currentTarget.style.background='#fafafa';$event.currentTarget.style.color='#888'">
            ↻ 초기화
          </button>
        </div>
        <div v-if="cfAppliedCash>0" style="margin-top:6px;font-size:0.82rem;color:#f97316;">
          {{ fmt(cfAppliedCash) }} 캐쉬 사용 예정
        </div>
      </div>
      <!-- ===== ■.■.■.■. 최종 금액 ============================================= -->
      <div style="border-top:1px solid var(--border);margin-top:16px;padding-top:14px;display:flex;flex-direction:column;gap:6px;">
        <div style="display:flex;justify-content:space-between;font-size:0.85rem;color:var(--text-secondary);">
          <span>
            상품금액
          </span>
          <span>
            {{ fmt(cfCartTotal) }}
          </span>
        </div>
        <div v-if="cfTotalCouponDiscount>0" style="display:flex;justify-content:space-between;font-size:0.85rem;color:var(--blue);">
          <span>
            쿠폰 할인
          </span>
          <span>
            -{{ fmt(cfTotalCouponDiscount) }}
          </span>
        </div>
        <div v-if="cfAppliedCash>0" style="display:flex;justify-content:space-between;font-size:0.85rem;color:#f97316;">
          <span>
            캐쉬 사용
          </span>
          <span>
            -{{ fmt(cfAppliedCash) }}
          </span>
        </div>
        <div style="display:flex;justify-content:space-between;font-size:0.85rem;color:var(--text-secondary);">
          <span>
            배송비
          </span>
          <span>
            <span v-if="uiState.selectedShipCoupon" style="color:var(--blue);font-size:0.8rem;margin-right:6px;">
              🎟️ {{ uiState.selectedShipCoupon.name }}
            </span>
            <span style="color:#22c55e;">
              무료
            </span>
          </span>
        </div>
        <div style="display:flex;justify-content:space-between;font-size:1.05rem;font-weight:800;padding-top:8px;border-top:2px solid var(--border);margin-top:2px;">
          <span style="color:var(--text-primary);">
            최종 결제금액
          </span>
          <span style="color:var(--blue);">
            {{ fmt(cfFinalPrice) }}
          </span>
        </div>
      </div>
    </fo-container>
    <!-- ===== ■.■.■. 주문자 정보 + 결제 안내 ====================================== -->
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:clamp(12px,2vw,20px);align-items:start;" class="order-grid">
      <!-- ===== ■.■.■.■. 주문자 정보 ============================================ -->
      <fo-container card-style="padding:clamp(16px,3vw,28px);">
        <h2 style="font-size:1rem;font-weight:700;margin-bottom:18px;color:var(--text-primary);">
          👤 주문자 정보
        </h2>
        <!-- ===== ■.■.■.■.■. 폼 영역 ============================================ -->
        <fo-form-area :columns="columns.baseForm" :form="form" :errors="errors" :cols="2" min-col-width="160px">
          <template #address>
            <div style="display:flex;gap:8px;margin-bottom:8px;">
              <input v-model="form.postcode" class="form-input" placeholder="우편번호" readonly
                  style="width:110px;flex-shrink:0;background:var(--bg-base);cursor:default;" />
              <button @click="handleBtnAction('form-openAddr')" type="button"
                  style="padding:8px 16px;border:1px solid #a5d6a7;border-radius:8px;background:#e8f5e9;color:#2e7d32;font-size:0.82rem;font-weight:600;cursor:pointer;white-space:nowrap;transition:all .15s;"
                  @mouseenter="$event.currentTarget.style.background='#c8e6c9'"
                  @mouseleave="$event.currentTarget.style.background='#e8f5e9'">
                📮 주소 검색
              </button>
            </div>
            <input v-model="form.address" class="form-input" placeholder="도로명 주소" readonly
                @input="clearErr('address')"
                style="margin-bottom:8px;background:var(--bg-base);cursor:default;" />
            <input v-model="form.addressDetail" class="form-input" placeholder="상세 주소 (동/호수 등)" />
            <div v-if="errors.address" class="form-error">
              {{ errors.address }}
            </div>
          </template>
        </fo-form-area>
        <button @click="handleBtnAction('form-submit')" :disabled="uiState.submitting"
            :style="{
            width:'100%',padding:'14px',border:'none',borderRadius:'10px',fontSize:'0.95rem',fontWeight:700,
            cursor: uiState.submitting ? 'wait' : 'pointer',
            background: uiState.submitting ? '#9ca3af' : 'linear-gradient(135deg,#1a1a1a,#404040)',
            color:'#fff',transition:'all .15s',
            boxShadow: uiState.submitting ? 'none' : '0 2px 8px rgba(0,0,0,0.15)',
            letterSpacing:'0.5px',
            }"
            @mouseenter="!uiState.submitting ? ($event.currentTarget.style.transform='translateY(-1px)', $event.currentTarget.style.boxShadow='0 4px 14px rgba(0,0,0,0.25)') : null"
            @mouseleave="$event.currentTarget.style.transform='', $event.currentTarget.style.boxShadow=uiState.submitting?'none':'0 2px 8px rgba(0,0,0,0.15)'">
          {{ uiState.submitting ? '처리 중...' : '🛒 주문 완료' }}
        </button>
      </fo-container>
      <!-- ===== ■.■.■.■. 결제 안내 ============================================= -->
      <fo-container card-style="padding:clamp(16px,3vw,28px);">
        <h2 style="font-size:1rem;font-weight:700;margin-bottom:18px;color:var(--text-primary);">
          💳 결제 안내 (계좌이체)
        </h2>
        <div style="display:flex;flex-direction:column;gap:4px;">
          <div class="info-row">
            <span class="info-icon">
              1️⃣
            </span>
            <div>
              <div class="info-label">
                결제 방식
              </div>
              <div class="info-val">
                계좌이체 방식으로 진행됩니다.
              </div>
            </div>
          </div>
          <div class="info-row">
            <span class="info-icon">
              2️⃣
            </span>
            <div>
              <div class="info-label">
                입금 계좌
              </div>
              <div class="info-val" style="margin-top:4px;">
                <span v-if="config.bank?.account">
                {{ config.bank.name }} {{ config.bank.account }}
                <br>
                예금주: {{ config.bank.holder }}
              </span>
            </div>
          </div>
        </div>
        <div class="info-row">
          <span class="info-icon">
            3️⃣
          </span>
          <div>
            <div class="info-label">
              입금 금액
            </div>
            <div class="info-val" style="color:var(--blue);font-weight:700;margin-top:4px;">
              {{ fmt(cfFinalPrice) }}
            </div>
          </div>
        </div>
        <div class="info-row">
          <span class="info-icon">
            4️⃣
          </span>
          <div>
            <div class="info-label">
              입금자명
            </div>
            <div class="info-val" style="margin-top:4px;">
              주문자명과 동일하게 입력해주세요.
            </div>
          </div>
        </div>
        <!-- ===== ■.■.■.■.■.■. 배송비 + 배송비 쿠폰 선택 =============================== -->
        <div class="info-row" style="align-items:flex-start;">
          <span class="info-icon">
            🚚
          </span>
          <div style="flex:1;">
            <div class="info-label">
              배송비
            </div>
            <div style="margin-top:6px;">
              <template v-if="uiState.selectedShipCoupon">
                <div style="display:flex;align-items:center;gap:8px;padding:8px 10px;border-radius:8px;background:var(--blue-dim);">
                  <span style="font-size:0.82rem;font-weight:700;color:var(--blue);flex:1;">
                    🎟️ {{ uiState.selectedShipCoupon.name }}
                  </span>
                  <button @click="handleBtnAction('shipCoupon-remove')"
                        style="padding:5px 11px;border:1px solid #ffcdd2;border-radius:6px;background:#ffebee;color:#c62828;font-size:0.78rem;cursor:pointer;font-weight:600;transition:all .15s;"
                        @mouseenter="$event.currentTarget.style.background='#ffcdd2'"
                        @mouseleave="$event.currentTarget.style.background='#ffebee'">
                    ✕ 제거
                  </button>
                  <button @click="handleBtnAction('shipCoupon-open')"
                        style="padding:5px 12px;border:1px solid #ce93d8;border-radius:6px;background:#f3e5f5;color:#6a1b9a;font-size:0.78rem;cursor:pointer;font-weight:600;transition:all .15s;"
                        @mouseenter="$event.currentTarget.style.background='#e1bee7'"
                        @mouseleave="$event.currentTarget.style.background='#f3e5f5'">
                    변경
                  </button>
                </div>
                <div style="font-size:0.82rem;color:#22c55e;margin-top:4px;">
                  ✓ 배송비 쿠폰 적용됨 → 무료
                </div>
              </template>
              <template v-else>
                <div style="display:flex;align-items:center;gap:8px;">
                  <span style="font-size:0.85rem;color:#22c55e;font-weight:700;">
                    무료
                  </span>
                  <button v-if="cfShippingCoupons.length" @click="handleBtnAction('shipCoupon-open')"
                        style="padding:6px 12px;border:1px solid #ce93d8;border-radius:8px;background:#f3e5f5;color:#6a1b9a;font-size:0.78rem;cursor:pointer;font-weight:600;transition:all .15s;"
                        @mouseenter="$event.currentTarget.style.background='#e1bee7'"
                        @mouseleave="$event.currentTarget.style.background='#f3e5f5'">
                    🎟 배송비 쿠폰 선택
                  </button>
                </div>
              </template>
            </div>
          </div>
        </div>
        <!-- ===== ■.■.■.■.■.■. 영역 ============================================ -->
        <div class="info-row">
          <span class="info-icon">
            📞
          </span>
          <div>
            <div class="info-label">
              문의
            </div>
            <div class="info-val" style="margin-top:4px;">
              {{ config.tel }} / {{ config.email }}
            </div>
          </div>
        </div>
      </div>
      <div style="margin-top:16px;">
        <button @click="handleBtnAction('page-goContact')"
              style="width:100%;padding:10px;border:1.5px solid #e4e7ec;border-radius:10px;background:#fff;color:#555;font-size:0.88rem;font-weight:600;cursor:pointer;transition:all .15s;"
              @mouseenter="$event.currentTarget.style.background='#f8f9fb';$event.currentTarget.style.borderColor='#d0d7de'"
              @mouseleave="$event.currentTarget.style.background='#fff';$event.currentTarget.style.borderColor='#e4e7ec'">
          💬 문의·상담하기
        </button>
      </div>
    </fo-container>
  </div>
</template>
</template>
<!-- ===== □.□. 페이지 타이틀 배너 ============================================ -->
<!-- ===== □. ══ 주문 입력 화면 ══ ========================================== -->
<!-- ===== ■. ══ 상품 쿠폰 팝업 ══ ========================================== -->
<fo-modal :show="couponPopup.show && cfOrderItems.length > 0" title="🎟️ 상품 쿠폰 선택" max-width="480px" max-height="82vh"
  @close="fnCallbackModal('coupon', null, 'close')">
  <div style="font-size:0.76rem;color:var(--text-muted);margin-bottom:12px;">
    할인(정률/정액) 쿠폰 · 상품 1개당 1개 적용
  </div>
  <div style="display:flex;flex-direction:column;gap:8px;">
    <!-- 쿠폰 없음 -->
    <div @click="fnCallbackModal('coupon', null, null)"
        style="padding:14px 16px;border-radius:10px;border:1.5px solid var(--border);background:var(--bg-card);cursor:pointer;display:flex;align-items:center;gap:12px;transition:all .15s;"
        :style="!selectedCoupons[couponPopup.targetIdx] ? 'border-color:var(--text-muted);background:var(--bg-base);' : ''">
      <div style="width:38px;height:38px;border-radius:10px;background:var(--bg-base);display:flex;align-items:center;justify-content:center;font-size:1.2rem;flex-shrink:0;color:var(--text-muted);">
        🚫
      </div>
      <div style="flex:1;font-size:0.9rem;font-weight:600;color:var(--text-secondary);">
        쿠폰 사용 안 함
      </div>
    </div>
    <template v-if="couponPopup.targetIdx !== null">
      <div v-for="c in productCoupons(cfOrderItems[couponPopup.targetIdx])" :key="c.couponId"
          @click="fnCallbackModal('coupon', null, c)"
          :style="{
            padding:'14px 16px', borderRadius:'10px', cursor:'pointer',
            display:'flex', alignItems:'center', gap:'12px', transition:'all .15s',
            border: selectedCoupons[couponPopup.targetIdx] ? (selectedCoupons[couponPopup.targetIdx].couponId===c.couponId ? '2px solid var(--blue)' : '1.5px solid var(--border)') : '1.5px solid var(--border)',
            background: selectedCoupons[couponPopup.targetIdx] ? (selectedCoupons[couponPopup.targetIdx].couponId===c.couponId ? 'var(--blue-dim)' : 'var(--bg-card)') : 'var(--bg-card)',
          }">
        <div style="width:44px;height:44px;background:var(--blue-dim);border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:1.3rem;flex-shrink:0;">
          🎟️
        </div>
        <div style="flex:1;min-width:0;">
          <div style="font-size:0.9rem;font-weight:700;color:var(--text-primary);">
            {{ c.name }}
          </div>
          <div style="font-size:0.74rem;color:var(--text-muted);margin-top:3px;display:flex;gap:8px;flex-wrap:wrap;">
            <span>{{ c.minOrder > 0 ? fmt(c.minOrder) + ' 이상' : '최소금액 없음' }}</span>
            <span>·</span>
            <span>~ {{ c.expiry }}</span>
          </div>
        </div>
        <div style="font-size:1rem;font-weight:800;color:var(--blue);flex-shrink:0;background:var(--blue-dim);border:1px solid var(--border);border-radius:8px;padding:4px 10px;">
          {{ discountLabel(c) }}
        </div>
      </div>
      <div v-if="!productCoupons(cfOrderItems[couponPopup.targetIdx]).length"
          style="text-align:center;padding:40px 20px;color:var(--text-muted);font-size:0.88rem;background:var(--bg-base);border-radius:10px;border:1px dashed var(--border);">
        🪙 이 상품에 적용 가능한 쿠폰이 없습니다.
      </div>
    </template>
  </div>
</fo-modal>
<!-- ===== □. ══ 상품 쿠폰 팝업 ══ ========================================== -->
<!-- ===== ■. ══ 배송비 쿠폰 팝업 ══ ========================================= -->
<fo-modal :show="uiState.shipCouponPopup && cfOrderItems.length > 0" title="🚚 배송비 쿠폰 선택" max-width="440px" max-height="72vh"
  @close="fnCallbackModal('shipCoupon', null, 'close')">
  <div style="font-size:0.76rem;color:var(--text-muted);margin-bottom:12px;">
    배송비 할인 쿠폰만 표시됩니다
  </div>
  <div style="display:flex;flex-direction:column;gap:8px;">
    <!-- 쿠폰 없음 -->
    <div @click="fnCallbackModal('shipCoupon', null, null)"
        style="padding:14px 16px;border-radius:10px;border:1.5px solid var(--border);background:var(--bg-card);cursor:pointer;display:flex;align-items:center;gap:12px;transition:all .15s;"
        :style="!uiState.selectedShipCoupon ? 'border-color:var(--text-muted);background:var(--bg-base);' : ''">
      <div style="width:38px;height:38px;border-radius:10px;background:var(--bg-base);display:flex;align-items:center;justify-content:center;font-size:1.2rem;flex-shrink:0;color:var(--text-muted);">
        🚫
      </div>
      <div style="font-size:0.9rem;font-weight:600;color:var(--text-secondary);">
        쿠폰 사용 안 함
      </div>
    </div>
    <div v-for="c in cfShippingCoupons" :key="c.couponId"
        @click="fnCallbackModal('shipCoupon', null, c)"
        :style="{
          padding:'14px 16px', borderRadius:'10px', cursor:'pointer',
          display:'flex', alignItems:'center', gap:'12px', transition:'all .15s',
          border: uiState.selectedShipCoupon ? (uiState.selectedShipCoupon.couponId===c.couponId ? '2px solid var(--green)' : '1.5px solid var(--border)') : '1.5px solid var(--border)',
          background: uiState.selectedShipCoupon ? (uiState.selectedShipCoupon.couponId===c.couponId ? 'var(--green-dim)' : 'var(--bg-card)') : 'var(--bg-card)',
        }">
      <div style="width:44px;height:44px;border-radius:10px;background:var(--green-dim);display:flex;align-items:center;justify-content:center;font-size:1.3rem;flex-shrink:0;">
        🚚
      </div>
      <div style="flex:1;min-width:0;">
        <div style="font-size:0.9rem;font-weight:700;color:var(--text-primary);">
          {{ c.name }}
        </div>
        <div style="font-size:0.74rem;color:var(--text-muted);margin-top:3px;">
          ~ {{ c.expiry }}
        </div>
      </div>
      <div style="font-size:0.9rem;font-weight:800;color:var(--green);flex-shrink:0;background:var(--green-dim);border:1px solid var(--border);border-radius:8px;padding:4px 10px;">
        무료배송
      </div>
    </div>
    <div v-if="!cfShippingCoupons.length"
        style="text-align:center;padding:40px 20px;color:var(--text-muted);font-size:0.88rem;background:var(--bg-base);border-radius:10px;border:1px dashed var(--border);">
      🪙 보유한 배송비 쿠폰이 없습니다.
    </div>
  </div>
</fo-modal>
<!-- ===== ■. 주소 검색 모달 (카카오 우편번호, 인라인 레이어) ============================ -->
<fo-addr-search-modal v-if="modals.isAddrSearchModal" modal-name="addr-search" :on-callback="fnCallbackModal" />
</fo-page>
<!-- ===== □. ══ 배송비 쿠폰 팝업 ══ ========================================= -->
`
};
