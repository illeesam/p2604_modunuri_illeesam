/* ShopJoy Admin - 게시판관리 상세/등록 */
export default {
  name: 'SyBbmDtl',
  props: {
    navigate:    { type: Function, required: true }, // 페이지 이동
    dtlId:       { type: String, default: null }, // 수정 대상 ID
    dtlMode:     { type: String, default: 'view' }, // 상세 모드 (new/view/edit),
    active:      { type: Boolean, default: true }, // false=행 미선택 빈 폼(저장/취소 등 버튼 숨김)
    reloadTrigger: { type: Number, default: 0 }, // reload signal from parent Mng // 첫 탭 저장 시 상위 Mng 재조회 (UX-bo §18)
  },
  setup(props) {

    /* ##### [01] 초기 변수 정의 #################################################### */

    const { reactive, computed, watch, onMounted, ref } = Vue;
    const showToast    = window.boApp.showToast;  // 토스트 알림
    const showConfirm  = window.boApp.showConfirm;  // 확인 모달

    const modals = reactive({ isPathPickModal: false });
    const uiState = reactive({ loading: false, error: null });
    const codes = reactive({ BBM_TYPE: [], BBM_COMMENT_TYPE: [], BBM_ATTACH_TYPE: [], BBM_CONTENT_TYPE: [], BBM_SCOPE_TYPE: [], USE_YN: [],
      ALLOW_YN: [],
    });

    const cfIsNew = computed(() => props.dtlId === null || props.dtlId === undefined);
    const cfSiteNm = computed(() => boUtil.bofGetSiteNm());
    const cfDtlMode = computed(() => props.dtlMode === 'view'); // dtlMode: 'view'이면 읽기전용

    const form = reactive({
      bbmId: null, bbmCode: '', bbmNm: '', bbmTypeCd: '',
      allowComment: '', allowAttach: '', allowLike: '',
      contentTypeCd: '', scopeTypeCd: '',
      sortOrd: '', useYn: '', bbmRemark: '', pathId: null,
    });
    // 신규 진입 시에만 채울 기본값 (미선택/검색초기화 inactive 상태에서는 빈 폼 유지)
    /* 2026-08-29 버그수정: '일반'/'불가'/'공개' 처럼 실제 codeValue 가 아닌 한글
       placeholder 를 하드코딩해뒀던 탓에, 해당 코드그룹 옵션 중 어느 것과도 일치하지
       않아 select 가 빈 값으로 보였다. 신규 등록 입력을 최소화하려는 목적이므로,
       각 코드그룹의 "첫 번째 옵션"을 기본 선택해둔다(이 함수는 initPage 에서
       fnLoadCodes() 완료 후에만 호출되므로 codes.* 는 이미 채워져 있다). */
    const _applyNewDefaults = () => {
      Object.assign(form, {
        bbmTypeCd: codes.BBM_TYPE[0]?.codeValue || '',
        allowComment: codes.BBM_COMMENT_TYPE[0]?.codeValue || '',
        allowAttach: codes.BBM_ATTACH_TYPE[0]?.codeValue || '',
        allowLike: codes.ALLOW_YN[0]?.codeValue || 'N',
        contentTypeCd: codes.BBM_CONTENT_TYPE[0]?.codeValue || 'textarea',
        scopeTypeCd: codes.BBM_SCOPE_TYPE[0]?.codeValue || '',
        sortOrd: 1, useYn: codes.USE_YN[0]?.codeValue || 'Y',
      });
    };
    const errors = reactive({});

    /* ── 표시경로 모달 ── */

    const schema = yup.object({
      bbmCode: yup.string().required('게시판코드를 입력해주세요.'),
      bbmNm: yup.string().required('게시판명을 입력해주세요.'),
    });

    /* ##### [02] 액션 모음 (dispatch) ############################################## */

    /* handleBtnAction — 버튼 액션 dispatch (cmd: '{영역명}-기능명'). 5줄 이하 짧은 로직은 인라인 */
    const handleBtnAction = (cmd, param = {}) => {
      console.log(' ■■ SyBbmDtl.js : handleBtnAction -> ', cmd, param);
      // 폼 저장 (신규 등록 또는 수정)
      if (cmd === 'form-save') {
        return handleSave();
      // 폼 편집 취소 → 상세영역 유지 + 빈 신규 폼으로 초기화 (영역 사라지지 않음)
      } else if (cmd === 'form-cancel') {
        return props.navigate('__cancelEdit__');
      // 상세 보기 → 편집 모드 전환
      } else if (cmd === 'form-edit') {
        return props.navigate('__switchToEdit__');
      // 폼 닫기 → 상세영역 유지 + 빈 신규 폼으로 초기화
      } else if (cmd === 'form-close') {
        return props.navigate('__closeDtl__');
      // 보기모드에서 바로 삭제 (2026-08-22 정책: 보기모드 표준 버튼 = [수정][삭제][닫기])
      } else if (cmd === 'form-delete') {
        return handleDelete();
      // 표시경로 picker 열기
      } else if (cmd === 'pathModal-open') {
        modals.isPathPickModal = true;
        return;
      // 표시경로 picker 닫기
      } else if (cmd === 'pathModal-close') {
        modals.isPathPickModal = false;
        return;
      } else {
        console.warn('[handleBtnAction] unknown cmd:', cmd);
      }
    };

    /* handleSelectAction — 그리드 행/노드/모달 선택 액션 dispatch (cmd: '{영역명}-기능명'). 5줄 이하 짧은 로직은 인라인 */
    const handleSelectAction = (cmd, param = {}) => {
      console.log(' ■■ SyBbmDtl.js : handleSelectAction -> ', cmd, param);
      // 표시경로 모달에서 경로 선택 → form.pathId 갱신
      if (cmd === 'pathModal-pick') {
        form.pathId = param;
        modals.isPathPickModal = false;
        return;
      } else {
        console.warn('[handleSelectAction] unknown cmd:', cmd);
      }
    };


    /* fnCallbackModal — 모든 모달 통합 dispatch. cmd=모달명, param=호출 시 파라미터, result=응답 결과 */
    const fnCallbackModal = (popCmd, param, result) => {
      console.log(' ■■ SyBbmDtl : fnCallbackModal -> ', popCmd, param, result);
      if (popCmd === 'cmPopup-path-pick') {
        if (result == null) {
          modals.isPathPickModal = false;
          return;
        }
        form.pathId = result;
        modals.isPathPickModal = false;
        return;
      } else {
        console.warn('[fnCallbackModal] unknown popCmd:', popCmd);
      }
    };

    /* ##### [04] 내장 사용 함수 (이벤트 핸들러 on* / handle*) #################### */

    /* pathLabel — 경로 라벨 */
    const pathLabel = (id) => boUtil.bofGetPathLabel(id) || (id == null ? '' : ('#' + id));

    /* fnLoadCodes — 공통코드 로드 */
    const fnLoadCodes = async () => {
      try {
        const codeStore = window.sfGetBoCodeStore();
        /* 필요한 코드그룹만 지연 로딩 — 캐시에 있으면 API 가 나가지 않는다 */
        await codeStore.saLoadCodes(['BBM_TYPE_CD', 'BBM_COMMENT_TYPE', 'BBM_ATTACH_TYPE', 'BBM_CONTENT_TYPE', 'SCOPE_TYPE_CD', 'USE_YN', 'ALLOW_YN'], {compNm: 'SyBbmDtl'});
        codes.BBM_TYPE = codeStore.sgGetGrpCodes('BBM_TYPE_CD');
        codes.BBM_COMMENT_TYPE = codeStore.sgGetGrpCodes('BBM_COMMENT_TYPE');
        codes.BBM_ATTACH_TYPE = codeStore.sgGetGrpCodes('BBM_ATTACH_TYPE');
        codes.BBM_CONTENT_TYPE = codeStore.sgGetGrpCodes('BBM_CONTENT_TYPE');
        codes.BBM_SCOPE_TYPE = codeStore.sgGetGrpCodes('SCOPE_TYPE_CD');
        codes.USE_YN       = codeStore.sgGetGrpCodes('USE_YN');
        codes.ALLOW_YN = codeStore.sgGetGrpCodes('ALLOW_YN');
      } catch (err) {
        console.error('[fnLoadCodes]', err);
      }
    };


    /* handleLoadDetail — 상세 조회 */
    const handleLoadDetail = async () => {
      if (cfIsNew.value) { return; }
      uiState.loading = true;
      try {
        const res = await boApiSvc.syBbm.getById(props.dtlId, '게시판모드관리', '상세조회');
        const data = res.data?.data;
        if (data) { Object.assign(form, data); }
        uiState.error = null;
      } catch (err) {
        console.error('[catch-info]', err);
        uiState.error = err.message;
      } finally {
        uiState.loading = false;
      }
    };

    /* handleDelete — 보기모드 [삭제] (2026-08-22 정책: 보기모드 표준 버튼 = [수정][삭제][닫기]) */
    const handleDelete = async () => {
      if (cfIsNew.value || !form.bbmId) { return; }
      const ok = await showConfirm('삭제', `[${form.bbmNm}]을 삭제하시겠습니까?`);
      if (!ok) { return; }
      try {
        await boApiSvc.syBbm.remove(form.bbmId, '게시판모드관리', '삭제');
        showToast('삭제되었습니다.', 'success');
        props.navigate('syBbmMng', { reload: true });
      } catch (err) {
        console.error('[catch-info]', err);
        const errMsg = (err.response?.data?.message) || err.message || '오류가 발생했습니다.';
        if (showToast) { showToast(errMsg, 'error', 0); }
      }
    };

    // ★ onMounted — 진입 시 코드 로드 + 상세 조회
    /* initPage — 화면 로드 시퀀스.
       코드 응답을 받은 뒤 초기 조회를 시작한다 — 코드 기반 select·라벨·기본값이
       빈 상태로 첫 조회가 나가는 것을 막는다(순서가 코드에 드러나도록 한 곳에 모았다). */
    const initPage = async () => {
      await fnLoadCodes();
      if (!cfIsNew.value) { await handleLoadDetail(); }
      if (props.active && cfIsNew.value) { _applyNewDefaults(); }
    };
    onMounted(initPage);
    /* policy: re-fetch detail API whenever parent Mng increments reloadTrigger */
    watch(() => props.reloadTrigger, async (n, o) => {
      if (n === o || n === 0) { return; }
      try { Object.keys(errors).forEach(k => delete errors[k]); } catch(_) {}
      await handleLoadDetail();
    });

    /* handleSave — 저장 */
    const handleSave = async () => {
      Object.keys(errors).forEach(k => delete errors[k]);
      try {
        await schema.validate(form, { abortEarly: false });
      } catch (err) {
        console.error('[catch-info]', err);
        err.inner.forEach(e => { errors[e.path] = e.message; });
        showToast('입력 내용을 확인해주세요.', 'error');
        return;
      }
      const ok = await showConfirm(cfIsNew.value ? '등록' : '저장', cfIsNew.value ? '등록하시겠습니까?' : '저장하시겠습니까?');
      if (!ok) { return; }
      try {
        const res = await (cfIsNew.value ? boApiSvc.syBbm.create({ ...form }, '게시판모드관리', '등록') : boApiSvc.syBbm.update(form.bbmId, { ...form }, '게시판모드관리', '저장'));
        if (showToast) { showToast(cfIsNew.value ? '등록되었습니다.' : '저장되었습니다.', 'success'); }
        if (props.navigate) { props.navigate('syBbmMng', { reload: true }); }
      } catch (err) {
        console.error('[catch-info]', err);
        const errMsg = (err.response?.data?.message) || err.message || '오류가 발생했습니다.';
        if (showToast) { showToast(errMsg, 'error', 0); }
      }
    };

    /* ##### [05] 사용자 함수 (헬퍼 / 카운트 / 렌더 / 컬럼정의) #################### */

    // 기본 폼
    const columns = {};
    columns.baseForm = [
      { type: 'group', label: '게시판 설정' },
      { key: '_siteNm',       label: '사이트명',    type: 'readonly', fmt: () => cfSiteNm.value, colSpan: 3 },
      { key: 'bbmCode',       label: '게시판코드',  type: 'text', required: true, mono: true, placeholder: 'BOARD_CODE' },
      { key: 'bbmNm',         label: '게시판명',    type: 'text', required: true, placeholder: '게시판명' },
      { key: 'bbmTypeCd',     label: '유형',        type: 'select', options: () => codes.BBM_TYPE },
      { key: 'allowComment',  label: '댓글허용',    type: 'select', options: () => codes.BBM_COMMENT_TYPE },
      { key: 'allowAttach',   label: '첨부허용',    type: 'select', options: () => codes.BBM_ATTACH_TYPE },
      { key: 'allowLike',     label: '좋아요허용',  type: 'select', options: () => codes.ALLOW_YN },
      { key: 'contentTypeCd', label: '내용입력',    type: 'select', options: () => codes.BBM_CONTENT_TYPE },
      { key: 'scopeTypeCd',   label: '공개범위',    type: 'select', options: () => codes.BBM_SCOPE_TYPE },
      { key: 'pathId',        label: '표시경로',    type: 'pathPick',
        pathLabel: (id) => pathLabel(id),
        onOpen: () => handleBtnAction('pathModal-open') },
      { key: 'sortOrd',       label: '정렬순서',    type: 'number', min: 1 },
      { key: 'useYn',         label: '사용여부',    type: 'select', options: () => codes.USE_YN },
      { key: 'bbmRemark',     label: '비고',        type: 'text', placeholder: '비고' },
    ];

    /* fnShareUrl — 이 게시판모드 상세를 가리키는 독립 새창 딥링크 URL 생성 */
    const fnShareUrl = () => {
      const qs = new URLSearchParams();
      qs.set('page', 'syBbmDtl');
      qs.set('id', form.bbmId);
      qs.set('embed', '1');
      return `${window.location.origin}${window.location.pathname}?${qs.toString()}`;
    };
    /* handleShareKakao — 카카오톡 공유(피드 카드, 상세보기 모드 전용) */
    const handleShareKakao = () => {
      try {
        window.coExtSdk.shareKakao({
          title: `게시판모드 ${form.bbmId} - ShopJoy BO`,
          description: form.bbmNm || '',
          imageUrl: window.location.origin + '/assets/img/shopjoy-share-og.png',
          url: fnShareUrl(),
        });
      } catch (e) {
        showToast(e.message || '카카오톡 공유를 열 수 없습니다.', 'error', 0);
      }
    };
    /* handleCopyLink — 순수 URL만 클립보드에 복사 (카카오톡 카드 없음) */
    const handleCopyLink = async () => {
      try {
        await navigator.clipboard.writeText(fnShareUrl());
        showToast('링크가 복사되었습니다.', 'success');
      } catch (e) {
        showToast(e.message || '링크 복사에 실패했습니다.', 'error', 0);
      }
    };
    /* pdfAreaRef — 게시판모드 상세 카드 캡처 대상. handleExportPdf — PDF 다운로드(항상 노출) */
    const pdfAreaRef = ref(null);
    const pdfExporting = ref(false);
    const handleExportPdf = async () => {
      pdfExporting.value = true;
      try {
        const filename = coUtil.cofBuildExportFilename(`게시판모드상세_${form.bbmId}.pdf`);
        await window.boUtil.bofExportPdf(pdfAreaRef.value, filename, showToast);
      } finally {
        pdfExporting.value = false;
      }
    };

    /* ##### [06] return (템플릿 노출) ############################################## */

    return {

      modals,   // 모달 표시 상태 모음
      columns,
      handleShareKakao, handleCopyLink,                                    // 카카오톡 공유 / 링크 복사 (상세보기)
      pdfAreaRef, pdfExporting, handleExportPdf,                           // PDF 다운로드 (항상 노출)
      form, errors, // 상태 / 데이터
      handleBtnAction, handleSelectAction, fnCallbackModal,                 // dispatch (모든 이벤트 / 액션 라우팅)
      cfIsNew, cfDtlMode,          // computed
    };
  },
  template: /* html */`
<div ref="pdfAreaRef">
<bo-container :title="!active ? '게시판 상세' : (cfIsNew ? '게시판 등록' : (cfDtlMode ? '게시판 상세' : '게시판 수정'))"
  :title-id="!active ? '' : (cfIsNew ? '' : form.bbmId)">
  <template #toolbar-actions>
    <button v-if="active ? (cfDtlMode ? !cfIsNew : false) : false" class="btn btn_link" title="링크 공유(URL만)" @click="handleCopyLink">🔗</button>
    <button v-if="active ? (cfDtlMode ? !cfIsNew : false) : false" class="btn btn_kakao" title="카카오톡 공유" @click="handleShareKakao">💬</button>
    <button class="btn btn_pdf" title="PDF 다운로드" :disabled="pdfExporting" @click="handleExportPdf">
      <span v-if="pdfExporting">⏳</span>
      <svg v-else width="18" height="20" viewBox="0 0 32 36" xmlns="http://www.w3.org/2000/svg">
        <path d="M4 2 H20 L28 10 V34 H4 Z" fill="#fff" stroke="#c2410c" stroke-width="1.5"/>
        <path d="M20 2 V10 H28 Z" fill="#f3d4c0"/>
        <rect x="2" y="20" width="28" height="12" rx="2" fill="#e2372c"/>
        <text x="16" y="29" font-family="Arial, sans-serif" font-size="10" font-weight="700" fill="#fff" text-anchor="middle">PDF</text>
      </svg>
    </button>
  </template>
  <!-- ===== ■.■. 폼 영역 ================================================== -->
  <bo-form-area plain-readonly :columns="columns.baseForm" :form="form" :errors="errors"
    :readonly="cfDtlMode" :cols="3" compact :show-actions="active" :show-cancel="!cfIsNew" :show-delete="!cfIsNew"
    @save="handleBtnAction('form-save')"
    @cancel="handleBtnAction('form-cancel')"
    @edit="handleBtnAction('form-edit')"
    @close="handleBtnAction('form-close')"
    @delete="handleBtnAction('form-delete')" />
  <!-- ===== □.□. 폼 영역 ================================================== -->
  <!-- ===== □. 카드 영역 =================================================== -->
  <!-- ===== ■. 표시경로 선택 모달 ============================================== -->
  <!-- ===== ■. 조건부 영역 ================================================== -->
  <bo-cm-popup-modal v-if="modals.isPathPickModal" popup-cmd="cmPopup-path-pick" popup-code="path" result-type="id" :init-param="{ bizCd: 'sy_bbm' }" title="게시판 표시경로 선택" :on-callback="fnCallbackModal" />
</bo-container>
</div>
<!-- ===== □. 조건부 영역 ================================================== -->
`
};
