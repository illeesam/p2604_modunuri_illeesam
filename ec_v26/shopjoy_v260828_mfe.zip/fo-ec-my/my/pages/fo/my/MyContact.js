/* ShopJoy - My 문의 페이지 (?page=myContact) */
export default {
  name: 'MyContact',
  props: {
    navigate:    { type: Function, required: true },                    // 페이지 이동
  },
  setup(props) {

    /* ##### [01] 초기 변수 정의 ################################################## */

    const { reactive, computed, ref, onMounted, watch } = Vue;
    const showToast            = window.foApp.showToast;  // 토스트 알림
    const showConfirm          = window.foApp.showConfirm;  // 확인 모달
    const cart                 = window.foApp.cart;  // 장바구니

    const uiState = reactive({ loading: false, error: null });
    /* contentRefTableNm/answerRefTableNm — sy_attach.ref_table_nm 실제 값. 백엔드
       SyAttachRefTableConst.OPTIONS 에서 각각 key='CONTACT_CONTENT'/'CONTACT_ANSWER' 항목을
       찾아 채운다(coUtil.cofGetAttachRefTableOptions, initPage 에서 로드). */
    const contentRefTableNm = ref('');
    const answerRefTableNm  = ref('');
    const fnLoadRefTableNm = async () => {
      const opts = await coUtil.cofGetAttachRefTableOptions();
      contentRefTableNm.value = opts.find(o => o.key === 'CONTACT_CONTENT')?.value || '';
      answerRefTableNm.value  = opts.find(o => o.key === 'CONTACT_ANSWER')?.value || '';
    };


    const myStore = window.useFoMyStore();

    /* ##### [02] 액션 모음 (dispatch) ############################################## */

    /* handleBtnAction — 버튼 액션 dispatch (cmd: '{영역명}-기능명'). 5줄 이하 짧은 로직은 인라인 */
    const handleBtnAction = (cmd, param = {}) => {
      console.log(' ■■ MyContact.js : handleBtnAction -> ', cmd, param);
      // 날짜 필터 조회
      if (cmd === 'searchParam-dateSearch') {
        return onSearch(param);
      } else {
        console.warn('[handleBtnAction] unknown cmd:', cmd);
      }
    };

    /* handleSelectAction — 행/선택 액션 dispatch (cmd: '{영역명}-기능명'). 5줄 이하 짧은 로직은 인라인 */
    const handleSelectAction = (cmd, param = {}) => {
      console.log(' ■■ MyContact.js : handleSelectAction -> ', cmd, param);
      // 문의 펼침 토글
      if (cmd === 'contacts-toggle') {
        expandedInquiry.value = expandedInquiry.value === param ? null : param;
      // 문의 취소
      } else if (cmd === 'contacts-cancel') {
        return cancelInquiry(param);
      } else {
        console.warn('[handleSelectAction] unknown cmd:', cmd);
      }
    };

    /* ##### [03] 초기 함수 (마운트 / 코드 로드 / watch) ############################## */


    const { inquiries, expandedInquiry } = Pinia.storeToRefs(myStore);

    const inquiryPager = reactive({ pageType: 'PAGE', pageNo: 1, pageSize: 50, pageTotalCount: 0, pageTotalPage: 1, pageSizes: [5, 10, 20, 30, 50, 100, 200, 500], pageCond: {} });

    const { dateRange, onDateSearch } = window.myDateFilterHelper();

    /* cancelInquiry — 취소 */
    const cancelInquiry = async id => {
      const ok = await showConfirm('문의 취소', '이 문의를 취소하시겠습니까?', 'warning');
      if (!ok) { return; }
      const item = inquiries.value.find(x => x.inquiryId === id);
      if (item) { item.status = '취소됨'; }
      showToast('문의가 취소되었습니다.', 'success');
    };

    /* fnBuildParams — 현재 검색조건(기간) → 서버 파라미터 */
    const fnBuildParams = () => ({ dateRangeType: 'reg_date', dateRangeStart: dateRange.start, dateRangeEnd: dateRange.end });

    /* handleLoadPage — 서버사이드 페이징 조회 (현재 inquiryPager 기준) */
    const handleLoadPage = async () => {
      await myStore.loadInquiriesPage(fnBuildParams(), inquiryPager);
    };

    /* handleSearchData — 초기/조회 진입점 */
    const handleSearchData = async () => { await handleLoadPage(); };

    /* ##### [04] 내장 사용 함수 (이벤트 핸들러 on* / handle*) #################### */

    /* onSearch — 조회 (기간 변경) → 1페이지부터 서버 재조회 */
    const onSearch = async (dateParams) => {
      if (dateParams) { onDateSearch(dateParams); }
      inquiryPager.pageNo = 1;
      await handleLoadPage();
    };

    /* onPageChange — 페이지 버튼 클릭 → 서버 재조회 (페이징 정책) */
    const onPageChange = async () => { await handleLoadPage(); };

    /* onSizeChange — 페이지크기 변경 → 서버 재조회 */
    const onSizeChange = async () => { await handleLoadPage(); };
    /* initPage — 화면 로드 시퀀스. 마운트 시 초기 조회를 실행한다. */
    const initPage = async () => {
      await fnLoadRefTableNm();
      await handleSearchData();
    };
    onMounted(initPage);

    /* ##### [06] return (템플릿 노출) ############################################## */

    const cartCount = computed(() => cart.length);

    return {
      handleBtnAction, handleSelectAction, // dispatch
      myStore, inquiries, expandedInquiry,
      inquiryPager, onPageChange, onSizeChange, cartCount,
      contentRefTableNm, answerRefTableNm,
    };
  },
  template: /* html */ `
<fo-page bare>
<fo-my-layout :navigate="navigate" :cart-count="cartCount" active-page="myContact">
  <MyDateFilter @search="handleBtnAction('searchParam-dateSearch', $event)" />
  <!-- ===== ■. 영역 ====================================================== -->
  <PagerHeader :total="inquiryPager.pageTotalCount" :pager="inquiryPager" @size-change="onSizeChange" />
  <!-- ===== ■. 조건부 영역 ================================================== -->
  <div v-if="!inquiries.length" style="text-align:center;padding:60px 0;color:var(--text-muted);">
    문의 내역이 없습니다.
  </div>
  <!-- ===== ■. 영역 ====================================================== -->
  <div v-for="q in inquiries" :key="q.inquiryId"
    style="background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius);padding:16px;margin-bottom:10px;">
    <div style="display:flex;align-items:flex-start;gap:12px;">
      <div style="flex:1;cursor:pointer;" @click="handleSelectAction('contacts-toggle', q.inquiryId)">
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px;">
          <span style="font-size:0.75rem;font-weight:700;padding:3px 8px;border-radius:20px;color:#fff;"
            :style="'background:'+myStore.inquiryStatusColor(q.status)">
            {{ q.status }}
          </span>
          <span style="font-size:0.78rem;color:var(--text-muted);">
            {{ q.category }}
          </span>
          <span style="font-size:0.78rem;color:var(--text-muted);">
            {{ q.date }}
          </span>
        </div>
        <div style="font-weight:600;font-size:0.9rem;color:var(--text-primary);">
          {{ q.title }}
        </div>
      </div>
      <button v-if="q.status==='요청'" @click="handleSelectAction('contacts-cancel', q.inquiryId)"
        style="padding:6px 14px;border:1.5px solid #ef4444;border-radius:6px;background:transparent;color:#ef4444;cursor:pointer;font-size:0.8rem;font-weight:600;white-space:nowrap;">
        취소
      </button>
    </div>
    <div v-if="expandedInquiry===q.inquiryId" style="margin-top:12px;padding-top:12px;border-top:1px solid var(--border);">
      <div style="background:var(--bg-base);border-radius:6px;padding:12px;font-size:0.85rem;color:var(--text-secondary);margin-bottom:10px;">
        {{ q.content }}
      </div>
      <!-- ===== ■.■. 문의 첨부파일 ============================================ -->
      <div style="margin-bottom:10px;">
        <div style="font-size:0.78rem;font-weight:600;color:var(--text-muted);margin-bottom:4px;">
          📎 첨부파일
        </div>
        <base-attach-grp :ref-table-nm="contentRefTableNm" :ref-key-id="q.inquiryId" :ref-id="q.inquiryId"
          grp-code="CONTACT_CONTENT_ATTACH" grp-nm="문의 첨부파일"
          display-mode="list" :readonly="true" />
      </div>
      <div v-if="q.answer" style="background:var(--blue-dim);border-radius:6px;padding:12px;font-size:0.85rem;color:var(--text-primary);">
        <span style="font-size:0.78rem;font-weight:700;color:var(--blue);display:block;margin-bottom:4px;">
          📩 답변
        </span>
        {{ q.answer }}
      </div>
      <!-- ===== ■.■. 답변 첨부파일 ============================================ -->
      <div v-if="q.answer" style="margin-top:10px;">
        <div style="font-size:0.78rem;font-weight:600;color:var(--text-muted);margin-bottom:4px;">
          📎 답변 첨부파일
        </div>
        <base-attach-grp :ref-table-nm="answerRefTableNm" :ref-key-id="q.inquiryId" :ref-id="q.inquiryId"
          grp-code="CONTACT_ANSWER_ATTACH" grp-nm="답변 첨부파일"
          display-mode="list" :readonly="true" />
      </div>
    </div>
  </div>
  <!-- ===== □. 영역 ====================================================== -->
  <!-- ===== ■. 영역 ====================================================== -->
  <Pagination :total="inquiryPager.pageTotalCount" :pager="inquiryPager" @set-page="onPageChange" />
</fo-my-layout>
<!-- ===== □. 영역 ====================================================== -->
</fo-page>
`,
  components: {
    FoPage:      window.FoPage,
    FoMyLayout:    window.foMyLayout,
    PagerHeader: window.PagerHeader,
    Pagination:  window.Pagination,
  }
};
