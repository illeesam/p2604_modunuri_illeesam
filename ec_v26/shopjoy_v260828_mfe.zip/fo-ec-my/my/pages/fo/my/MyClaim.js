﻿/* ShopJoy - My 취소/반품/교환 페이지 (?page=myClaim) */
export default {
  name: 'MyClaim',
  props: {
    navigate:    { type: Function, required: true },                    // 페이지 이동
  },
  setup(props) {

    /* ##### [01] 초기 변수 정의 ################################################## */

    const { reactive, computed, onMounted, watch } = Vue;
    const showToast            = window.foApp.showToast;  // 토스트 알림
    const showConfirm          = window.foApp.showConfirm;  // 확인 모달
    const cart                 = window.foApp.cart;  // 장바구니

    const uiState = reactive({ loading: false, error: null });


    /* ##### [02] 액션 모음 (dispatch) ############################################## */

    /* handleBtnAction — 버튼 액션 dispatch (cmd: '{영역명}-기능명'). 5줄 이하 짧은 로직은 인라인 */
    const handleBtnAction = (cmd, param = {}) => {
      console.log(' ■■ MyClaim.js : handleBtnAction -> ', cmd, param);
      // 클레임 유형 필터 변경 (전체/취소/반품/교환) → 1페이지부터 서버 재조회 (claimTypeCd)
      if (cmd === 'claims-setFilter') {
        claimFilter.value = param;
        claimStatusFilter.splice(0);
        pager.pageNo = 1;
        return handleLoadPage();
      // 상태 필터 초기화
      } else if (cmd === 'claims-statusReset') {
        claimStatusFilter.splice(0);
      } else {
        console.warn('[handleBtnAction] unknown cmd:', cmd);
      }
    };

    /* handleSelectAction — 행/선택 액션 dispatch (cmd: '{영역명}-기능명'). 5줄 이하 짧은 로직은 인라인 */
    const handleSelectAction = (cmd, param = {}) => {
      console.log(' ■■ MyClaim.js : handleSelectAction -> ', cmd, param);
      // 클레임 상태 토글 (다중선택 단계 필터) — 현재 서버 페이지 내 표시 구분(클라이언트 refine)
      if (cmd === 'claims-statusToggle') {
        toggleClaimStatus(param);
      // 클레임 신청 취소
      } else if (cmd === 'claims-cancel') {
        return cancelClaim(param);
      // 주문 모달 열기
      } else if (cmd === 'claims-orderOpen') {
        return openOrderModal(param);
      // 주문자 모달 열기
      } else if (cmd === 'claims-customerOpen') {
        return openCustomerModal(param);
      // 상품 모달 열기
      } else if (cmd === 'claims-prodOpen') {
        return openProdModal(param);
      // 배송 추적 (작은 버튼)
      } else if (cmd === 'claims-track') {
        return openTracking2(param.courier, param.trackingNo);
      } else {
        console.warn('[handleSelectAction] unknown cmd:', cmd);
      }
    };

    /* fnCallbackModal — 모든 모달 통합 dispatch. cmd=모달명, param=호출 시 파라미터, result=응답 결과 */
    const fnCallbackModal = (popCmd, param, result) => {
      console.log(' ■■ MyClaim : fnCallbackModal -> ', popCmd, param, result);
      if (popCmd === 'order-detail') {
        if (result == null) { myStore.orderDetailModal.show = false; return; }
        return;
      } else if (popCmd === 'product') {
        if (result == null) { myStore.productModal.show = false; return; }
        return;
      } else if (popCmd === 'customer') {
        if (result == null) { myStore.customerModal.show = false; return; }
        return;
      } else {
        console.warn('[fnCallbackModal] unknown popCmd:', popCmd);
      }
    };

    /* ##### [03] 초기 함수 (마운트 / 코드 로드 / watch) ############################## */


    const myStore = window.useFoMyStore();
    const { claims, claimFilter, orders } = Pinia.storeToRefs(myStore);

    const pager = reactive({ pageType: 'PAGE', pageNo: 1, pageSize: 50, pageTotalCount: 0, pageTotalPage: 1, pageSizes: [5, 10, 20, 30, 50, 100, 200, 500], pageCond: {} });

    const { dateRange, onDateSearch } = window.myDateFilterHelper();
    const claimStatusFilter = reactive([]);

    /* 유형 필터 라벨(전체/취소/반품/교환) → 서버 claimTypeCd 코드값 매핑 */
    const CLAIM_TYPE_CD = { '취소': 'CANCEL', '반품': 'RETURN', '교환': 'EXCHANGE' };

    /* toggleClaimStatus — 토글 */
    const toggleClaimStatus = (step) => {
      const idx = claimStatusFilter.indexOf(step);
      if (idx === -1) { claimStatusFilter.push(step); }
      else { claimStatusFilter.splice(idx, 1); }
    };
    // 날짜/기간·유형(claimTypeCd) 필터는 서버(API)가 처리 — claims 는 이미 현재 페이지 결과.
    // 클레임상태 토글(다중선택)만 현재 서버 페이지 안에서 클라이언트 표시 구분.
    const cfDateFilteredClaims = computed(() => claims.value
      .filter(c => !claimStatusFilter.length || claimStatusFilter.includes(c.status))
    );

    const cfAuthUser = computed(() => window.foAuth.state.user);

    /* findProd — 찾기 상품 */
    /* SITE_CONFIG.prods 는 상품목록 화면이 채운다 — 마이페이지로 바로 들어오면 없다.
       가드 없이 .find 를 부르면 TypeError 로 화면이 통째로 안 뜬다. */
    const findProd = (name) => {
      const list = window.SITE_CONFIG && window.SITE_CONFIG.prods;
      if (!Array.isArray(list)) return null;
      return list.find(p => p.prodNm === name) || null;
    };

    /* openProdModal — 열기 */
    const openProdModal = name => {
      const p = findProd(name);
      if (p) { myStore.productModal.prod = p; myStore.productModal.show = true; }
    };

    /* openCustomerModal — 열기 */
    const openCustomerModal = order => {
      myStore.customerModal.user = cfAuthUser.value;
      myStore.customerModal.order = order || null;
      myStore.customerModal.show = true;
    };

    /* openOrderModal — 열기 */
    const openOrderModal = async orderId => {
      await myStore.handleLoadOrders();
      const ok = myStore.openOrderModal(orderId);
      if (!ok) { showToast('주문 정보를 찾을 수 없습니다.', 'error'); }
    };

    /* openTracking2 — 열기 (택배사 송장조회 URL: coConsts.courierTrackUrl) */
    const openTracking2 = (courier, trackingNo) => {
      const url = coConsts.courierTrackUrl(courier, trackingNo);
      if (url) { window.open(url, '_blank', 'width=960,height=700,scrollbars=yes'); }
    };

    /* cancelClaim — 취소 */
    const cancelClaim = async claimId => {
      const ok = await showConfirm('신청 취소', '이 신청을 취소하시겠습니까?', 'warning');
      if (!ok) { return; }
      const item = claims.value.find(c => c.claimId === claimId);
      if (item) {
        item.status = item.type === '취소' ? '취소완료'
          : item.type === '반품' ? '반품취소됨'
          : '교환취소됨';
        myStore.removeClaim(claimId);
      }
      showToast('신청이 취소되었습니다.', 'info');
    };

    /* fnBuildParams — 현재 검색조건(기간 + 유형 claimTypeCd) → 서버 파라미터 */
    const fnBuildParams = () => {
      const p = { dateRangeType: 'request_date', dateRangeStart: dateRange.start, dateRangeEnd: dateRange.end };
      const typeCd = CLAIM_TYPE_CD[claimFilter.value];
      if (typeCd) { p.claimTypeCd = typeCd; }   // '전체'면 미전송
      return p;
    };

    /* handleLoadPage — 서버사이드 페이징 조회 (현재 pager 기준) */
    const handleLoadPage = async () => {
      await myStore.handleLoadClaimsPage(fnBuildParams(), pager);
    };

    /* ##### [04] 내장 사용 함수 (이벤트 핸들러 on* / handle*) #################### */

    /* onSearch — 조회 (기간 변경) → 1페이지부터 서버 재조회 */
    const onSearch = async (dateParams) => {
      if (dateParams) { onDateSearch(dateParams); }
      pager.pageNo = 1;
      await handleLoadPage();
      myStore.handleLoadOrders();
    };

    /* onPageChange — 페이지 버튼 클릭 → 서버 재조회 (페이징 정책) */
    const onPageChange = async () => { await handleLoadPage(); };

    /* onSizeChange — 페이지크기 변경 → 서버 재조회 */
    const onSizeChange = async () => { await handleLoadPage(); };

    /* initPage — 화면 로드 시퀀스. 마운트 시 실행한다. */
    const initPage = async () => {
      await handleLoadPage();
      myStore.handleLoadOrders();
    };
    onMounted(initPage);

    /* ##### [05] 사용자 함수 (헬퍼 / 카운트 / 렌더) ############################### */

    /* fnClaimStepCount — 클레임 유형/단계별 건수 (템플릿 속성값 && 회피용 헬퍼) */
    const fnClaimStepCount = (claimType, step) => claims.value.filter(c => c.type === claimType && c.status === step).length;

    /* fnShowPickupTrack — 수거완료 단계 운송장 추적 버튼 노출 여부 */
    const fnShowPickupTrack = (c, step) => {
      if (!c.trackingNo || step !== '수거완료') { return false; }
      const flows = myStore.CLAIM_FLOWS[c.type];
      return flows.indexOf(c.status) >= flows.indexOf('수거완료');
    };
    /* fnShowShipTrack — 발송완료 단계 운송장 추적 버튼 노출 여부 */
    const fnShowShipTrack = (c, step) => {
      if (!c.exchangeTrackingNo || step !== '발송완료') { return false; }
      const flows = myStore.CLAIM_FLOWS[c.type];
      return flows.indexOf(c.status) >= flows.indexOf('발송완료');
    };

    /* ##### [06] return (템플릿 노출) ############################################## */

    const cartCount = computed(() => cart.length);

    return {
      handleBtnAction, handleSelectAction, fnCallbackModal, // dispatch + 모달 통합 콜백
      myStore, claims, claimFilter, orders,
      pager, cfDateFilteredClaims, claimStatusFilter,
      onSearch, onPageChange, onSizeChange,
      // ===== shared (헬퍼) ====================================================
      cfAuthUser, findProd, fnClaimStepCount, fnShowPickupTrack, fnShowShipTrack, cartCount,
    };
  },
  template: /* html */ `
<fo-page bare>
<fo-my-layout :navigate="navigate" :cart-count="cartCount" active-page="myClaim">
  <!-- ===== ■. 영역 ====================================================== -->
  <MyDateFilter @search="onSearch" @reset="handleBtnAction('claims-statusReset')" />
  <!-- ===== ■. 유형 필터 =================================================== -->
  <div style="display:flex;gap:8px;margin-bottom:14px;flex-wrap:wrap;">
    <button v-for="f in ['전체','취소','반품','교환']" :key="f"
      @click="handleBtnAction('claims-setFilter', f)"
      style="padding:6px 16px;border-radius:20px;cursor:pointer;font-size:0.82rem;font-weight:700;transition:all 0.15s;"
      :style="claimFilter===f
      ? 'background:var(--blue);color:#fff;border:2px solid var(--blue);'
      : 'background:var(--bg-card);color:var(--text-secondary);border:2px solid var(--border);'">
      {{ f }}
      <span v-if="f!=='전체'" style="margin-left:4px;font-size:0.75rem;opacity:0.8;">
        ({{ claims.filter(c=>c.type===f).length }})
      </span>
      <span v-else style="margin-left:4px;font-size:0.75rem;opacity:0.8;">
        ({{ claims.length }})
      </span>
    </button>
  </div>
  <!-- ===== □. 유형 필터 =================================================== -->
  <!-- ===== ■. 처리 흐름 (취소/반품/교환) ======================================== -->
  <template v-for="claimType in (claimFilter==='전체' ? ['취소','반품','교환'] : [claimFilter])" :key="claimType">
    <div v-if="claims.filter(c=>c.type===claimType).length>0"
      style="background:#f4f5f7;border:1px solid var(--border);border-radius:var(--radius);padding:8px 12px;margin-bottom:8px;">
      <div style="display:flex;align-items:center;gap:6px;overflow-x:auto;flex-wrap:nowrap;">
        <!-- ===== ■.■.■.■. 유형 배지 ============================================= -->
        <span style="font-size:0.72rem;font-weight:800;padding:3px 10px;border-radius:10px;color:#fff;flex-shrink:0;"
          :style="'background:' + myStore.CLAIM_TYPE_COLOR[claimType]">
          {{ claimType }}
        </span>
        <span style="font-size:0.75rem;color:var(--border);flex-shrink:0;">
          ›
        </span>
        <!-- ===== ■.■.■.■. 흐름 단계 ============================================= -->
        <template v-for="(step, si) in myStore.CLAIM_FLOWS[claimType]" :key="step">
          <button @click="fnClaimStepCount(claimType, step)>0 ? handleSelectAction('claims-statusToggle', step) : null" style="display:flex;align-items:center;gap:4px;padding:4px 10px;border-radius:20px;border:1.5px solid transparent;white-space:nowrap;flex-shrink:0;transition:all 0.15s;" :style="claimStatusFilter.includes(step) ? 'background:var(--blue);border-color:var(--blue);cursor:pointer;' : fnClaimStepCount(claimType, step)>0 ? 'background:var(--bg-base);border-color:var(--border);cursor:pointer;' : 'background:var(--bg-card);border-color:#e5e7eb;cursor:default;opacity:0.72;'">
          <span style="font-size:0.7rem;font-weight:600;" :style="claimStatusFilter.includes(step) ? 'color:#fff;' : fnClaimStepCount(claimType, step)>0 ? 'color:var(--text-primary);' : 'color:#9ca3af;'">
          {{ step }}
        </span>
        <span style="font-size:0.65rem;font-weight:800;padding:0px 5px;border-radius:8px;" :style="claimStatusFilter.includes(step) ? 'background:rgba(255,255,255,0.25);color:#fff;' : fnClaimStepCount(claimType, step)>0 ? 'background:var(--blue-dim);color:var(--blue);' : 'color:#9ca3af;'">
        {{ fnClaimStepCount(claimType, step) || 0 }}
      </span>
    </button>
    <span v-if="si < myStore.CLAIM_FLOWS[claimType].length-1"
            style="font-size:0.75rem;color:var(--border);flex-shrink:0;">
      ›
    </span>
  </template>
  <!-- ===== ■.■.■.■. 필터해제 ============================================== -->
  <button v-if="claimStatusFilter.length"
          @click="handleBtnAction('claims-statusReset')"
          style="margin-left:4px;font-size:0.68rem;padding:2px 7px;border-radius:6px;border:1px solid var(--border);background:var(--bg-base);color:var(--text-secondary);cursor:pointer;flex-shrink:0;">
    ✕
  </button>
</div>
</div>
</template>
<!-- ===== □. 처리 흐름 (취소/반품/교환) ======================================== -->
<!-- ===== ■. 영역 ====================================================== -->
<PagerHeader :total="pager.pageTotalCount" :pager="pager" @size-change="onSizeChange" />
<!-- ===== ■. 조건부 영역 ================================================== -->
<div v-if="!cfDateFilteredClaims.length" style="text-align:center;padding:60px 0;color:var(--text-muted);">
  해당 내역이 없습니다.
</div>
<!-- ===== ■. 영역 ====================================================== -->
<div v-for="c in cfDateFilteredClaims" :key="c.claimId"
    style="background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius);padding:16px;margin-bottom:14px;">
  <!-- ===== ■.■. 카드 헤더 ================================================= -->
  <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:8px;margin:-16px -16px 12px;padding:12px 16px;border-bottom:1px solid var(--border);border-radius:var(--radius) var(--radius) 0 0;"
      :style="'background:linear-gradient(135deg,'+({'취소':'rgba(220,38,38,0.22)','반품':'rgba(255,187,0,0.22)','교환':'rgba(59,130,246,0.13)'}[c.type]||'rgba(156,95,163,0.13)')+' 0%,rgba(255,255,255,0.6) 60%,rgba(255,255,255,0) 100%);'">
    <div>
      <span style="font-weight:700;font-size:0.88rem;color:var(--text-primary);">
        {{ c.claimId }}
      </span>
      <button @click="handleSelectAction('claims-orderOpen', c.orderId)"
          style="margin-left:8px;font-size:0.78rem;color:var(--blue);border:none;background:none;cursor:pointer;padding:0;font-weight:600;text-decoration:underline;text-underline-offset:2px;">
        주문: {{ c.orderId }}
      </button>
      <button v-if="cfAuthUser" @click="handleSelectAction('claims-customerOpen', orders.find(o=>o.orderId===c.orderId))"
          style="margin-left:8px;font-size:0.78rem;font-weight:600;color:var(--text-secondary);border:none;background:none;cursor:pointer;padding:0;text-decoration:underline;text-underline-offset:2px;">
        {{ cfAuthUser.name }}
      </button>
      <div style="margin-top:4px;font-size:0.78rem;color:var(--text-muted);">
        신청일: {{ c.requestDate }}
        <span v-if="c.completeDate">
          · 완료일: {{ c.completeDate }}
        </span>
      </div>
    </div>
    <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;justify-content:flex-end;">
      <button v-if="c.status === myStore.CLAIM_FLOWS[c.type][0]" @click="handleSelectAction('claims-cancel', c.claimId)"
          style="padding:4px 12px;border:1.5px solid #ef4444;border-radius:6px;background:transparent;color:#ef4444;cursor:pointer;font-size:0.76rem;font-weight:700;white-space:nowrap;">
        신청취소
      </button>
      <span style="font-size:0.78rem;font-weight:800;padding:4px 12px;border-radius:20px;color:#fff;"
          :style="'background:' + myStore.CLAIM_TYPE_COLOR[c.type]">
        {{ c.type }}
      </span>
      <span style="font-size:0.68rem;font-weight:600;padding:2px 8px;border-radius:10px;color:#fff;opacity:0.85;"
          :style="'background:' + myStore.CLAIM_STATUS_COLOR(c.status)">
        {{ c.status }}
      </span>
    </div>
  </div>
  <!-- ===== □.□. 카드 헤더 ================================================= -->
  <!-- ===== ■.■. 진행 흐름 바 =============================================== -->
  <div style="background:#f6f6f6;border-radius:8px;padding:12px 14px;margin-bottom:12px;overflow-x:auto;">
    <div style="display:flex;align-items:center;min-width:320px;">
      <template v-for="(step, si) in myStore.CLAIM_FLOWS[c.type]" :key="step">
        <div style="display:flex;flex-direction:column;align-items:center;flex:1;">
          <div :style="{
              width: c.status===step ? '14px' : '10px',
              height: c.status===step ? '14px' : '10px',
              borderRadius:'50%',
              marginBottom:'4px',
              transition:'all .15s',
              boxShadow: c.status===step ? '0 0 0 2px '+myStore.CLAIM_TYPE_COLOR[c.type]+'33' : 'none',
              background: myStore.CLAIM_FLOWS[c.type].indexOf(c.status) >= si ? myStore.CLAIM_TYPE_COLOR[c.type] : '#bbb',
              }">
          </div>
          <div style="font-size:0.65rem;text-align:center;white-space:nowrap;font-weight:600;"
              :style="c.status===step ? 'color:'+myStore.CLAIM_TYPE_COLOR[c.type]+';font-weight:800;'
              : myStore.CLAIM_FLOWS[c.type].indexOf(c.status) > si ? 'color:var(--text-secondary);'
              : 'color:var(--text-muted);'">
            {{ step }}
          </div>
          <button v-if="fnShowPickupTrack(c, step)" @click.stop="handleSelectAction('claims-track', { courier: c.courier, trackingNo: c.trackingNo })" style="margin-top:4px;padding:2px 6px;border-radius:4px;border:1px solid #fed7aa;background:#fff7ed;color:#c2410c;cursor:pointer;font-size:0.6rem;font-weight:700;white-space:nowrap;">
          {{ (c.courier||'').replace('대한통운','').replace('택배','').replace('로지스','') }}수거
        </button>
        <button v-if="fnShowShipTrack(c, step)" @click.stop="handleSelectAction('claims-track', { courier: c.exchangeCourier, trackingNo: c.exchangeTrackingNo })" style="margin-top:3px;padding:2px 6px;border-radius:4px;border:1px solid #93c5fd;background:#dbeafe;color:#1d4ed8;cursor:pointer;font-size:0.6rem;font-weight:700;white-space:nowrap;">
        {{ (c.exchangeCourier||'').replace('대한통운','').replace('택배','').replace('로지스','') }}발송
      </button>
    </div>
    <div v-if="si < myStore.CLAIM_FLOWS[c.type].length-1" style="height:2px;flex:1;margin-bottom:16px;"
            :style="myStore.CLAIM_FLOWS[c.type].indexOf(c.status) > si ? 'background:'+myStore.CLAIM_TYPE_COLOR[c.type] : 'background:#bbb;'">
    </div>
  </template>
</div>
</div>
<!-- ===== □.□. 진행 흐름 바 =============================================== -->
<!-- ===== ■.■. 상품 목록 ================================================= -->
<div v-for="(item, ii) in c.items" :key="ii"
      style="display:flex;align-items:center;gap:10px;padding:6px 0;border-bottom:1px dashed var(--border);">
  <span style="font-size:1.4rem;">
    {{ item.emoji }}
  </span>
  <div style="flex:1;">
    <div style="display:flex;align-items:center;gap:5px;flex-wrap:wrap;">
      <span style="font-size:0.88rem;font-weight:600;color:var(--text-primary);">
        {{ item.prodNm }}
      </span>
      <button v-if="findProd(item.prodNm)" @click="handleSelectAction('claims-prodOpen', item.prodNm)"
            style="font-size:0.65rem;padding:0 5px;border:1px solid var(--border);border-radius:4px;background:var(--bg-base);color:var(--text-muted);cursor:pointer;font-weight:600;line-height:1.7;white-space:nowrap;">
        #{{ findProd(item.prodNm).prodId }}
      </button>
    </div>
    <div style="font-size:0.78rem;color:var(--text-muted);">
      {{ item.color }} / {{ item.size }} / {{ item.qty }}개
    </div>
  </div>
  <div style="font-size:0.88rem;font-weight:700;color:var(--blue);">
    {{ item.price.toLocaleString() }}원
  </div>
</div>
<!-- ===== □.□. 상품 목록 ================================================= -->
<!-- ===== ■.■. 사유 + 교환 정보 ============================================ -->
<div style="margin-top:10px;display:flex;flex-direction:column;gap:6px;font-size:0.82rem;">
  <div style="display:flex;gap:8px;align-items:flex-start;">
    <span style="color:var(--text-muted);flex-shrink:0;min-width:44px;">
      사유
    </span>
    <span style="color:var(--text-primary);font-weight:600;">
      {{ c.reason }}
    </span>
    <span v-if="c.reasonDetail" style="color:var(--text-secondary);">
      · {{ c.reasonDetail }}
    </span>
  </div>
  <div v-if="c.exchangeSize || c.exchangeColor" style="display:flex;gap:8px;">
    <span style="color:var(--text-muted);flex-shrink:0;min-width:44px;">
      교환
    </span>
    <span style="color:var(--text-primary);">
      <span v-if="c.exchangeSize">
        사이즈: {{ c.exchangeSize }}
      </span>
      <span v-if="c.exchangeColor">
        색상: {{ c.exchangeColor }}
      </span>
    </span>
  </div>
  <div v-if="c.courier" style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
    <span style="color:var(--text-muted);flex-shrink:0;min-width:44px;">
      수거
    </span>
    <span style="color:var(--text-primary);">
      {{ c.courier }}
    </span>
    <button v-if="c.trackingNo" @click="handleSelectAction('claims-track', { courier: c.courier, trackingNo: c.trackingNo })"
          style="padding:2px 8px;border:1.5px solid var(--blue);border-radius:14px;background:transparent;color:var(--blue);cursor:pointer;font-size:0.75rem;font-weight:700;">
      {{ c.trackingNo }}
    </button>
    <span v-if="c.pickupDate" style="color:var(--text-muted);font-size:0.78rem;">
      수거예정: {{ c.pickupDate }}
    </span>
  </div>
  <div v-if="c.exchangeCourier" style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
    <span style="color:var(--text-muted);flex-shrink:0;min-width:44px;">
      발송
    </span>
    <span style="color:var(--text-primary);">
      {{ c.exchangeCourier }}
    </span>
    <button v-if="c.exchangeTrackingNo" @click="handleSelectAction('claims-track', { courier: c.exchangeCourier, trackingNo: c.exchangeTrackingNo })"
          style="padding:2px 8px;border:1.5px solid #22c55e;border-radius:14px;background:transparent;color:#22c55e;cursor:pointer;font-size:0.75rem;font-weight:700;">
      {{ c.exchangeTrackingNo }}
    </button>
  </div>
  <!-- ===== ■.■.■. 조건부 영역 ============================================== -->
  <div v-if="c.refundAmount" style="display:flex;justify-content:space-between;align-items:center;margin-top:6px;padding-top:8px;border-top:1px solid var(--border);">
    <span style="color:var(--text-muted);">
      {{ c.type==='반품' ? '환불 예정금액' : '취소 환불금액' }}
    </span>
    <span style="font-size:0.95rem;font-weight:800;color:var(--blue);">
      {{ c.refundAmount.toLocaleString() }}원
    </span>
  </div>
  <div v-if="c.refundDetails?.length" style="margin-top:8px;padding:8px 10px;background:var(--bg-base);border-radius:7px;">
  <div style="font-size:0.68rem;font-weight:700;color:var(--text-muted);letter-spacing:0.04em;margin-bottom:5px;">
    💸 환불 내역
  </div>
  <div v-for="(rd, rdi) in c.refundDetails" :key="rdi"
          style="display:flex;align-items:center;gap:6px;font-size:0.72rem;padding:2px 0;flex-wrap:wrap;">
    <span style="padding:1px 7px;border-radius:4px;font-weight:700;white-space:nowrap;flex-shrink:0;"
            :style="rd.type==='계좌환불' ? 'background:#dcfce7;color:#16a34a;'
            : rd.type==='카드취소' ? 'background:#dbeafe;color:#1d4ed8;'
            : rd.type==='캐쉬환급' ? 'background:#fef3c7;color:#d97706;'
            : rd.type==='환불처리중' ? 'background:#ffedd5;color:#ea580c;'
            : 'background:#f3f4f6;color:#6b7280;'">
      {{ rd.type }}
    </span>
    <span style="font-weight:700;color:var(--text-primary);white-space:nowrap;">
      {{ rd.amount.toLocaleString() }}원
    </span>
    <span v-if="rd.account" style="color:var(--text-secondary);white-space:nowrap;">
      {{ rd.account }}
    </span>
    <span v-if="rd.name ? rd.type==='계좌환불' : false" style="color:var(--text-secondary);white-space:nowrap;">
    · {{ rd.name }}
  </span>
  <span style="color:var(--text-muted);white-space:nowrap;flex-shrink:0;">
    {{ rd.datetime }}
  </span>
</div>
</div>
</div>
</div>
<Pagination :total="pager.pageTotalCount" :pager="pager" @set-page="onPageChange" />
<!-- ===== □.□. 사유 + 교환 정보 ============================================ -->
<!-- ===== □. 영역 ====================================================== -->
<!-- ===== ■. 영역 ====================================================== -->
<Teleport to="body">
  <OrderDetailModal :show="myStore.orderDetailModal.show" :order="myStore.orderDetailModal.order" modal-name="order-detail" :on-callback="fnCallbackModal" />
  <ProductModal :show="myStore.productModal.show" :product="myStore.productModal.prod" modal-name="product" :on-callback="fnCallbackModal" />
  <CustomerModal :show="myStore.customerModal.show" :user="myStore.customerModal.user" :order="myStore.customerModal.order" modal-name="customer" :on-callback="fnCallbackModal" />
</teleport>
</fo-my-layout>
</fo-page>
<!-- ===== □. 영역 ====================================================== -->
`,
  components: {
    FoMyLayout:         window.foMyLayout,
    PagerHeader:      window.PagerHeader,
    Pagination:       window.Pagination,
    OrderDetailModal: window.OrderDetailModal,
    ProductModal:     window.ProductModal,
    CustomerModal:    window.CustomerModal,
  }
};
