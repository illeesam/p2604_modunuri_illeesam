/* ShopJoy Admin - 회원관리
 * 원본: shopjoy_v260406/pages/bo/ec/mb/MbMemberMng.js — 실제 프로덕션 화면을 그대로
 * 가져와 shopjoy_v260828_mfe 규칙(ES 모듈 export default + bo- 접두어 id/name)만
 * 적용했다(2026-08-29). setup()/template/props 로직은 원본과 100% 동일 — 원본
 * 프로젝트(shopjoy_v260406)는 이 작업으로 전혀 수정되지 않는다. */
export default {
  name: 'mb-member-mbMemberMng',
  props: {
    navigate:          { type: Function, required: true }, // 페이지 이동
    openNewWindow:     { type: Function, default: () => {} }, // 실제 새 브라우저 창으로 열기 (Ctrl+클릭)
    initSearchValue:   { type: String,   default: null },  // ZdSimul BO상세 자동 조회값
  },
  setup(props) {

    /* ##### [01] 초기 변수 정의 #################################################### */

    const { ref, reactive, computed, watch, onMounted } = Vue;
    const showToast    = window.boApp.showToast;   // 토스트 알림
    const showConfirm  = window.boApp.showConfirm; // 확인 모달
    const members = reactive([]);                  // 회원 목록 (메인 그리드 데이터)
    const uiState = reactive({                     // UI 상태
      loading: false, error: null, sortKey: '', sortDir: 'asc',
    });
    const codes = reactive({ MEMBER_STATUS: [], MEMBER_GRADE: [] }); // 공통코드
    const siteOptions = reactive([]);  // 사이트 선택 옵션 (BO 는 강제 필터 없음 — 선택적 검색용)
    const SORT_MAP = { nm: { asc: 'memberNm asc', desc: 'memberNm desc' }, reg: { asc: 'joinDate asc', desc: 'joinDate desc' } };

    /* ===== 검색조건 ===== */

    /* ##### [02] 액션 모음 (dispatch) ############################################## */

    /* handleBtnAction — 버튼 액션 dispatch (cmd: '{영역명}-기능명'). 5줄 이하 짧은 로직은 인라인 */
    const handleBtnAction = (cmd, param = {}) => {
      console.log(' ■■ MbMemberMng.js : handleBtnAction -> ', cmd, param);
      // 검색조건으로 목록 조회
      if (cmd === 'searchParam-list') {
        baseGridPager.pageNo = 1;
        return handleSearchList('SEARCH');
      // 검색조건 초기화 + 재조회
      } else if (cmd === 'searchParam-reset') {
        Object.assign(searchParam, searchParamInit);
        uiState.sortKey = ''; uiState.sortDir = 'asc';
        baseGridPager.pageNo = 1;
        resetDetailToNew();
        return handleSearchList('SEARCH');
      // 회원 신규 등록 (인라인 패널)
      } else if (cmd === 'members-add') {
        return openNew();
      // 상세 인라인 패널 저장
      } else if (cmd === 'detailPanel-save') {
        return handleSave();
      // 상세 인라인 패널 삭제
      } else if (cmd === 'detailPanel-delete') {
        return handleDelete();
      // 상세 인라인 패널 닫기
      } else if (cmd === 'detailPanel-close') {
        return closeDetail();
      // 그리드 정렬 헤더 클릭
      } else if (cmd === 'members-sort') {
        return onSort(param);
      // 페이지 번호 클릭
      } else if (cmd === 'members-pager-setPage') {
        return setPage(param);
      } else {
        console.warn('[handleBtnAction] unknown cmd:', cmd);
      }
    };

    /* handleSelectAction — 그리드 행/노드/모달 선택 액션 dispatch (cmd: '{영역명}-기능명'). 5줄 이하 짧은 로직은 인라인 */
    const handleSelectAction = (cmd, param = {}, e = null) => {
      console.log(' ■■ MbMemberMng.js : handleSelectAction -> ', cmd, param);
      // 페이지 크기 변경
      if (cmd === 'members-pager-sizeChange') {
        return onSizeChange();
      // 행 수정 버튼 → 인라인 상세 편집 모드 (Ctrl+클릭/휠클릭 시 새창 편집모드)
      } else if (cmd === 'members-rowEdit') {
        if (e && (e.ctrlKey || e.metaKey || e.button === 1)) { return props.openNewWindow('mbMemberDtl', param.memberId, 'edit'); }
        return openDetail(param);
      // 행 이력 버튼 → 목록 하단 이력정보 표시
      } else if (cmd === 'members-rowHist') {
        return openHist(param.memberId);
      } else {
        console.warn('[handleSelectAction] unknown cmd:', cmd);
      }
    };

    /* handleGridCellAction — 그리드 셀 클릭 라우터. colKey 기준 분기 */
    const handleGridCellAction = (cmd, colKey, row, e = {}) => {
      console.log(' ■■ MbMemberMng.js : handleGridCellAction -> ', cmd, colKey, row);
      if (cmd === 'members-cellClick') {
        // 보기모드 트리거 컬럼: 행번호(__no__) 또는 link 셀 → 보기모드(저장/취소 숨김)
        const VIEW_COLS = ['__no__'];
        if (VIEW_COLS.includes(colKey) || (e.col && e.col.link)) {
          if (e.ctrlKey || e.metaKey || e.button === 1) { return props.openNewWindow('mbMemberDtl', row.memberId); }
          return openView(row);
        }
      } else {
        console.warn('[handleGridCellAction] unknown cmd:', cmd);
      }
    };

    const searchParam = reactive({ searchType: '', searchValue: '', gradeCd: '', memberStatusCd: '' });
    /* searchParamInit — [초기화] 기준값. initPage 끝에서 그때의 searchParam 을 복사해 둔다.
       리터럴 기본값이 아니라 '화면을 열었을 때의 상태'가 기준이라, initPage 가 채운
       기본 기간·사이트 값도 함께 복원된다. (재대입 금지 — Object.assign 으로만 갱신) */
    const searchParamInit = {};

    /* ===== 페이지네이션 ===== */
    const baseGridPager = reactive({ pageType: 'PAGE', pageNo: 1, pageSize: 5, pageTotalCount: 0, pageTotalPage: 1, pageSizes: [5, 10, 20, 30, 50, 100, 200, 500], pageCond: {} });

    /* ===== 상세 인라인 패널 ===== */
    /* _emptyForm — 빈(신규) 폼 기본값.
       2026-08-29 버그수정: gradeCd/memberStatusCd 를 '일반'/'활성' 처럼 실제 코드값이 아닌
       한글 placeholder 로 하드코딩해뒀던 탓에, select 옵션(codes.MEMBER_GRADE/MEMBER_STATUS
       의 실제 codeValue, 예: BASIC/GOLD/VIP, ACTIVE/DORMANT 등) 중 어느 것과도 일치하지
       않아 신규 등록 화면에서 두 select 가 전부 빈 값(placeholder)으로 보였다. 신규 등록 시
       입력을 최소화하려는 목적이므로, 코드가 이미 로드돼 있으면 그 그룹의 "첫 번째 옵션"을
       기본값으로 채운다(신규 진입 시점엔 initPage 의 fnLoadCodes 가 이미 끝나있어 codes 배열이
       채워진 상태 — 못 채워진 경우에만 빈 문자열로 폴백). */
    const _emptyForm = () => ({
      memberId: null, loginId: '', memberEmail: '', memberNm: '', memberPhone: '',
      gradeCd: codes.MEMBER_GRADE[0]?.codeValue || '',
      memberStatusCd: codes.MEMBER_STATUS[0]?.codeValue || '',
      joinDate: '', memberMemo: '',
    });
    const detailPanel = reactive({                 // 인라인 Dtl 패널 상태
      show: true,                                  // 상세영역 항상 표시 (진입 시 빈 신규 폼)
      isNew: false, dtlId: null, reloadTrigger: 0,
      active: false,                               // 행 선택/신규 시 true → 저장/취소 노출. 초기/취소 시 false → 버튼 숨김
      form: _emptyForm()
    });
    const errors = reactive({});   // 저장 검증 실패 시 항목 아래 빨간 라벨(field-error)로 표시

    /* ===== 이력 인라인 패널 =====
     *   상세와 달리 항상 표시하지 않는다 — 관리컬럼 [이력] 클릭 시에만 memberId 가 채워져 렌더된다.
     *   [이력] 이 아닌 모든 동작(행 클릭·[수정]·[신규]·[취소]·조회·페이징)에서는 닫는다. */
    const histPanel = reactive({ memberId: null });

    /* openHist — 관리컬럼 [이력] 클릭 → 목록 하단에 해당 회원 이력 표시 */
    const openHist = (id) => { histPanel.memberId = id; };

    /* closeHist — 이력 패널 닫기 */
    const closeHist = () => { histPanel.memberId = null; };

    /* ##### [04] 내장 사용 함수 (이벤트 핸들러 on* / handle*) ############################ */

    /* getSortParam — 정렬 파라미터 */
    const getSortParam = () => {
      const { sortKey, sortDir } = uiState;
      if (!sortKey || !SORT_MAP[sortKey]) { return {}; }
      return { sort: SORT_MAP[sortKey][sortDir] };
    };

    /* onSort — 정렬 */
    const onSort = (key) => {
      if (uiState.sortKey === key) {
        if (uiState.sortDir === 'asc') { uiState.sortDir = 'desc'; }
        else { uiState.sortKey = ''; uiState.sortDir = 'asc'; }
      } else { uiState.sortKey = key; uiState.sortDir = 'asc'; }
      baseGridPager.pageNo = 1;
      handleSearchList();
    };



    /* handleSearchList — 목록 조회 */
    const handleSearchList = async (searchType = 'DEFAULT') => {
      closeHist();   // 목록이 바뀌면 이력 대상 행이 화면에서 사라지므로 함께 닫는다
      uiState.loading = true;
      try {
        const params = {
          pageNo: baseGridPager.pageNo, pageSize: baseGridPager.pageSize,
          ...getSortParam(),
          ...coUtil.cofOmitEmpty(searchParam)
        };
        // searchValue 가 있는데 searchType 가 비어있으면 전체 필드로 검색
        if (params.searchValue && !params.searchType) {
          params.searchType = 'memberId,memberNm,loginId,memberEmail';
        }
        const res = await boApiSvc.mbMember.getPage(params, '회원관리', '목록조회');
        const data = res.data?.data;
        members.splice(0, members.length, ...(data?.pageList || []));
        baseGridPager.pageTotalCount = data?.pageTotalCount || 0;
        baseGridPager.pageTotalPage = data?.pageTotalPage || coUtil.cofTotalPage(baseGridPager);
        coUtil.cofBuildPagerNums(baseGridPager);
        Object.assign(baseGridPager.pageCond, data?.pageCond || baseGridPager.pageCond);
        uiState.error = null;
      } catch (err) {
        console.error('[catch-info]', err);
        uiState.error = err.message;
      } finally {
        uiState.loading = false;
      }
    };

    /* fnApplyForm — 폼 데이터 적용 */
    const fnApplyForm = (d) => {
      Object.assign(detailPanel.form, {
        memberId: d.memberId, loginId: d.loginId || '', memberEmail: d.memberEmail || '', memberNm: d.memberNm || '',
        memberPhone: d.memberPhone || '', gradeCd: d.gradeCd || '', memberStatusCd: d.memberStatusCd || '',
        joinDate: fnFmtDate(d.joinDate), memberMemo: d.memberMemo || ''
      });
    };

    /* _loadMember — 공통 상세 데이터 로드 (row 먼저 표시 후 API 재조회) */
    const _loadMember = async (row, active) => {
      closeHist();
      detailPanel.dtlId = row.memberId;
      detailPanel.isNew = false;
      detailPanel.show = true;
      detailPanel.active = active;
      detailPanel.reloadTrigger++;
      fnApplyForm(row);
      try {
        const res = await boApiSvc.mbMember.getById(row.memberId, '회원관리', '상세조회');
        const d = res.data?.data || res.data;
        if (d) { fnApplyForm(d); }
      } catch (err) {
        console.error('[_loadMember]', err);
      }
    };

    /* openView — 번호/이름 클릭 → 보기 모드 (저장/취소 숨김) */
    const openView = (row) => _loadMember(row, false);

    /* openDetail — 수정 버튼 클릭 → 편집 모드 (저장/취소 노출) */
    const openDetail = (row) => _loadMember(row, true);

    /* openNew — 신규 등록 (빈 폼 + 활성 → 저장/취소 노출) */
    const openNew = () => {
      closeHist();
      Object.keys(errors).forEach(k => delete errors[k]);
      Object.assign(detailPanel.form, _emptyForm(), { joinDate: new Date().toISOString().split('T')[0] });
      detailPanel.dtlId = '__new__';
      detailPanel.isNew = true;
      detailPanel.show = true;
      detailPanel.active = true;     // 신규 입력 가능 → 저장/취소 노출
      detailPanel.reloadTrigger++;
    };

    /* resetDetailToNew — 상세영역을 빈 신규 폼(비활성)으로 초기화 (영역은 항상 표시 유지)
     *   active=false → 저장/취소 등 버튼 숨김 (행 미선택 안내 상태) */
    const resetDetailToNew = () => {
      closeHist();
      Object.keys(errors).forEach(k => delete errors[k]);
      Object.assign(detailPanel.form, _emptyForm());
      detailPanel.show = true;
      detailPanel.dtlId = null;
      detailPanel.isNew = false;
      detailPanel.active = false;    // 버튼 숨김
    };

    /* closeDetail — 상세 닫기 = 빈 신규 폼(비활성)으로 초기화 (영역 유지) */
    const closeDetail = () => { resetDetailToNew(); };

    /* switchToEdit — 보기모드 → 편집모드 전환 (Dtl 내 [수정] 버튼 콜백) */
    const switchToEdit = () => { detailPanel.active = true; };

    /* handleSave — 저장 */
    const handleSave = async () => {
      Object.keys(errors).forEach(k => delete errors[k]);
      if (!detailPanel.form.loginId) { errors.loginId = '로그인ID를 입력해주세요.'; }
      else if (!coUtil.cofIsValidEmail(detailPanel.form.loginId)) { errors.loginId = '로그인ID는 이메일 형식이어야 합니다.'; }
      if (!detailPanel.form.memberNm) { errors.memberNm = '이름을 입력해주세요.'; }
      if (!coUtil.cofIsValidEmail(detailPanel.form.memberEmail)) { errors.memberEmail = '올바른 이메일 형식이 아닙니다.'; }
      if (!coUtil.cofIsValidMobile(detailPanel.form.memberPhone)) { errors.memberPhone = '올바른 휴대전화 형식이 아닙니다. (예: 010-1234-5678)'; }
      if (Object.keys(errors).length) { showToast('입력 내용을 확인해주세요.', 'error'); return; }
      const isNewMember = detailPanel.isNew;
      const ok = await showConfirm('저장', '저장하시겠습니까?');
      if (!ok) { return; }
      /* ⚠ 목록(members) 을 API 호출 전에 미리 바꾸지 않는다.
         저장이 실패해도 되돌리지 않아 화면에만 저장된 것처럼 남는 문제가 있었다.
         성공 시 아래에서 handleSearchList('RELOAD') 로 서버 기준 재조회하므로 낙관적 갱신이 불필요하다. */
      if (isNewMember) {
        detailPanel.form.memberId = 'MB' + String(Date.now()).slice(-6);
        detailPanel.form.orderCount = 0;
        detailPanel.form.totalPurchaseAmt = 0;
      }
      try {
        /* DB join_date 컬럼은 TIMESTAMP — LocalDateTime 매핑이라 'YYYY-MM-DDTHH:mm:ss' 형식 필요 */
        const fnToDateTime = (s) => {
          if (!s) { return s; }
          return /^\d{4}-\d{2}-\d{2}$/.test(s) ? `${s}T00:00:00` : s;
        };
        const payload = {
          ...detailPanel.form,
          joinDate: fnToDateTime(detailPanel.form.joinDate),
        };
        if (isNewMember && !payload.loginPwdHash) {
          /* 신규 등록 시 임시 비밀번호 = 'init1234' 의 sha256 (회원에게 별도 안내 후 변경 유도) */
          payload.loginPwdHash = await coUtil.cofSha256('init1234');
        }
        const res = await (isNewMember
          ? boApiSvc.mbMember.create(payload, '회원관리', '등록')
          : boApiSvc.mbMember.update(detailPanel.form.memberId, payload, '회원관리', '저장'));
        if (showToast) { showToast('저장되었습니다.', 'success'); }
        /* 저장 완료: 목록 재조회 + 상세영역을 빈 신규 폼(비활성)으로 초기화 (영역 유지) */
        handleSearchList('RELOAD');
        resetDetailToNew();
      } catch (err) {
        console.error('[catch-info]', err);
        const errMsg = (err.response?.data?.message) || err.message || '오류가 발생했습니다.';
        if (showToast) { showToast(errMsg, 'error', 0); }
      }
    };

    /* handleDelete — 삭제 */
    const handleDelete = async () => {
      if (!cfSelectedRow.value) { return; }
      const ok = await showConfirm('삭제', `[${cfSelectedRow.value.memberNm}] 회원을 삭제하시겠습니까?`);
      if (!ok) { return; }
      const memberId = cfSelectedRow.value.memberId;
      const si = members.findIndex(m => m.memberId === memberId);
      if (si !== -1) { members.splice(si, 1); }
      closeDetail();
      try {
        const res = await boApiSvc.mbMember.remove(memberId, '회원관리', '삭제');
        if (showToast) { showToast('삭제되었습니다.', 'success'); }
      } catch (err) {
        console.error('[catch-info]', err);
        const errMsg = (err.response?.data?.message) || err.message || '오류가 발생했습니다.';
        if (showToast) { showToast(errMsg, 'error', 0); }
      }
    };

    /* setPage — 페이지 번호 변경 */
    const setPage = n => { if (n >= 1 && n <= baseGridPager.pageTotalPage) { baseGridPager.pageNo = n; handleSearchList('PAGE_CLICK'); } };

    /* onSizeChange — 페이지 크기 변경 */
    const onSizeChange = () => { baseGridPager.pageNo = 1; handleSearchList('DEFAULT'); };




    /* fnLoadCodes — 공통코드 로드 */
    const fnLoadCodes = async () => {
      const codeStore = window.sfGetBoCodeStore();
      await codeStore.saLoadCodes(['MEMBER_GRADE', 'MEMBER_STATUS_CD'], { compNm: 'mb-member-mbMemberMng' });
      codes.MEMBER_GRADE = codeStore.sgGetGrpCodes('MEMBER_GRADE');
      codes.MEMBER_STATUS = codeStore.sgGetGrpCodes('MEMBER_STATUS_CD');
            siteOptions.splice(0, siteOptions.length, ...(await window.boUtil.bofLoadSiteOptions()));
    };

    // ★ onMounted — 진입 시 코드 로드 + 목록 초기 조회
    /* initPage — 화면 로드 시퀀스. 마운트 시 실행한다. */
    const initPage = async () => {
      await fnLoadCodes();
      if (props.initSearchValue) {
        searchParam.searchValue = props.initSearchValue;
      }
      /* 공유된 링크(bo-page shareQuery)로 들어온 경우 URL 쿼리의 검색조건을 복원 (2026-08-23) */
      const _qs = new URLSearchParams(window.location.search);
      const _reserved = ['page','id','orderId','claimId','embed','dtlMode'];
      Object.keys(searchParam).forEach((k) => { if (!_reserved.includes(k) && _qs.has(k)) searchParam[k] = _qs.get(k); });
      handleSearchList('DEFAULT');
      Object.assign(searchParamInit, searchParam);   // [초기화] 기준값 스냅샷
    };
    onMounted(initPage);

    /* ##### [05] 사용자 함수 (헬퍼 / 카운트 / 렌더 / 컬럼정의) #################### */

    const cfSelectedRow = computed(() => members.find(m => m.memberId === detailPanel.dtlId) || null);

    /* fnFmtDate — 날짜 포맷 */
    const fnFmtDate = v => v ? String(v).slice(0, 10) : '';

    /* fnGradeBadge — 등급 배지 */
    const _MEMBER_GRADE_FB = { 'VIP': 'badge-purple', '우수': 'badge-blue', '일반': 'badge-gray' };
    const fnGradeBadge = g => coUtil.cofCodeBadge('MEMBER_GRADE', g, _MEMBER_GRADE_FB[g] || 'badge-gray');

    /* fnStatusBadge — 상태 배지 */
    const _MEMBER_STATUS_FB = { '활성': 'badge-green', '정지': 'badge-red' };
    const fnStatusBadge = s => coUtil.cofCodeBadge('MEMBER_STATUS_CD', s, _MEMBER_STATUS_FB[s] || 'badge-gray');

    /* fnGridRowClass — 그리드 행 클래스 */
    const fnGridRowClass = (row) => (detailPanel.dtlId === row.memberId ? 'active' : '');

    // 기본 검색
    const columns = {};
    columns.baseSearch = [
      { key: 'searchType', type: 'multiCheck', label: '검색대상',
        options: [
          { value: 'memberId', label: 'ID' },
          { value: 'memberNm', label: '이름' },
          { value: 'loginId',     label: '로그인ID' },
          { value: 'memberEmail', label: '이메일' },
        ],
        placeholder: '검색대상 전체', allLabel: '전체 선택', minWidth: '160px' },
      { key: 'searchValue', type: 'text', label: '검색어', placeholder: '검색어 입력' },
      { key: 'gradeCd', type: 'select', label: '등급', options: () => codes.MEMBER_GRADE, nullLabel: '전체' },
      { key: 'memberStatusCd', type: 'select', label: '상태', options: () => codes.MEMBER_STATUS, nullLabel: '전체' },
          { key: 'siteId', type: 'select', label: '사이트', options: () => siteOptions, nullLabel: '전체' },
    ];

    // 기본 그리드
    columns.baseGrid = [
      { key: 'memberNm',         label: '이름',     sortKey: 'nm',
        fmt: (v, row) => `${row.memberNm || '-'}  #${row.memberId || row.sessionKey || '-'}` },
      { key: 'loginId',          label: '로그인ID' },
      { key: 'memberEmail',      label: '이메일' },
      { key: 'memberPhone',      label: '연락처' },
      { key: 'gradeCd',          label: '등급',     align: 'center', badge: (row) => fnGradeBadge(row.gradeCd) },
      { key: 'memberStatusCd',   label: '상태',     align: 'center', badge: (row) => fnStatusBadge(row.memberStatusCd) },
      { key: 'joinDate',         label: '가입일',   sortKey: 'reg', fmt: (v) => fnFmtDate(v) },
      { key: 'orderCount',       label: '주문수',   style: 'width:80px;text-align:right', align: 'right', fmt: (v) => (v || 0) + '건' },
      { key: 'totalPurchaseAmt', label: '총구매액', style: 'width:100px;text-align:right', align: 'right', fmt: (v) => coUtil.cofWon(v) },
          { key: 'siteNm', label: '사이트' },
    ];

    /* excelModal — 엑셀 다운로드 (공용 모달) */
    const excelModal = reactive({ show: false });
    const buildExcelParams = () => {
      const p = { ...getSortParam(), ...coUtil.cofOmitEmpty(searchParam) };
      if (p.searchValue && !p.searchType) { p.searchType = 'memberId,memberNm,loginId,memberEmail'; }
      return p;
    };

    /* ##### [06] return (템플릿 노출) ############################################## */

    return {
      columns,
      members, uiState, searchParam, baseGridPager, detailPanel, histPanel, errors,       // 상태 / 데이터
      excelModal, buildExcelParams, // 엑셀 다운로드 모달
      handleBtnAction, handleSelectAction, handleGridCellAction,                                             // dispatch (모든 이벤트 / 액션 라우팅)
      fnGridRowClass,                                                  // 헬퍼
      handleSave, handleDelete, closeDetail, switchToEdit, handleSearchList,            // Dtl 콜백 (자식 컴포넌트로 전달)
      closeHist,                                                       // 이력 패널 닫기 (Hist 임베드 전달용)
    };
  },
  template: /* html */`
<bo-page title="회원관리" :share-query="searchParam">
  <!-- ===== ■. 검색 ======================================================== -->
  <bo-container>
    <!-- ===== ■.■. 검색 영역 ================================================= -->
    <bo-search-area :loading="uiState.loading" @search="handleBtnAction('searchParam-list')" @reset="handleBtnAction('searchParam-reset')" :columns="columns.baseSearch" :param="searchParam" />
  </bo-container>
  <!-- ===== □. 검색 ======================================================== -->
  <!-- ===== ■. 목록 영역 =================================================== -->
  <bo-container title="회원목록" :count-text="'총 ' + baseGridPager.pageTotalCount + '건'">
    <template #toolbar-actions>
      <button class="btn btn_excel" @click="excelModal.show = true">엑셀</button>
      <button class="btn btn_new" @click="handleBtnAction('members-add')">
        + 신규
      </button>
    </template>
    <bo-grid bare :columns="columns.baseGrid" :rows="members" row-key="memberId" :selected-key="detailPanel.dtlId"
      :sort-state="uiState"
      :row-class="fnGridRowClass" empty-text="데이터가 없습니다."
      @sort="key => handleBtnAction('members-sort', key)"
      grid-id="members-cellClick" @cell-click="e => handleGridCellAction(e.cmd, e.colKey, e.row, e)" row-actions
            table-max-height="540px">
      <template #row-actions="{ row }">
        <button class="btn btn_row_edit" @click.stop="handleSelectAction('members-rowEdit', row, $event)" @auxclick.stop="handleSelectAction('members-rowEdit', row, $event)">
          수정
        </button>
        <button class="btn btn_row_hist" @click.stop="handleSelectAction('members-rowHist', row)">
          이력
        </button>
      </template>
    </bo-grid>
    <bo-pager :pager="baseGridPager" :on-set-page="n => handleBtnAction('members-pager-setPage', n)" :on-size-change="() => handleSelectAction('members-pager-sizeChange')" />
    <bo-excel-down-modal :show="excelModal.show" domain="mbMember" area-nm="회원"
      :columns="columns.baseGrid" ui-nm="회원관리" :params="buildExcelParams()"
      @close="excelModal.show = false" />
  </bo-container>
  <!-- ===== □. 목록 영역 =================================================== -->
  <!-- ===== ■. 상세 패널 (인라인 임베드, 항상 표시) ================================== -->
  <mb-member-dtl :detail-modal="detailPanel" :active="detailPanel.active" :errors="errors"
    :handle-save="handleSave" :handle-delete="handleDelete" :close-detail="closeDetail"
    :switch-to-edit="switchToEdit"
    :reload-trigger="detailPanel.reloadTrigger"
    />
  <!-- ===== □. 상세 패널 (인라인 임베드) ========================================= -->
  <!-- ===== ■. 하단 이력: 관리컬럼 [이력] 클릭 시에만 노출 ========================= -->
  <bo-container v-if="histPanel.memberId">
    <mb-member-hist :key="histPanel.memberId" :member-id="histPanel.memberId" :on-close="closeHist" />
  </bo-container>
  <!-- ===== □. 하단 이력 ==================================================== -->
</bo-page>
`,
};
