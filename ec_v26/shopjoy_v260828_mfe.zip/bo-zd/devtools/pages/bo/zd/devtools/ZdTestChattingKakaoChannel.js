﻿/**
 * 개발도구 — 카카오 채널(플러스친구) 메시지 테스트
 */
export default {
  name: 'zd-devtools-zdTestChattingKakaoChannel',
  props: {
    navigate:  { type: Function, required: true }, // 페이지 이동
    showToast: { type: Function, default: () => {} }, // 토스트 알림
  },
  setup(props) {

    /* ##### [01] 초기 변수 정의 #################################################### */

    const { reactive, onMounted } = Vue;
    const showToast = props.showToast || window.boApp?.showToast || (() => {});

    const cfg = reactive({
      channelId:     '',   // 카카오 채널 공개 ID (@ 포함)
      bizMsgApiKey:  '',   // 비즈메시지 API Key
      senderKey:     '',   // 알림톡 발신 프로필 키
      from:          '',   // 발신 전화번호
    });

    const form = reactive({
      msgType:     'alimtalk',  // alimtalk | friendtalk | channel_add
      toPhone:     '01038050206',
      templateCode:'',
      variables:   '{"name":"송성일","orderNo":"ORD20260619001","amount":"150,000"}',
      content:     '',
    });

    const result = reactive({
      status:   '',
      response: null,
      error:    '',
      logs:     [],
    });

    const uiState = reactive({ loading: false });


    /* ##### [02] 초기 로드 #################################################### */

    /* initPage — 화면 로드 시퀀스. 마운트 시 실행한다. */
    const initPage = async () => {
      try {
        const res = await boApiSvc.syProp?.getList?.({
          propKeys: 'app.kakao.channel-id,app.kakao.biz-msg-api-key,app.kakao.sender-key,app.kakao.from',
        }, '카카오 채널 테스트', '키 조회');
        const list = res?.data?.data || [];
        const pickVal = (key) => { const rows = list.filter(p => p.propKey === key && p.propValue); const pref = rows.find(p => /local|dev/.test(p.propProfile || '')) || rows[0]; return pref?.propValue || ''; };
        cfg.channelId    = pickVal('app.kakao.channel-id');
        cfg.bizMsgApiKey = pickVal('app.kakao.biz-msg-api-key');
        cfg.senderKey    = pickVal('app.kakao.sender-key');
        cfg.from         = pickVal('app.kakao.from');
      } catch (e) {
        result.error = 'sy_prop 조회 실패: ' + (e.message || e);
      }
    };
    onMounted(initPage);

    /* ##### [03] 헬퍼 함수 #################################################### */

    const addLog = (msg, type = 'info') => {
      result.logs.unshift({ msg, type, time: new Date().toLocaleTimeString() });
      if (result.logs.length > 20) result.logs.pop();
    };

    const send = async () => {
      if (form.msgType !== 'channel_add' && !form.toPhone) { showToast('수신 번호를 입력하세요.', 'error'); return; }
      uiState.loading = true;
      result.status   = '⏳ 발송 중…';
      result.error    = '';
      result.response = null;
      let varsObj = {};
      try { varsObj = JSON.parse(form.variables || '{}'); } catch (e) { /* 무시 */ }
      addLog('[' + form.msgType + '] 발송 요청 → ' + (form.toPhone || form.templateCode));
      try {
        const res = await boApi.post('/co/ext/kakao-send/send', {
          msgType:      form.msgType,
          toPhone:      form.toPhone,
          templateCode: form.templateCode,
          variables:    varsObj,
          content:      form.content,
        }, coUtil.cofApiHdr('카카오채널 테스트', '발송'));
        result.response = res.data?.data || res.data;
        result.status   = '✅ 발송 완료';
        addLog('✅ 완료', 'success');
        showToast('발송 완료', 'success');
      } catch (e) {
        result.error  = coUtil.cofErrMsg(e, '발송 실패');
        result.status = '❌ 발송 실패';
        addLog('❌ ' + result.error, 'error');
        showToast(result.error, 'error', 0);
      }
      uiState.loading = false;
    };

    const saveKey = async () => {
      try {
        await boApi.put('/bo/sy/prop/bulk', [
          { propKey: 'app.kakao.channel-id',      propValue: cfg.channelId },
          { propKey: 'app.kakao.biz-msg-api-key', propValue: cfg.bizMsgApiKey },
          { propKey: 'app.kakao.sender-key',      propValue: cfg.senderKey },
          { propKey: 'app.kakao.from',            propValue: cfg.from },
        ], coUtil.cofApiHdr('카카오채널 테스트', '키 저장'));
        showToast('sy_prop 에 저장되었습니다.', 'success');
      } catch (e) {
        showToast(coUtil.cofErrMsg(e, '저장 실패'), 'error', 0);
      }
    };

    /* ##### [04] 액션 dispatch #################################################### */

    const handleBtnAction = (cmd) => {
      if (cmd === 'send')     return send();
      if (cmd === 'key-save') return saveKey();
    };

    /* ##### [05] 폼 컬럼 정의 #################################################### */

    const cfgFormColumns = [
      { key: 'channelId',    label: '채널 공개 ID',          type: 'text', placeholder: '@shopjoy',                              hint: 'app.kakao.channel-id',      mono: true },
      { key: 'from',         label: '발신 번호 (사전 등록)',  type: 'text', placeholder: '0212345678',                            hint: 'app.kakao.from' },
      { key: 'bizMsgApiKey', label: '비즈메시지 API Key',     type: 'text', placeholder: 'sy_prop: app.kakao.biz-msg-api-key',    hint: 'app.kakao.biz-msg-api-key', mono: true },
      { key: 'senderKey',    label: '발신 프로필 키 (Sender Key)', type: 'text', placeholder: 'sy_prop: app.kakao.sender-key',   hint: 'app.kakao.sender-key',      mono: true },
    ];

    const msgFormColumns = [
      { key: 'msgType',      label: '메시지 유형',  type: 'select',
        options: [{ value: 'alimtalk', label: '알림톡 (Alimtalk)' }, { value: 'friendtalk', label: '친구톡 (Friendtalk)' }, { value: 'channel_add', label: '채널 추가 요청' }],
        hint: 'msgType' },
      { key: 'toPhone',      label: '수신 번호',    type: 'text', placeholder: '01012345678',    hint: 'toPhone' },
      { key: 'templateCode', label: '템플릿 코드',  type: 'text', placeholder: 'ORDER_CONFIRM_01', mono: true, hint: 'templateCode',
        visible: (f) => f.msgType === 'alimtalk' },
      { key: 'variables',    label: '변수 (JSON)',  type: 'text', placeholder: '{"name":"홍길동"}', mono: true, hint: 'variables',
        visible: (f) => f.msgType === 'alimtalk' },
      { key: 'content',      label: '메시지 내용',  type: 'textarea', colSpan: 3,
        placeholder: '친구톡 내용을 입력하세요. (최대 1000자)',
        visible: (f) => f.msgType === 'friendtalk', hint: 'content' },
    ];

    return { cfg, form, result, uiState, handleBtnAction, cfgFormColumns, msgFormColumns };
  },

  template: `
<div>
  <div class="page-title">카카오 채널(알림톡/친구톡) 테스트</div>

  <!-- 키 설정 -->
  <div class="card" style="margin-bottom:12px">
    <div class="toolbar"><span class="list-title">카카오 비즈메시지 설정</span></div>
    <div style="padding:12px">
      <bo-form-area plain-readonly :columns="cfgFormColumns" :form="cfg" :errors="{}" :cols="3" :show-actions="false" :readonly="false" compact />
      <div class="form-actions" style="justify-content:flex-start;margin-top:8px">
        <button class="btn btn_save btn-sm" @click="handleBtnAction('key-save')">sy_prop 저장</button>
      </div>
    </div>
  </div>

  <!-- 발송 폼 -->
  <div class="card" style="margin-bottom:12px">
    <div class="toolbar">
      <span class="list-title">메시지 발송</span>
      <div style="margin-left:auto">
        <button class="btn btn_send btn-sm" :disabled="uiState.loading" @click="handleBtnAction('send')">
          {{ uiState.loading ? '⏳ 발송 중…' : '💬 발송' }}
        </button>
      </div>
    </div>
    <div style="padding:12px">
      <bo-form-area plain-readonly :columns="msgFormColumns" :form="form" :errors="{}" :cols="3" :show-actions="false" :readonly="false" compact />
      <div v-if="form.msgType==='channel_add'" style="padding:8px;background:#f0f4ff;border-radius:4px;font-size:12px;color:#444;margin-top:8px">
        채널 추가 요청 메시지를 발송합니다. 채널 ID: <b>{{ cfg.channelId || '(미설정)' }}</b>
      </div>
      <div v-if="result.status" style="margin-top:8px;font-size:13px;font-weight:600">{{ result.status }}</div>
      <div v-if="result.error" style="padding:8px;background:#fff5f5;border:1px solid #fca5a5;border-radius:4px;font-size:12px;color:#b91c1c;margin-top:8px">{{ result.error }}</div>
      <div v-if="result.response" style="padding:8px;background:#f0fdf4;border:1px solid #86efac;border-radius:4px;font-size:12px;margin-top:8px">
        <pre style="margin:0">{{ JSON.stringify(result.response, null, 2) }}</pre>
      </div>
    </div>
  </div>

  <!-- 이력 -->
  <div class="card" style="margin-bottom:12px">
    <div class="toolbar"><span class="list-title">발송 이력 (최근 20건)</span></div>
    <div style="padding:12px">
      <div v-if="!result.logs.length" style="color:#999;font-size:12px;text-align:center;padding:16px">발송 이력 없음</div>
      <div v-for="log in result.logs" :key="log.time" style="display:flex;gap:8px;font-size:12px;padding:4px 0;border-bottom:1px solid #f0f0f0">
        <span style="color:#999;white-space:nowrap">{{ log.time }}</span>
        <span :style="log.type==='error'?'color:#b91c1c':log.type==='success'?'color:#15803d':''">{{ log.msg }}</span>
      </div>
    </div>
  </div>

  <!-- 안내 -->
  <div class="card" style="margin-bottom:12px">
    <div class="toolbar"><span class="list-title">설정 안내</span></div>
    <div style="padding:12px;font-size:12px;line-height:1.8;color:#444">
      <b>1.</b> 카카오 비즈니스 채널 개설 → 카카오 비즈메시지 파트너사 등록<br>
      <b>2.</b> 알림톡 발신 프로필 등록 → Sender Key 발급<br>
      <b>3.</b> 알림톡 템플릿 등록 → 검수 완료 후 사용 가능<br>
      <b>4.</b> 비즈메시지 API Key 발급 (파트너사 포털)<br><br>
      <b>백엔드 API:</b> <code>POST /api/co/ext/kakao-send/send</code> → <code>CoExtKakaoSendController → CmKakaoSendService.sendKakao()</code><br>
      → <code>CmKakaoSendService</code> 경유 (알림톡/친구톡/채널추가 분기)
    </div>
  </div>

  <bo-zd-sy-prop-grid prop-key-prefixes="app.kakao." default-prop-key-filter="app.kakao" />
  <bo-zd-yml-grid endpoint="/bo/sy/app-config/kakao" default-key-filter="app.kakao" />
</div>`,
};
