/* ShopJoy Admin - 배치스케즐 상세/등록 */
export default {
  name: 'SyBatchDtl',
  props: {
    navigate:      { type: Function, required: true },        // 페이지 이동
    dtlId:         { type: String, default: null },           // 수정 대상 ID
    dtlMode:       { type: String, default: 'view' },         // 상세 모드 (new/view/edit)
    reloadTrigger: { type: Number, default: 0 },              // 첫 탭 저장 시 상위 Mng 재조회 (UX-bo §18)
  },
  setup(props) {

    /* ##### [01] 초기 변수 정의 #################################################### */

    const { reactive, computed, watch, onMounted, ref } = Vue;
    const showToast    = window.boApp.showToast;   // 토스트 알림
    const showConfirm  = window.boApp.showConfirm; // 확인 모달

    const uiState = reactive({ loading: false, error: null }); // UI 상태
    const codes = reactive({ active_statuses: [] });

    const form = reactive({                        // 배치 폼 데이터
      batchId: null, batchNm: '', batchCode: '', batchDesc: '', cronExpr: '0 0 * * *', batchStatusCd: '',
    });
    const errors = reactive({});                   // 폼 검증 에러

    const schema = yup.object({                    // 폼 검증 스키마
      batchNm: yup.string().required('배치명을 입력해주세요.'),
      batchCode: yup.string().required('배치코드를 입력해주세요.'),
      cronExpr: yup.string().required('Cron 표현식을 입력해주세요.'),
    });

    const CRON_PRESETS = [                         // Cron 프리셋 (편집 모드에서 노출)
      { label: '매일 자정 (0 0 * * *)', value: '0 0 * * *' },
      { label: '매일 오전 1시 (0 1 * * *)', value: '0 1 * * *' },
      { label: '매일 오전 2시 (0 2 * * *)', value: '0 2 * * *' },
      { label: '매시간 (0 * * * *)', value: '0 * * * *' },
      { label: '2시간마다 (0 */2 * * *)', value: '0 */2 * * *' },
      { label: '매주 일요일 자정 (0 0 * * 0)', value: '0 0 * * 0' },
      { label: '매월 1일 오전 8시 (0 8 1 * *)', value: '0 8 1 * *' },
    ];

    const cfIsNew = computed(() => props.dtlId === null || props.dtlId === undefined);
    const cfSiteNm = computed(() => boUtil.bofGetSiteNm());
    const cfDtlMode = computed(() => props.dtlMode === 'view'); // dtlMode: 'view' 이면 읽기전용, 'new'/'edit' 이면 편집

    /* ##### [02] 액션 모음 (dispatch) ############################################## */

    /* handleBtnAction — 버튼 액션 dispatch (cmd: '{영역명}-기능명'). 5줄 이하 짧은 로직은 인라인 */
    const handleBtnAction = (cmd, param = {}) => {
      console.log(' ■■ SyBatchDtl.js : handleBtnAction -> ', cmd, param);
      // 폼 저장 (신규 등록 또는 수정)
      if (cmd === 'form-save') {
        return handleSave();
      // 폼 편집 취소 → 목록으로 이동
      } else if (cmd === 'form-cancel') {
        return props.navigate('syBatchMng');
      // 상세 보기 → 편집 모드 전환
      } else if (cmd === 'form-edit') {
        return props.navigate('__switchToEdit__');
      // 폼 닫기 → 목록으로 이동
      } else if (cmd === 'form-close') {
        return props.navigate('syBatchMng');
      // Cron 프리셋 적용 (param 은 cron 문자열)
      } else if (cmd === 'cronPreset-apply') {
        form.cronExpr = param;
        return;
      } else {
        console.warn('[handleBtnAction] unknown cmd:', cmd);
      }
    };

    /* ##### [04] 내장 사용 함수 (이벤트 핸들러 on* / handle*) #################### */

    /* handleLoadDetail — 상세 조회 */
    const handleLoadDetail = async () => {
      if (cfIsNew.value) { return; }
      uiState.loading = true;
      try {
        const res = await boApiSvc.syBatch.getById(props.dtlId, '배치관리', '상세조회');
        const data = res.data?.data;
        if (data) { Object.assign(form, data); }
        uiState.error = null;
      } catch (err) {
        console.error('[catch-info]', err);
        uiState.error = err.message;
      } finally {
        uiState.loading = false;
      }
    };

    /* handleSave — 저장 (신규 등록 / 수정) */
    const handleSave = async () => {
      Object.keys(errors).forEach(k => delete errors[k]);
      try {
        await schema.validate(form, { abortEarly: false });
      } catch (err) {
        console.error('[catch-info]', err);
        err.inner.forEach(e => { errors[e.path] = e.message; });
        showToast('입력 내용을 확인해주세요.', 'error');
        return;
      }
      const ok = await showConfirm(cfIsNew.value ? '등록' : '저장', cfIsNew.value ? '등록하시겠습니까?' : '저장하시겠습니까?');
      if (!ok) { return; }
      try {
        const res = await (cfIsNew.value
          ? boApiSvc.syBatch.create({ ...form }, '배치관리', '등록')
          : boApiSvc.syBatch.update(form.batchId, { ...form }, '배치관리', '저장'));
        if (showToast) { showToast(cfIsNew.value ? '등록되었습니다.' : '저장되었습니다.', 'success'); }
        if (props.navigate) { props.navigate('syBatchMng', { reload: true }); }
      } catch (err) {
        console.error('[catch-info]', err);
        const errMsg = (err.response?.data?.message) || err.message || '오류가 발생했습니다.';
        if (showToast) { showToast(errMsg, 'error', 0); }
      }
    };

    /* fnLoadCodes — 공통코드 로드 */
    const fnLoadCodes = async () => {
      try {
        const codeStore = window.sfGetBoCodeStore();
        /* 필요한 코드그룹만 지연 로딩 — 캐시에 있으면 API 가 나가지 않는다 */
        await codeStore.saLoadCodes(['ACTIVE_STATUS'], {compNm: 'SyBatchDtl'});
        codes.active_statuses = codeStore.sgGetGrpCodes('ACTIVE_STATUS');
      } catch (err) {
        console.error('[fnLoadCodes]', err);
      }
    };

    // ★ onMounted — 진입 시 코드 로드 + 상세 조회
    /* initPage — 화면 로드 시퀀스.
       코드 응답을 받은 뒤 초기 조회를 시작한다 — 코드 기반 select·라벨·기본값이
       빈 상태로 첫 조회가 나가는 것을 막는다(순서가 코드에 드러나도록 한 곳에 모았다). */
    const initPage = async () => {
      await fnLoadCodes();
      if (!cfIsNew.value) { await handleLoadDetail(); }
      /* 신규 등록 입력 최소화(2026-08-29) — 이전엔 '활성' 이 실제 codeValue 가 아니라
         select 가 빈 값으로 보였다. 코드그룹의 첫 번째 값을 기본 선택. */
      else { form.batchStatusCd = codes.active_statuses[0]?.codeValue || ''; }
    };
    onMounted(initPage);

    /* policy: 상위 Mng 이 reloadTrigger 증가시키면 상세 API 재조회 */
    watch(() => props.reloadTrigger, async (n, o) => {
      if (n === o || n === 0) { return; }
      try { Object.keys(errors).forEach(k => delete errors[k]); } catch(_) {}
      await handleLoadDetail();
    });

    /* ##### [05] 사용자 함수 (헬퍼 / 카운트 / 렌더 / 컬럼정의) #################### */

    // 기본 폼
    const columns = {};
    columns.baseForm = [
      { key: '_siteNm',       label: '사이트명', type: 'readonly', fmt: () => cfSiteNm.value, colSpan: 2 },
      { key: 'batchNm',       label: '배치명', type: 'text', required: true, placeholder: '배치 이름' },
      { key: 'batchCode',     label: '배치코드', type: 'text', required: true,
        placeholder: 'ORDER_AUTO_COMPLETE', mono: true },
      { key: 'batchDesc',     label: '설명', type: 'text', placeholder: '배치 처리 내용 설명', colSpan: 2 },
      { key: 'cronExpr',      label: 'Cron 표현식', type: 'text', required: true,
        placeholder: '0 0 * * *', mono: true, hint: '분 시 일 월 요일', colSpan: 2 },
      { key: '_cronPreset',   label: 'Cron 프리셋', type: 'slot', name: 'cronPreset',
        colSpan: 2, visible: () => !cfDtlMode.value },
      { key: 'batchStatusCd', label: '활성여부', type: 'select', options: () => codes.active_statuses },
    ];

    /* ##### [06] return (템플릿 노출) ############################################## */

    return {
      columns,
      form, errors, CRON_PRESETS,                // 상태 / 데이터
      handleBtnAction,                                       // dispatch (모든 이벤트 / 액션 라우팅)
      cfIsNew, cfDtlMode,          // computed
    };
  },
  template: /* html */`
<bo-container :title="cfIsNew ? '배치 등록' : (cfDtlMode ? '배치 상세' : '배치 수정')"
  :title-id="cfIsNew ? '' : form.batchId">
  <!-- ===== ■. 폼 영역 (BoFormArea 자동 렌더) ================================= -->
  <bo-form-area plain-readonly :columns="columns.baseForm" :form="form" :errors="errors"
    :readonly="cfDtlMode" :cols="3" compact :show-delete="false"
    @save="handleBtnAction('form-save')"
    @cancel="handleBtnAction('form-cancel')"
    @edit="handleBtnAction('form-edit')"
    @close="handleBtnAction('form-close')">
    <!-- ===== ■.■.■. Cron 프리셋 버튼 그룹 (편집 모드에서만 노출) =================== -->
    <template #cronPreset>
      <div style="padding:10px 12px;background:#f8f9fa;border-radius:6px;">
        <div style="display:flex;flex-wrap:wrap;gap:6px;">
          <button v-for="p in CRON_PRESETS" :key="p.value"
            class="btn btn-secondary btn-sm"
            style="font-size:11px;"
            @click="handleBtnAction('cronPreset-apply', p.value)">
            {{ p.label }}
          </button>
        </div>
      </div>
    </template>
  </bo-form-area>
  <!-- ===== □. 폼 영역 ==================================================== -->
</bo-container>
`,
};
