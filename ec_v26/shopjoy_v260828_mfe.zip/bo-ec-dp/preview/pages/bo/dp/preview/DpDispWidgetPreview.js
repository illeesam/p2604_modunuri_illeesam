/* ShopJoy Admin - 전시위젯미리보기 (#page=ecDispWidgetLibPreview) */

/* -- 위젯미리보기 서브컴포넌트 (grid · dashboard 공용)
 * 백엔드 DTO 필드(widgetTypeCd / widgetNm / widgetDesc / widgetConfigJson / thumbnailUrl 등) 기준
 * + UI 호환 별칭(widgetType / name) 도 함께 인식
 * + dp_widget 의 widgetConfigJson 도 파싱하여 콘텐츠 추출
 * 23종 위젯 유형 모두 분기 처리
 */
const _WP_DispWidgetPreview = {
  name: 'WidgetPreview',
  props: { lib: Object, compact: { type: Boolean, default: false } },
  setup(props) {
    // ===== 초기 변수 정의 =====================================================

    const { reactive, computed } = Vue;
    const codes = reactive({ disp_widget_types: [] });
    const uiState = reactive({});
    const chartColors = coUtil.cofChartColors();  // 전시 차트 공용 팔레트

    // ===== 초기 함수 (마운트 / 코드 로드 / watch) =============================

    /* fnLoadCodes — 이 화면이 쓰는 코드그룹만 지연 로딩 */
    const fnLoadCodes = async () => {
      const codeStore = window.sfGetBoCodeStore?.();
      if (codeStore) {
        /* 필요한 코드그룹만 지연 로딩 — 캐시에 있으면 API 가 나가지 않는다 */
        await codeStore.saLoadCodes(['WIDGET_TYPE_CD'], {compNm: 'DpDispWidgetPreview'});
        codes.disp_widget_types = codeStore.sgGetGrpCodes('WIDGET_TYPE_CD') || [];
      }
    };

    /* -- 위젯 유형 (DTO / UI 호환 별칭 모두 지원) -- */
    const cfType = computed(() => {
      const w = props.lib || {};
      return w.widgetTypeCd || w.widgetType || '';
    });

    /* -- 위젯명 -- */
    const cfName = computed(() => {
      const w = props.lib || {};
      return w.widgetNm || w.name || w.widgetTitle || '';
    });

    /* -- 설명 -- */
    const cfDesc = computed(() => {
      const w = props.lib || {};
      return w.widgetLibDesc || w.widgetDesc || w.desc || '';
    });

    /* -- 콘텐츠 (dp_widget.widget_content) -- */
    const cfContent = computed(() => (props.lib || {}).widgetContent || '');

    /* -- config: widgetConfigJson 단일 컬럼으로 통일됨 (3개 테이블 모두) -- */
    const cfConfig = computed(() => {
      const w = props.lib || {};

      /* tryParse — try 파싱 */
      const tryParse = (s) => { try { return JSON.parse(s); } catch (_) { return null; } };
      const cfgJson  = tryParse(w.widgetConfigJson);
      if (!cfgJson) { return {}; }
      /* JSON Schema 인 경우 properties 의 default 값을 평탄화 */
      if (cfgJson.properties) {
        const out = {};
        Object.keys(cfgJson.properties).forEach(k => {
          const p = cfgJson.properties[k];
          if (p && 'default' in p) { out[k] = p.default; }
        });
        return out;
      }
      /* 실데이터 객체인 경우 그대로 사용 */
      return cfgJson;
    });

    /* 썸네일 / 미리보기 이미지 — 서버 '/cdn/...' 경로 → 'assets/cdn/...' 정규화 */
    const cfImg = computed(() => {
      const w = props.lib || {};
      const rawUrl = cfConfig.value.img_url || cfConfig.value.imageUrl
          || w.thumbnailUrl || w.imageUrl || '';
      return coUtil.cofImgSrc(rawUrl);
    });

    /* 차트 막대 데이터 */
    const cfChartBars = computed(() => {
      /* 1. configJson 에 values 있으면 사용 */
      const cfg = cfConfig.value;
      let values = null, labels = null;
      if (Array.isArray(cfg.values)) { values = cfg.values.map(Number); }
      else if (typeof cfg.chartValues === 'string') { values = cfg.chartValues.split(',').map(v => Number(v.trim()) || 0); }
      else if (typeof (props.lib || {}).chartValues === 'string') {
        values = (props.lib.chartValues || '').split(',').map(v => Number(v.trim()) || 0);
      }
      /* 2. 데이터 없으면 더미 (차트 미리보기 항상 보여주기) */
      if (!values || !values.length) { values = [40, 65, 30, 80, 55, 70, 45]; }
      if (Array.isArray(cfg.labels)) { labels = cfg.labels; }
      else if (typeof cfg.chartLabels === 'string') { labels = cfg.chartLabels.split(',').map(l => l.trim()); }
      else if (typeof (props.lib || {}).chartLabels === 'string') {
        labels = (props.lib.chartLabels || '').split(',').map(l => l.trim());
      }
      if (!labels || !labels.length) { labels = ['월','화','수','목','금','토','일']; }
      const max = Math.max(...values, 1);
      return values.map((v,i) => ({ v, label: labels[i] || '', pct: Math.round((v/max)*100), color: chartColors[i % chartColors.length] }));
    });

    /* 파이 차트 segments / gradient — coUtil 위임 (세그먼트·conic-gradient 공용) */
    const cfPie = computed(() => coUtil.cofChartPie(cfChartBars.value));
    const cfPieGradient = computed(() => coUtil.cofChartPieGradient(cfPie.value));

    // ===== return (템플릿 노출) ===============================================

    return { cfType, cfName, cfDesc, cfContent, cfConfig, cfImg, cfChartBars, cfPie, cfPieGradient };
  },
  template: /* html */`
<div style="padding:10px;">
  <!-- ===== ■. 미리보기 ==================================================== -->

  <!-- ===== ■. 1) 이미지 배너 =============================================== -->
  <template v-if="cfType==='image_banner'">
    <div style="border-radius:6px;overflow:hidden;background:#f0f0f0;">
      <img v-if="cfImg" :src="cfImg" style="width:100%;display:block;max-height:130px;object-fit:cover;" @error="$event.target.style.display='none'" />
      <div v-else style="height:80px;display:flex;align-items:center;justify-content:center;color:#ccc;font-size:12px;">🖼 이미지 배너</div>
    </div>
    <div style="font-size:11px;color:#444;margin-top:6px;font-weight:600;">{{ cfName }}</div>
    <div v-if="cfConfig.alt" style="font-size:10px;color:#888;margin-top:2px;">{{ cfConfig.alt }}</div>
  </template>

  <!-- ===== □. 1) 이미지 배너 =============================================== -->
  <!-- ===== ■. 2) 텍스트 배너 =============================================== -->
  <template v-else-if="cfType==='text_banner'">
    <div :style="{background:cfConfig.bg_color||cfConfig.bgColor||'#fff0f4',color:cfConfig.text_color||cfConfig.textColor||'#c0396a',padding:'14px',borderRadius:'6px',border:'1px solid #ffe4ec',fontSize:'13px',fontWeight:600,textAlign:'center'}">
      <span v-if="cfConfig.icon" style="margin-right:6px;">{{ cfConfig.icon }}</span>
      <span>{{ cfConfig.text || cfContent || cfName }}</span>
    </div>
  </template>

  <!-- ===== □. 2) 텍스트 배너 =============================================== -->
  <!-- ===== ■. 3) 정보 카드 ================================================ -->
  <template v-else-if="cfType==='info_card'">
    <div style="background:#f0f9ff;border-radius:6px;padding:12px;border:1px solid #bae6fd;display:flex;gap:10px;align-items:flex-start;">
      <span style="font-size:24px;flex-shrink:0;">{{ cfConfig.icon || '📦' }}</span>
      <div style="flex:1;min-width:0;">
        <div style="font-size:12px;font-weight:700;color:#0369a1;margin-bottom:3px;">{{ cfConfig.title || cfName || '카드 제목' }}</div>
        <div style="font-size:11px;color:#0c4a6e;line-height:1.5;">{{ cfConfig.content || cfDesc || '카드 내용' }}</div>
      </div>
    </div>
  </template>

  <!-- ===== □. 3) 정보 카드 ================================================ -->
  <!-- ===== ■. 4) 텍스트 영역 =============================================== -->
  <template v-else-if="cfType==='textarea'">
    <div style="font-size:11px;color:#374151;line-height:1.6;white-space:pre-wrap;background:#f9fafb;padding:10px;border-radius:5px;border:1px solid #e5e7eb;max-height:120px;overflow:hidden;">{{ cfConfig.text || cfContent || cfName }}</div>
  </template>

  <!-- ===== □. 4) 텍스트 영역 =============================================== -->
  <!-- ===== ■. 5) Markdown ============================================= -->
  <template v-else-if="cfType==='markdown'">
    <div style="font-size:11px;color:#374151;line-height:1.6;white-space:pre-wrap;font-family:monospace;background:#f3f4f6;padding:10px;border-radius:5px;border:1px solid #d1d5db;max-height:120px;overflow:hidden;">{{ cfConfig.markdown || cfContent || ('## ' + cfName + '\\n- 항목1\\n- 항목2') }}</div>
  </template>

  <!-- ===== □. 5) Markdown ============================================= -->
  <!-- ===== ■. 6) HTML 에디터 ============================================= -->
  <template v-else-if="cfType==='html_editor'">
    <div v-if="cfContent || cfConfig.html" v-html="cfContent || cfConfig.html" style="font-size:12px;overflow:hidden;max-height:120px;border:1px solid #eee;border-radius:5px;padding:8px;background:#fff;"></div>
    <div v-else style="color:#bbb;font-size:11px;padding:14px;background:#fafafa;border-radius:5px;border:1px dashed #d1d5db;text-align:center;">HTML 콘텐츠 없음</div>
  </template>

  <!-- ===== □. 6) HTML 에디터 ============================================= -->
  <!-- ===== ■. 7) 팝업 =================================================== -->
  <template v-else-if="cfType==='popup'">
    <div style="border:2px solid #cbd5e1;border-radius:8px;overflow:hidden;background:#fff;box-shadow:0 4px 12px rgba(0,0,0,0.08);">
      <div style="background:#1e293b;color:#fff;padding:6px 12px;font-size:11px;display:flex;justify-content:space-between;align-items:center;">
        <span>{{ cfConfig.title || cfName || '공지 팝업' }}</span><span style="">✕</span>
      </div>
      <div style="padding:12px;text-align:center;">
        <img v-if="cfImg" :src="cfImg" style="max-width:100%;max-height:80px;border-radius:4px;" @error="$event.target.style.display='none'" />
        <div v-else style="height:60px;display:flex;align-items:center;justify-content:center;color:#bbb;font-size:11px;">팝업 이미지</div>
        <div style="font-size:10px;color:#64748b;margin-top:6px;">오늘 하루 안 보기</div>
      </div>
    </div>
  </template>

  <!-- ===== □. 7) 팝업 =================================================== -->
  <!-- ===== ■. 8) 파일 다운로드 ============================================== -->
  <template v-else-if="cfType==='file'">
    <div style="display:flex;align-items:center;gap:10px;padding:12px;border:1px solid #e5e7eb;border-radius:6px;background:#f9fafb;">
      <span style="font-size:24px;">📎</span>
      <div style="flex:1;min-width:0;">
        <div style="font-size:12px;font-weight:600;color:#222;">{{ cfConfig.btn_label || cfName || '파일 다운로드' }}</div>
        <div style="font-size:10px;color:#666;margin-top:2px;">{{ cfConfig.file_size || '1.2MB' }} · {{ (cfConfig.file_url || '').split('/').pop() || cfName + '.pdf' }}</div>
      </div>
      <button style="font-size:11px;padding:4px 10px;border-radius:4px;border:1px solid #1677ff;background:#fff;color:#1677ff;">⬇</button>
    </div>
  </template>

  <!-- ===== □. 8) 파일 다운로드 ============================================== -->
  <!-- ===== ■. 9) 파일 목록 ================================================ -->
  <template v-else-if="cfType==='file_list'">
    <div style="border:1px solid #e5e7eb;border-radius:6px;overflow:hidden;">
      <div v-for="(f,i) in ((Array.isArray(cfConfig.files) ? cfConfig.files.length : false) ? cfConfig.files : [{nm:'카탈로그.pdf'},{nm:'가격표.pdf'},{nm:'사용자매뉴얼.pdf'}])" :key="i"
           style="display:flex;align-items:center;gap:8px;padding:7px 10px;font-size:11px;border-bottom:1px solid #f0f0f0;background:#fff;">
        <span>📄</span><span style="flex:1;color:#374151;">{{ f.nm || f.name || ('파일 ' + (i+1)) }}</span>
        <span style="color:#1677ff;font-size:10px;">⬇</span>
      </div>
    </div>
  </template>

  <!-- ===== □. 9) 파일 목록 ================================================ -->
  <!-- ===== ■. 10) 동영상 플레이어 ============================================ -->
  <template v-else-if="cfType==='video_player'">
    <div style="position:relative;background:#000;border-radius:6px;overflow:hidden;">
      <img v-if="cfImg || cfConfig.poster_url" :src="cfImg || cfConfig.poster_url" style="width:100%;display:block;height:120px;object-fit:cover;opacity:.85;" @error="$event.target.style.display='none'" />
      <div v-else style="height:120px;background:linear-gradient(135deg,#1e293b,#0f172a);"></div>
      <div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;">
        <span style="font-size:36px;color:#fff;background:rgba(0,0,0,0.4);width:54px;height:54px;border-radius:50%;display:flex;align-items:center;justify-content:center;">▶</span>
      </div>
      <div style="position:absolute;bottom:0;left:0;right:0;background:linear-gradient(to top,rgba(0,0,0,0.7),transparent);color:#fff;padding:14px 10px 6px;font-size:11px;font-weight:600;">{{ cfName }}</div>
    </div>
  </template>

  <!-- ===== □. 10) 동영상 플레이어 ============================================ -->
  <!-- ===== ■. 11~12) 상품 슬라이더 / 그리드 ==================================== -->
  <template v-else-if="cfType==='product_slider' || cfType==='product'">
    <div style="font-size:11px;font-weight:700;color:#222;margin-bottom:6px;display:flex;align-items:center;gap:6px;">
      <span>{{ cfType==='product_slider' ? '🛒 슬라이더' : '📦 상품 그리드' }}</span>
      <span style="font-size:10px;color:#888;font-weight:400;">{{ cfConfig.category_id || cfName }}</span>
    </div>
    <div :style="{display:'grid',gridTemplateColumns: cfType==='product_slider' ? 'repeat(4, 1fr)' : 'repeat(2, 1fr)',gap:'5px'}">
      <div v-for="i in 4" :key="i" style="text-align:center;">
        <div style="aspect-ratio:1;background:linear-gradient(135deg,#fce7f3,#fbcfe8);border-radius:5px;margin-bottom:3px;display:flex;align-items:center;justify-content:center;font-size:18px;">{{ ['👗','👔','👜','👟'][i-1] }}</div>
        <div style="font-size:9px;color:#374151;">상품{{ i }}</div>
        <div style="font-size:9px;color:#e8587a;font-weight:700;">₩29,900</div>
      </div>
    </div>
  </template>

  <!-- ===== □. 11~12) 상품 슬라이더 / 그리드 ==================================== -->
  <!-- ===== ■. 13) 조건상품 ================================================ -->
  <template v-else-if="cfType==='cond_product'">
    <div style="font-size:11px;font-weight:700;color:#222;margin-bottom:6px;">🔍 {{ cfConfig.condition || 'BEST_SELLER' }}</div>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:4px;">
      <div v-for="i in 3" :key="i" style="aspect-ratio:1;background:linear-gradient(135deg,#dcfce7,#bbf7d0);border-radius:5px;display:flex;flex-direction:column;align-items:center;justify-content:center;font-size:9px;color:#15803d;font-weight:600;gap:2px;">
        <span style="font-size:18px;">{{ ['🥇','🥈','🥉'][i-1] }}</span><span>BEST {{ i }}</span>
      </div>
    </div>
  </template>

  <!-- ===== □. 13) 조건상품 ================================================ -->
  <!-- ===== ■. 14) 쿠폰 ================================================== -->
  <template v-else-if="cfType==='coupon'">
    <div style="background:linear-gradient(135deg,#e8587a,#f97316);border-radius:8px;padding:14px;color:#fff;display:flex;align-items:center;gap:12px;">
      <span style="font-size:28px;">🎟</span>
      <div style="flex:1;min-width:0;">
        <div style="font-size:10px;opacity:.9;">{{ cfConfig.coupon_id || '쿠폰' }}</div>
        <div style="font-size:14px;font-weight:800;">{{ cfConfig.btn_label || cfName }}</div>
      </div>
      <div style="border:2px dashed rgba(255,255,255,.6);border-radius:6px;padding:6px 12px;font-size:11px;font-weight:700;white-space:nowrap;">발급</div>
    </div>
  </template>

  <!-- ===== □. 14) 쿠폰 ================================================== -->
  <!-- ===== ■. 15) 카운트다운 =============================================== -->
  <template v-else-if="cfType==='countdown'">
    <div style="background:linear-gradient(135deg,#1e1b4b,#312e81);border-radius:8px;padding:12px;color:#fff;text-align:center;">
      <div style="font-size:11px;opacity:.8;margin-bottom:6px;">⏱ {{ cfConfig.label || cfName || '이벤트 종료까지' }}</div>
      <div style="display:flex;justify-content:center;gap:6px;">
        <div v-for="(v,i) in [12,23,45,30]" :key="i" style="background:rgba(255,255,255,0.15);border-radius:4px;padding:4px 8px;min-width:32px;">
          <div style="font-size:14px;font-weight:800;">{{ String(v).padStart(2,'0') }}</div>
          <div style="font-size:8px;opacity:.7;">{{ ['DAY','HR','MIN','SEC'][i] }}</div>
        </div>
      </div>
    </div>
  </template>

  <!-- ===== □. 15) 카운트다운 =============================================== -->
  <!-- ===== ■. 16) 막대 차트 =============================================== -->
  <template v-else-if="cfType==='chart_bar'">
    <div style="font-size:11px;font-weight:700;color:#222;margin-bottom:6px;">📊 {{ cfConfig.title || cfName }}</div>
    <div style="display:flex;align-items:flex-end;gap:3px;height:80px;background:#fafafa;border-radius:5px;padding:8px;">
      <div v-for="(bar,i) in cfChartBars" :key="i" style="flex:1;display:flex;flex-direction:column;align-items:center;gap:3px;">
        <div :style="{height:bar.pct+'%',background:bar.color,borderRadius:'2px 2px 0 0',width:'100%',minHeight:'4px'}"></div>
        <div style="font-size:8px;color:#888;">{{ bar.label }}</div>
      </div>
    </div>
  </template>

  <!-- ===== □. 16) 막대 차트 =============================================== -->
  <!-- ===== ■. 17) 라인 차트 =============================================== -->
  <template v-else-if="cfType==='chart_line'">
    <div style="font-size:11px;font-weight:700;color:#222;margin-bottom:6px;">📈 {{ cfConfig.title || cfName }}</div>
    <div style="position:relative;height:80px;background:#fafafa;border-radius:5px;padding:8px;">
      <svg viewBox="0 0 100 50" preserveAspectRatio="none" style="width:100%;height:100%;">
        <polyline :points="cfChartBars.map((b,i) => (i*(100/(cfChartBars.length-1||1))) + ',' + (50-b.pct/2)).join(' ')"
                  fill="none" stroke="#1677ff" stroke-width="1.5" />
        <circle v-for="(b,i) in cfChartBars" :key="i"
                :cx="i*(100/(cfChartBars.length-1||1))" :cy="50-b.pct/2" r="1.2" fill="#1677ff" />
      </svg>
    </div>
  </template>

  <!-- ===== □. 17) 라인 차트 =============================================== -->
  <!-- ===== ■. 18) 파이 차트 =============================================== -->
  <template v-else-if="cfType==='chart_pie'">
    <div style="font-size:11px;font-weight:700;color:#222;margin-bottom:6px;">🥧 {{ cfConfig.title || cfName }}</div>
    <div style="display:flex;align-items:center;gap:10px;">
      <div :style="{width:'70px',height:'70px',borderRadius:'50%',background:cfPieGradient,flexShrink:0}"></div>
      <div style="flex:1;display:flex;flex-direction:column;gap:3px;">
        <div v-for="(s,i) in cfPie.slice(0,5)" :key="i" style="display:flex;align-items:center;gap:5px;font-size:10px;">
          <span :style="{width:'10px',height:'10px',background:s.color,borderRadius:'2px'}"></span>
          <span style="flex:1;color:#555;">{{ s.label }}</span>
          <span style="color:#888;">{{ s.ratio }}%</span>
        </div>
      </div>
    </div>
  </template>

  <!-- ===== □. 18) 파이 차트 =============================================== -->
  <!-- ===== ■. 19) 바코드 ================================================= -->
  <template v-else-if="cfType==='barcode'">
    <div style="background:#fff;border:1px solid #ddd;border-radius:6px;padding:14px;text-align:center;">
      <div style="font-family:monospace;font-size:36px;letter-spacing:-2px;color:#000;line-height:1;font-weight:900;">||‖|‖‖|||‖|‖|||‖||‖|||</div>
      <div style="font-family:monospace;font-size:10px;color:#666;margin-top:5px;letter-spacing:2px;">{{ cfConfig.value || cfName || 'BC-001' }}</div>
    </div>
  </template>

  <!-- ===== □. 19) 바코드 ================================================= -->
  <!-- ===== ■. 20) QR 코드 =============================================== -->
  <template v-else-if="cfType==='qrcode'">
    <div style="background:#fff;border:1px solid #ddd;border-radius:6px;padding:12px;text-align:center;">
      <div style="display:inline-block;padding:6px;background:#fff;border:2px solid #000;font-family:monospace;font-size:7px;line-height:0.9;color:#000;font-weight:900;letter-spacing:0;white-space:pre;">{{
'■■■ ■ ■ ■■■\\n■   ■■■   ■\\n■ ■  ■  ■ ■\\n  ■ ■■■ ■  \\n■ ■ ■   ■ ■\\n  ■■■ ■■■  \\n■■■   ■ ■■■'
      }}</div>
      <div style="font-size:10px;color:#666;margin-top:5px;">{{ cfConfig.value || cfName }}</div>
    </div>
  </template>

  <!-- ===== □. 20) QR 코드 =============================================== -->
  <!-- ===== ■. 21) 바코드 + QR ============================================ -->
  <template v-else-if="cfType==='barcode_qrcode'">
    <div style="display:flex;gap:10px;align-items:center;background:#fff;border:1px solid #ddd;border-radius:6px;padding:10px;">
      <div style="flex:1;text-align:center;">
        <div style="font-family:monospace;font-size:22px;letter-spacing:-2px;font-weight:900;">||‖|‖‖|||‖|‖||</div>
        <div style="font-family:monospace;font-size:9px;color:#666;margin-top:3px;">{{ cfConfig.barcode_value || 'BC-001' }}</div>
      </div>
      <div style="width:50px;height:50px;background:#000;border-radius:3px;display:flex;align-items:center;justify-content:center;color:#fff;font-size:9px;">QR</div>
    </div>
  </template>

  <!-- ===== □. 21) 바코드 + QR ============================================ -->
  <!-- ===== ■. 22) 결제위젯 ================================================ -->
  <template v-else-if="cfType==='payment_widget'">
    <div style="background:linear-gradient(135deg,#3b82f6,#1e40af);border-radius:8px;padding:14px;color:#fff;">
      <div style="font-size:10px;opacity:.8;">💳 결제 금액</div>
      <div style="font-size:20px;font-weight:800;margin:4px 0;">₩{{ (cfConfig.amount || 29900).toLocaleString() }}</div>
      <div style="display:flex;gap:4px;margin-top:8px;">
        <div v-for="m in ['카드','토스','카카오']" :key="m" style="flex:1;background:rgba(255,255,255,0.2);border-radius:4px;padding:4px 0;text-align:center;font-size:10px;font-weight:600;">{{ m }}</div>
      </div>
    </div>
  </template>

  <!-- ===== □. 22) 결제위젯 ================================================ -->
  <!-- ===== ■. 23) 전자결재 ================================================ -->
  <template v-else-if="cfType==='approval_widget'">
    <div style="background:#fff;border:1px solid #e5e7eb;border-radius:6px;padding:12px;">
      <div style="font-size:11px;font-weight:700;color:#222;margin-bottom:8px;">✅ {{ cfName || '전자결재' }}</div>
      <div style="display:flex;justify-content:space-between;font-size:10px;">
        <div v-for="(s,i) in ['담당자','팀장','부서장']" :key="i" style="text-align:center;flex:1;">
          <div :style="{width:'34px',height:'34px',margin:'0 auto 4px',borderRadius:'50%',background:i<2?'#22c55e':'#e5e7eb',color:'#fff',display:'flex',alignItems:'center',justifyContent:'center',fontSize:'14px'}">{{ i<2 ? '✓' : '?' }}</div>
          <div style="color:#555;">{{ s }}</div>
        </div>
      </div>
    </div>
  </template>

  <!-- ===== □. 23) 전자결재 ================================================ -->
  <!-- ===== ■. 기타 ====================================================== -->
  <template v-else>
    <div style="background:#f5f5f5;border-radius:6px;padding:16px;text-align:center;color:#9ca3af;">
      <div style="font-size:24px;margin-bottom:4px;">▪</div>
      <div style="font-size:11px;font-weight:600;">{{ cfName || '미리보기' }}</div>
      <div v-if="cfType" style="font-size:10px;color:#bbb;margin-top:2px;">{{ cfType }}</div>
    </div>
  </template>
</div>
  
  <!-- ===== □. 기타 ====================================================== -->`,
};

/* -- 메인 컴포넌트 -- */
export default {
  name: 'dp-preview-dpDispWidgetPreview',
  props: {
    navigate:     { type: Function, required: true }, // 페이지 이동
  },
  setup(props) {
    // ===== 초기 변수 정의 =====================================================

    const { reactive, computed, ref, watch, onMounted, nextTick, watchEffect } = Vue;
    const codes = reactive({ disp_widget_types: [], disp_envs: [],
      /* 상태는 dp_widget.use_yn 파생 (구 ACTIVE_STATUS 코드그룹 미사용) */
      active_statuses: [{ codeValue: '활성', codeLabel: '활성' }, { codeValue: '비활성', codeLabel: '비활성' }],
      visibility_opts: [
      { value: '', label: '전체' },
      { value: 'PUBLIC',    label: '전체공개' },
      { value: 'MEMBER',    label: '회원공개' },
      { value: 'VERIFIED',  label: '인증회원' },
      { value: 'PREMIUM',   label: '우수회원↑' },
      { value: 'VIP',       label: 'VIP전용' },
      { value: 'INVITED',   label: '초대회원' },
      { value: 'STAFF',     label: '직원' },
      { value: 'EXECUTIVE', label: '임직원' },
    ] });
    const uiState = reactive({ selectedLibId: null });
    const widgetLibs = reactive([]);

    /* handleBtnAction — 버튼 액션 dispatch (cmd: '{영역명}-기능명'). 5줄 이하 짧은 로직은 인라인 */
    const handleBtnAction = (cmd, param = {}) => {
      console.log(' ■■ DpDispWidgetPreview.js : handleBtnAction -> ', cmd, param);
      // 검색조건으로 목록 필터링
      if (cmd === 'searchParam-list') {
        return onSearch();
      // 검색조건 초기화
      } else if (cmd === 'searchParam-reset') {
        return onReset();
      // 트리 전체 펼치기
      } else if (cmd === 'pathTree-expand-all') {
        return expandAll();
      // 트리 전체 닫기
      } else if (cmd === 'pathTree-collapse-all') {
        return collapseAll();
      // 실제컨텐츠 토글
      } else if (cmd === 'preview-toggle-real') {
        gridState.showRealContent = !gridState.showRealContent;
        return;
      // 현재 그리드 / 대시보드 초기화
      } else if (cmd === 'preview-reset') {
        return resetCurrent();
      // span 팝업 닫기
      } else if (cmd === 'spanPopup-close') {
        return closeSpanPopup();
      // 슬롯 제거 (param: idx)
      } else if (cmd === 'slot-remove') {
        return removeSlot(param);
      // 대시보드 항목 제거 (param: id)
      } else if (cmd === 'dashItem-remove') {
        return removeDashItem(param);
      } else {
        console.warn('[handleBtnAction] unknown cmd:', cmd);
      }
    };

    /* handleSelectAction — 그리드 행/노드/모달 선택 액션 dispatch (cmd: '{영역명}-기능명'). 5줄 이하 짧은 로직은 인라인 */
    const handleSelectAction = (cmd, param = {}) => {
      console.log(' ■■ DpDispWidgetPreview.js : handleSelectAction -> ', cmd, param);
      // 트리 노드 토글 (param: key)
      if (cmd === 'pathTree-toggle') {
        return toggleNode(param);
      // 트리에서 위젯 선택 (param: lib)
      } else if (cmd === 'pathTree-select') {
        return onTreeSelect(param);
      // 그리드 탭 전환 (param: tabId)
      } else if (cmd === 'preview-tab') {
        gridState.previewGrid = param;
        return;
      // 뷰포트 모드 변경 (param: key)
      } else if (cmd === 'preview-viewport') {
        gridState.viewportMode = param;
        return;
      // span 설정 (param: { idx, axis, delta })
      } else if (cmd === 'slot-span-set') {
        return setSpan(param.idx, param.axis, param.delta);
      // span 팝업 토글 (param: { e, idx })
      } else if (cmd === 'slot-span-popup') {
        return toggleSpanPopup(param.e, param.idx);
      } else {
        console.warn('[handleSelectAction] unknown cmd:', cmd);
      }
    };

    // ===== 내장 사용 함수 (이벤트 핸들러 on* / handle*) =======================

    /* fnLoadCodes — 이 화면이 쓰는 코드그룹만 지연 로딩 */
    const fnLoadCodes = async () => {
      const codeStore = window.sfGetBoCodeStore();
      /* 필요한 코드그룹만 지연 로딩 — 캐시에 있으면 API 가 나가지 않는다 */
      await codeStore.saLoadCodes(['WIDGET_TYPE_CD', 'DISP_ENV'], {compNm: 'DpDispWidgetPreview'});
      codes.disp_widget_types = codeStore.sgGetGrpCodes('WIDGET_TYPE_CD');
      codes.disp_envs = codeStore.sgGetGrpCodes('DISP_ENV');
    };

    /* handleSearchList — 실 dp_widget(위젯 인스턴스) 조회 + 어댑터 (config 펼침, 유형별 트리 그룹) */
    const handleSearchList = async () => {
      try {
        const res = await boApiSvc.dpWidget.getPage({ pageNo: 1, pageSize: 10000 }, '전시위젯미리보기', '조회');
        const rows = (res.data?.data?.pageList || []).map(x => {
          let cfg = {}; try { cfg = JSON.parse(x.widgetConfigJson || '{}'); } catch (e) { /* 파싱 실패 무시 */ }
          return { ...cfg, ...x, name: x.widgetNm, widgetType: x.widgetTypeCd, desc: x.widgetDesc,
                   libId: x.widgetId, tags: cfg.tags || '', pathId: x.widgetTypeCd };
        });
        widgetLibs.splice(0, widgetLibs.length, ...rows);
      } catch (err) { console.error('[handleSearchList]', err); }
    };


    /* initPage — 화면 로드 시퀀스.
       코드 응답을 받은 뒤 초기 조회를 시작한다 — 코드 기반 select·라벨·기본값이
       빈 상태로 첫 조회가 나가는 것을 막는다(순서가 코드에 드러나도록 한 곳에 모았다). */
    const initPage = async () => {
      await fnLoadCodes();
      await handleSearchList('DEFAULT');
      Object.assign(searchParamInit, searchParam);   // [초기화] 기준값 스냅샷
    };
    onMounted(initPage);
    const cfSiteNm = computed(() => boUtil.bofGetSiteNm());

    const today   = coUtil.cofToYmd(new Date());
    const nowTime = new Date().toTimeString().slice(0, 5);

    const WIDGET_ICONS = {
      'image_banner':'🖼', 'product_slider':'🛒', 'product':'📦',
      'cond_product':'🔍', 'chart_bar':'📊',      'chart_line':'📈',
      'chart_pie':'🥧',   'text_banner':'📝',     'info_card':'ℹ️',
      'popup':'💬',        'file':'📎',            'file_list':'📁',
      'coupon':'🎟',       'html_editor':'📄',     'event_banner':'🎉',
      'cache_banner':'💰', 'widget_embed':'🧩',    'textarea':'📋',
      'markdown':'📑',     'barcode':'🔖',          'qrcode':'📱',
      'barcode_qrcode':'🔖','video_player':'▶️',   'countdown':'⏱',
      'payment_widget':'💳','approval_widget':'✅', 'map_widget':'🗺',
    };

    /* wIcon — w 아이콘 */
    const wIcon      = (v) => WIDGET_ICONS[v] || '▪';

    /* wTypeLabel — w 유형 라벨 */
    const wTypeLabel = (v) => codes.disp_widget_types.find(t => t.codeValue === v)?.codeLabel || v;

    const searchParam = reactive({ previewDate: today, previewTime: nowTime, filterType: '', filterStatus: '활성', filterVisibility: '', filterDispEnv: 'PROD', dashCanvas: null, searchType: '', searchValue: '' });
    /* searchParamInit — [초기화] 기준값. initPage 끝에서 그때의 searchParam 을 복사해 둔다.
       리터럴 기본값이 아니라 '화면을 열었을 때의 상태'가 기준이라, initPage 가 채운
       기본 기간·사이트 값도 함께 복원된다. (재대입 금지 — Object.assign 으로만 갱신) */
    const searchParamInit = {};

    const applied = reactive({ type: '', status: '활성', dispEnv: 'PROD', visibility: '', searchType: '', searchValue: '' });

    /* onSearch — 조회 */
    const onSearch = () => {
      Object.assign(applied, {
        type:       searchParam.filterType,
        status:     searchParam.filterStatus,
        dispEnv:    searchParam.filterDispEnv,
        searchType: searchParam.searchType,
        searchValue: (searchParam.searchValue || '').trim().toLowerCase(),
        visibility: searchParam.filterVisibility,
      });
    };

    /* onReset — 초기화 */
    const onReset = () => {
      Object.assign(searchParam, searchParamInit);
      Object.assign(applied, { type: '', status: '활성', dispEnv: 'PROD', visibility: '', searchType: '', searchValue: '' });
      resetCurrent();   // 검색 초기화 시 우측 미리보기(배치된 위젯)도 비움
    };

    /* _getType — 조회 */
    const _getType = (lib) => lib.widgetTypeCd || lib.widgetType || '';

    /* _getName — 조회 */
    const _getName = (lib) => lib.widgetNm || lib.name || '';

    /* _getDesc — 조회 */
    const _getDesc = (lib) => lib.widgetLibDesc || lib.desc || '';

    /* _getStatus — 조회 */
    const _getStatus = (lib) => lib.useYn === 'Y' ? '활성' : (lib.useYn === 'N' ? '비활성' : (lib.status || '활성'));

    /* _getPath — 조회 */
    const _getPath = (lib) => lib.pathId || (Array.isArray(lib.usedPaths) && lib.usedPaths[0]) || '';

    /* _getId — 조회 (위젯 인스턴스 ID 우선 — widgetLibId 는 참조 FK 라 식별자로 부적합) */
    const _getId   = (lib) => lib.widgetId || lib.libId || lib.widgetLibId || '';

    const cfFilteredLibs = computed(() => {
      const searchVal = (applied.searchValue || '').toLowerCase();
      const types = applied.searchType || 'widgetNm,tag,widgetLibDesc';
      return (widgetLibs || []).filter(lib => {
        if (applied.type   && _getType(lib)   !== applied.type) { return false; }
        if (applied.status && _getStatus(lib) !== applied.status) { return false; }
        if (applied.dispEnv && lib.dispEnv && !lib.dispEnv.includes('^' + applied.dispEnv + '^')) { return false; }
        if (searchVal) {
          const hits = [];
          if (types.includes('widgetNm')) { hits.push(_getName(lib).toLowerCase().includes(searchVal)); }
          if (types.includes('tag')) { hits.push((lib.tags || '').toLowerCase().includes(searchVal)); }
          if (types.includes('widgetLibDesc')) { hits.push(_getDesc(lib).toLowerCase().includes(searchVal)); }
          if (!hits.some(Boolean)) { return false; }
        }
        return true;
      });
    });

    /* onTreeSelect — 이벤트 */
    const onTreeSelect = (lib) => { uiState.selectedLibId = _getId(lib); };

    /* _splitPath — 분할 경로 */
    const _splitPath = (pathStr) => {
      if (!pathStr) { return []; }
      return String(pathStr).split(/[.\->]+/).map(s => s.trim()).filter(Boolean);
    };
    const cfTree = computed(() => {
      const map = {};

      /* addToPath — 추가 */
      const addToPath = (lib, pathStr) => {
        const parts = _splitPath(pathStr);
        if (!parts.length) {
          parts.push('(미등록)', '(미등록)');
        } else if (parts.length === 1) {
          parts.push('(루트)');
        }
        const top  = parts[0];
        const sub  = parts.slice(1).join(' > ');
        if (!map[top]) { map[top] = {}; }
        if (!map[top][sub]) { map[top][sub] = []; }
        map[top][sub].push(lib);
      };
      (cfFilteredLibs.value || []).forEach(lib => {
        const path = _getPath(lib);
        if (Array.isArray(lib.usedPaths) && lib.usedPaths.length) {
          lib.usedPaths.forEach(p => addToPath(lib, p));
        } else {
          addToPath(lib, path);
        }
      });
      return Object.keys(map).sort().map(top => ({
        label: top,
        children: Object.keys(map[top]).sort().map(sub => ({
          label: sub,
          libs: map[top][sub],
        })),
      }));
    });
    const openNodes = reactive(new Set());

    /* toggleNode — 노드 토글 */
    const toggleNode = (key) => {
      if (openNodes.has(key)) { openNodes.delete(key); }
      else { openNodes.add(key); }
    };

    /* isOpen — 여부 확인 */
    const isOpen = (key) => openNodes.has(key);

    /* allChildrenOpen — 전체 자식 열기 */
    const allChildrenOpen = (node) =>
      node.children.every(sub => openNodes.has(node.label + '_' + sub.label));

    /* toggleAllChildren — 전체 토글 */
    const toggleAllChildren = (e, node) => {
      e.stopPropagation();
      const open = !allChildrenOpen(node);
      node.children.forEach(sub => {
        const key = node.label + '_' + sub.label;
        if (open) { openNodes.add(key); }
        else { openNodes.delete(key); }
      });
      if (open) { openNodes.add(node.label); }
    };
    watchEffect(() => {
      if (!openNodes.has('__root__')) { openNodes.add('__root__'); }
      if (cfTree.value.length && openNodes.size === 1) {
        openNodes.add(cfTree.value[0].label);
      }
    });

    /* expandAll — 펼치기 전체 */
    const expandAll = () => { cfTree.value.forEach(n => openNodes.add(n.label)); openNodes.add('__root__'); };

    /* collapseAll — 접기 전체 */
    const collapseAll = () => { openNodes.clear(); openNodes.add('__root__'); };

    /* onItemDragStart — 이벤트 */
    const onItemDragStart = (e, lib) => {
      window._dragWidgetLib  = lib;
      window._dragWidgetLibs = null;
      e.dataTransfer.effectAllowed = 'copy';
      e.dataTransfer.setData('text/plain', _getId(lib));
    };

    /* onItemDragEnd — 이벤트 */
    const onItemDragEnd = () => { window._dragWidgetLib = null; };

    /* dedupeLibs — dedupeLibs */
    const dedupeLibs = (arr) => {
      const seen = new Set();
      return (arr || []).filter(lib => { const id = _getId(lib); if (seen.has(id)) return false; seen.add(id); return true; });
    };

    /* onNodeDragStart — 이벤트 */
    const onNodeDragStart = (e, allLibs) => {
      const libs = dedupeLibs(allLibs);
      window._dragWidgetLib  = null;
      window._dragWidgetLibs = libs;
      e.dataTransfer.effectAllowed = 'copy';
      e.dataTransfer.setData('text/plain', 'node:' + libs.length);
    };

    /* onNodeDragEnd — 이벤트 */
    const onNodeDragEnd = () => { window._dragWidgetLibs = null; };

    /* -- UI 상태 -- */
    const gridState = reactive({
      previewGrid: 'grid1',
      viewportMode: 'desktop',
      showRealContent: false,
      spanPopupIdx: -1,
      dashDragOver: false,
    });

    const GRID_TABS   = [
      { id:'grid1',     label:'grid1',     cols:1 },
      { id:'grid2',     label:'grid2',     cols:2 },
      { id:'grid3',     label:'grid3',     cols:3 },
      { id:'grid4',     label:'grid4',     cols:4 },
      { id:'dashboard', label:'dashboard', cols:null },
    ];
    const GRID_COLS = { grid1:1, grid2:2, grid3:3, grid4:4 };

    const VIEWPORT = {
      desktop: { label:'🖥 PC',     width: null  },
      tablet:  { label:'📟 태블릿', width:'768px' },
      mobile:  { label:'📱 모바일', width:'375px' },
    };
    /* auto-fill 반응형: 뷰포트 width 제약 + 브라우저 창 리사이즈 모두 반응 */
    const cfAutoGridColumns = computed(() => {
      const map = {
        grid1: 'repeat(1,1fr)',
        grid2: 'repeat(auto-fill,minmax(max(calc(50% - 5px),260px),1fr))',
        grid3: 'repeat(auto-fill,minmax(max(calc(33.333% - 6px),190px),1fr))',
        grid4: 'repeat(auto-fill,minmax(max(calc(25% - 6px),220px),1fr))',
      };
      return map[gridState.previewGrid] || 'repeat(1,1fr)';
    });

    /* makeInit — 생성 */
    const makeInit = (cols) => Array(cols * 2).fill(null);
    const tabSlots = reactive({
      grid1: makeInit(1),
      grid2: makeInit(2),
      grid3: makeInit(3),
      grid4: makeInit(4),
    });
    const cfCurrentSlots = computed(() => tabSlots[gridState.previewGrid] || []);

    /* autoExpand — 자동 펼치기 */
    const autoExpand = (tabId) => {
      const cols = GRID_COLS[tabId];
      if (!cols) { return; }
      const arr = tabSlots[tabId];
      const lastRowStart = arr.length - cols;
      if (arr.slice(lastRowStart).some(Boolean)) {
        for (let i = 0; i < cols; i++) { arr.push(null); }
      }
    };

    /* -- 드래그·드롭 (그리드) -- */
    const dragState = reactive({ dragOverIdx: -1 });

    /* onDragOver — 드래그 오버 (같은 슬롯이면 재할당 생략 → 불필요한 리렌더/깜빡임 방지) */
    const onDragOver  = (e, idx) => {
      e.preventDefault();
      if (e.dataTransfer) { e.dataTransfer.dropEffect = 'copy'; }
      if (dragState.dragOverIdx !== idx) { dragState.dragOverIdx = idx; }
    };

    /* onDragLeave — 슬롯 밖으로 실제 이탈할 때만 해제 (자식 진입 시 발생하는 깜빡임 방지) */
    const onDragLeave = (e, idx) => {
      const to = e.relatedTarget;
      if (to && e.currentTarget && e.currentTarget.contains(to)) { return; }
      if (dragState.dragOverIdx === idx) { dragState.dragOverIdx = -1; }
    };

    /* onDrop — 이벤트 */
    const onDrop = (e, idx) => {
      e.preventDefault(); dragState.dragOverIdx = -1;

      /* -- 노드 일괄 배치 -- */
      const nodeLibs = window._dragWidgetLibs;
      if (nodeLibs) {
        window._dragWidgetLibs = null;
        if (nodeLibs.length > 40) {
          showToast(`노드 하위 위젯이 ${nodeLibs.length}개로 40개를 초과합니다. 배치할 수 없습니다.`, 'error');
          return;
        }
        const tabId = gridState.previewGrid;
        const arr   = tabSlots[tabId];
        const cols  = GRID_COLS[tabId] || 1;
        let placed = 0, i = idx;
        while (placed < nodeLibs.length) {
          if (i >= arr.length) {
            for (let c = 0; c < cols; c++) { arr.push(null); }
          }
          if (!arr[i]) { arr.splice(i, 1, { ...nodeLibs[placed], colSpan: 1, rowSpan: 1 }); placed++; }
          i++;
        }
        autoExpand(tabId);
        return;
      }

      /* -- 단일 위젯 배치 -- */
      const lib = window._dragWidgetLib;
      if (!lib) { return; }
      const tabId = gridState.previewGrid;
      tabSlots[tabId].splice(idx, 1, { ...lib, colSpan: 1, rowSpan: 1 });
      autoExpand(tabId);
    };

    /* removeSlot — 제거 */
    const removeSlot = (idx) => { tabSlots[gridState.previewGrid].splice(idx, 1, null); };

    /* setSpan — 설정 */
    const setSpan = (idx, axis, delta) => {
      const slot = tabSlots[gridState.previewGrid][idx];
      if (!slot) { return; }
      const maxCol = GRID_COLS[gridState.previewGrid] || 1;
      if (axis === 'col') { slot.colSpan = Math.max(1, Math.min(maxCol, (slot.colSpan || 1) + delta)); }
      if (axis === 'row') { slot.rowSpan = Math.max(1, Math.min(4,      (slot.rowSpan || 1) + delta)); }
    };

    /* toggleSpanPopup — 토글 */
    const toggleSpanPopup = (e, idx) => {
      e.stopPropagation();
      gridState.spanPopupIdx = gridState.spanPopupIdx === idx ? -1 : idx;
    };

    /* closeSpanPopup — 닫기 */
    const closeSpanPopup = () => { gridState.spanPopupIdx = -1; };

    /* -- 대시보드: 자유 배치 + 크기 조절 -- */
    const dashItems  = reactive([]); // { id, lib, x, y, w, h }

    /* onDashDragOver — 이벤트 */
    const onDashDragOver = (e) => { e.preventDefault(); gridState.dashDragOver = true; };

    /* onDashDragLeave — 이벤트 */
    const onDashDragLeave = () => { gridState.dashDragOver = false; };

    /* onDashDrop — 이벤트 */
    const onDashDrop = (e) => {
      e.preventDefault(); gridState.dashDragOver = false;
      if (!searchParam.dashCanvas) { return; }
      const rect = searchParam.dashCanvas.getBoundingClientRect();

      /* -- 노드 일괄 배치 -- */
      const nodeLibs = window._dragWidgetLibs;
      if (nodeLibs) {
        window._dragWidgetLibs = null;
        if (nodeLibs.length > 40) {
          showToast(`노드 하위 위젯이 ${nodeLibs.length}개로 40개를 초과합니다. 배치할 수 없습니다.`, 'error');
          return;
        }
        const startX = Math.max(0, e.clientX - rect.left - 120);
        const startY = Math.max(0, e.clientY - rect.top  - 20);
        const COLS = 3, W = 260, H = 200, GAP = 10;
        window.safeArrayUtils.safeForEach(nodeLibs, (lib, i) => {
          const col = i % COLS, row = Math.floor(i / COLS);
          dashItems.push({ id: Date.now() + i, lib: { ...lib },
            x: startX + col * (W + GAP), y: startY + row * (H + GAP), w: W, h: H });
        });
        return;
      }

      /* -- 단일 위젯 배치 -- */
      const lib = window._dragWidgetLib;
      if (!lib) { return; }
      const x = Math.max(0, e.clientX - rect.left - 110);
      const y = Math.max(0, e.clientY - rect.top  - 20);
      dashItems.push({ id: Date.now(), lib: { ...lib }, x, y, w: 240, h: 180 });
    };

    /* removeDashItem — 제거 */
    const removeDashItem = (id) => {
      const i = dashItems.findIndex(d => d.id === id);
      if (i >= 0) { dashItems.splice(i, 1); }
    };

    /* startItemMove — 시작 항목 이동 */
    const startItemMove = (e, item) => {
      e.preventDefault();
      const ox = e.clientX - item.x;
      const oy = e.clientY - item.y;

      /* onMove — 이벤트 */
      const onMove = (me) => {
        item.x = Math.max(0, me.clientX - ox);
        item.y = Math.max(0, me.clientY - oy);
      };

      /* onUp — 이벤트 */
      const onUp = () => {
        document.removeEventListener('mousemove', onMove);
        document.removeEventListener('mouseup', onUp);
      };
      document.addEventListener('mousemove', onMove);
      document.addEventListener('mouseup', onUp);
    };

    /* startItemResize — 시작 항목 Resize */
    const startItemResize = (e, item) => {
      e.preventDefault(); e.stopPropagation();
      const sx = e.clientX, sy = e.clientY;
      const sw = item.w,    sh = item.h;

      /* onMove — 이벤트 */
      const onMove = (me) => {
        item.w = Math.max(160, sw + (me.clientX - sx));
        item.h = Math.max(120, sh + (me.clientY - sy));
      };

      /* onUp — 이벤트 */
      const onUp = () => {
        document.removeEventListener('mousemove', onMove);
        document.removeEventListener('mouseup', onUp);
      };
      document.addEventListener('mousemove', onMove);
      document.addEventListener('mouseup', onUp);
    };

    /* -- 배치 수 / 초기화 -- */
    const cfPlacedCount = computed(() =>
      gridState.previewGrid === 'dashboard'
        ? dashItems.length
        : (cfCurrentSlots.value || []).filter(Boolean).length
    );

    /* resetCurrent — 초기화 */
    const resetCurrent = () => {
      if (gridState.previewGrid === 'dashboard') {
        dashItems.splice(0);
      } else {
        const cols = GRID_COLS[gridState.previewGrid];
        const arr  = tabSlots[gridState.previewGrid];
        arr.splice(0, arr.length, ...makeInit(cols));
      }
    };

    // ===== return (템플릿 노출) ===============================================

    return {
      uiState, codes, searchParam, applied, gridState, dragState,                    // 상태 / 데이터
      tabSlots, dashItems,                                                            // 상태 (그리드/대시보드)
      handleBtnAction, handleSelectAction,                                            // dispatch (모든 이벤트 / 액션 라우팅)
      cfSiteNm, cfFilteredLibs, cfTree, cfAutoGridColumns, cfCurrentSlots,           // computed
      cfPlacedCount,                                                                  // computed
      VIEWPORT, GRID_TABS, GRID_COLS, today,                                          // 상수
      wIcon, wTypeLabel,                                                              // 헬퍼
      isOpen,                                                                         // 헬퍼 (template 사용)
      onItemDragStart, onItemDragEnd, onNodeDragStart, onNodeDragEnd,                 // 드래그 이벤트 (직접 바인딩)
      onDragOver, onDragLeave, onDrop,                                                // 그리드 드래그 (직접 바인딩)
      onDashDragOver, onDashDragLeave, onDashDrop,                                    // 대시보드 드래그 (직접 바인딩)
      startItemMove, startItemResize,                                                 // 대시보드 마우스 이동/리사이즈 (직접 바인딩)
      coUtil,                                                                         // template 에서 coUtil.cofAnd 직접 호출 → return 필수
    };
  },
  template: /* html */`
<div>
  <!-- ===== ■. 페이지 타이틀 ================================================= -->
  <div class="page-title" style="display:flex;align-items:center;justify-content:space-between;">
    <div>
      전시위젯미리보기
      <span style="font-size:13px;font-weight:400;color:#888;">위젯 트리 & 드래그하여 배치</span>
    </div>
    <span style="font-size:12px;background:#e8f0fe;color:#1565c0;border:1px solid #bbdefb;border-radius:10px;padding:3px 12px;font-weight:600;">
      🌐 {{ cfSiteNm }}
    </span>
  </div>

  <!-- ===== □. 페이지 타이틀 ================================================= -->
  <!-- ===== ■. 조회 조건 =================================================== -->
  <div class="card" style="padding:14px 18px;margin-bottom:12px;">
    <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
      <div style="display:flex;align-items:center;gap:5px;">
        <span style="font-size:12px;font-weight:600;color:#555;">📅 전시일시</span>
        <bo-date-time-picker v-model:date="searchParam.previewDate" v-model:time="searchParam.previewTime"
          :show-clear="false" date-width="136px" time-width="90px" />
      </div>
      <div style="width:1px;height:24px;background:#e0e0e0;"></div>
      <div style="display:flex;align-items:center;gap:5px;">
        <span style="font-size:12px;font-weight:600;color:#555;">상태</span>
        <select v-model="searchParam.filterStatus" class="form-control" style="width:76px;margin:0;font-size:12px;">
          <option value="">전체</option><option v-for="c in codes.active_statuses" :key="c.codeValue" :value="c.codeValue">{{ c.codeLabel }}</option>
        </select>
      </div>
      <div style="display:flex;align-items:center;gap:5px;">
        <span style="font-size:12px;font-weight:600;color:#555;">환경</span>
        <select v-model="searchParam.filterDispEnv" class="form-control" style="width:76px;margin:0;font-size:12px;">
          <option value="">전체</option><option v-for="c in codes.disp_envs" :key="c.codeValue" :value="c.codeValue">{{ c.codeLabel }}</option>
        </select>
      </div>
      <div style="display:flex;align-items:center;gap:5px;">
        <span style="font-size:12px;font-weight:600;color:#555;">공개대상</span>
        <select v-model="searchParam.filterVisibility" class="form-control" style="width:100px;margin:0;font-size:12px;">
          <option v-for="o in codes.visibility_opts" :key="o?.value" :value="o.value">{{ o.label }}</option>
        </select>
      </div>
      <div style="width:1px;height:24px;background:#e0e0e0;"></div>
      <div style="display:flex;align-items:center;gap:5px;">
        <span style="font-size:12px;font-weight:600;color:#555;">위젯유형</span>
        <!-- ===== ■.■.■.■. 영역 ================================================ -->
        <select v-model="searchParam.filterType" class="form-control" style="width:114px;margin:0;font-size:12px;">
          <option v-for="t in codes.disp_widget_types" :key="t?.value" :value="t.codeValue">{{ t.codeLabel }}</option>
        </select>
      </div>
      <bo-multi-check-select
        v-model="searchParam.searchType"
        :options="[
          { value: 'widgetNm',   label: '이름' },
          { value: 'tag',  label: '태그' },
          { value: 'widgetLibDesc', label: '설명' },
        ]"
        placeholder="검색대상 전체"
        all-label="전체 선택"
        min-width="130px" />
      <input v-model="searchParam.searchValue" class="form-control" placeholder="검색어 입력" style="margin:0;width:130px;font-size:12px;" @keyup.enter="handleBtnAction('searchParam-list')" />
      <span style="font-size:12px;color:#888;">총 <b>{{ cfFilteredLibs.length }}</b>건</span>
      <div style="display:flex;align-items:center;gap:6px;margin-left:auto;">
        <button @click="handleBtnAction('searchParam-reset')" class="btn btn_reset"
          style="padding:0;width:26px;height:26px;font-size:13px;display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;" title="초기화">🔄</button>
        <button @click="handleBtnAction('searchParam-list')" class="btn btn_search">검색</button>
      </div>
    </div>
  </div>

  <!-- ===== □. 조회 조건 =================================================== -->
  <!-- ===== ■. 2단 레이아웃 ================================================= -->
  <div style="display:flex;gap:12px;height:calc(100vh - 240px);min-height:500px;align-items:stretch;">

    <!-- ===== ■.■. 왼쪽: 트리 (카드) =========================================== -->
    <div class="card" style="width:340px;flex-shrink:0;display:flex;flex-direction:column;padding:0;overflow:hidden;">
      <div style="padding:7px 12px;border-bottom:1px solid #f0f0f0;font-size:12px;font-weight:700;color:#555;background:#fafafa;flex-shrink:0;display:flex;align-items:center;justify-content:space-between;">
        <span class="list-title">표시경로
          <span style="font-size:10px;color:#aaa;font-family:monospace;font-weight:400;margin-left:4px;">#ec_disp_widget</span>
        </span>
        <span style="font-size:10px;color:#aaa;font-weight:400;">⠿ 드래그하여 배치</span>
      </div>
      <!-- ===== ■.■.■. 전체펼치기 / 전체닫기 ======================================== -->
      <div style="padding:6px 12px;display:flex;gap:4px;border-bottom:1px solid #f0f0f0;background:#fff;flex-shrink:0;">
        <button @click="handleBtnAction('pathTree-expand-all')"
          style="flex:1;padding:4px 6px;font-size:10px;border:1px solid #d0d7de;border-radius:4px;background:#fff;color:#555;">
          ▼ 전체펼치기
        </button>
        <button @click="handleBtnAction('pathTree-collapse-all')"
          style="flex:1;padding:4px 6px;font-size:10px;border:1px solid #d0d7de;border-radius:4px;background:#fff;color:#555;">
          ▶ 전체닫기
        </button>
      </div>
      <div style="flex:1;overflow-y:auto;padding:4px 0;border-bottom:1px solid #ececec;">
        <!-- ===== ■.■.■.■. 루트 노드 ============================================= -->
        <div @click="handleSelectAction('pathTree-toggle', '__root__')"
          style="display:flex;align-items:center;gap:6px;padding:7px 12px;font-size:12px;font-weight:700;color:#222;user-select:none;background:#f8f9fb;border-radius:4px;margin:1px 4px;"
          :style="isOpen('__root__') ? 'background:#f0f4ff;' : ''">
          <span style="font-size:10px;color:#9ca3af;transition:transform .2s;"
            :style="isOpen('__root__') ? 'transform:rotate(90deg);' : ''">▶</span>
          <span>📂 전체</span>
          <span style="margin-left:auto;font-size:10px;background:#fff;color:#555;border:1px solid #ddd;border-radius:8px;padding:0 6px;">
            {{ cfTree.reduce((acc,n)=>acc+n.children.reduce((a,c)=>a+c.libs.length,0),0) }}
          </span>
        </div>
        <div v-if="isOpen('__root__')" style="padding-left:8px;">
        <div v-for="node in cfTree" :key="node?.label">
          <div @click="handleSelectAction('pathTree-toggle', node.label)"
            draggable="true"
            @dragstart="onNodeDragStart($event, node.children.flatMap(c => c.libs))"
            @dragend="onNodeDragEnd"
            style="display:flex;align-items:center;gap:6px;padding:6px 12px;cursor:grab;font-size:12px;font-weight:700;color:#374151;user-select:none;border-radius:4px;margin:1px 4px;"
            :style="isOpen(node.label) ? 'background:#f0f4ff;' : ''">
            <span style="font-size:10px;color:#9ca3af;transition:transform .2s;"
              :style="isOpen(node.label) ? 'transform:rotate(90deg);' : ''">▶</span>
            <span>{{ node.label }}</span>
            <span style="margin-left:auto;font-size:10px;background:#e5e7eb;color:#6b7280;border-radius:8px;padding:0 6px;">
              {{ node.children.reduce((acc,c)=>acc+c.libs.length,0) }}
            </span>
          </div>
          <template v-if="isOpen(node.label)">
            <div v-for="sub in node.children" :key="node.label+'_'+sub.label">
              <div @click="handleSelectAction('pathTree-toggle', node.label+'_'+sub.label)"
                draggable="true"
                @dragstart="onNodeDragStart($event, sub.libs)"
                @dragend="onNodeDragEnd"
                style="display:flex;align-items:center;gap:6px;padding:5px 12px 5px 26px;cursor:grab;font-size:11px;font-weight:600;color:#4b5563;border-radius:4px;margin:1px 4px;"
                :style="isOpen(node.label+'_'+sub.label) ? 'background:#f9fafb;' : ''">
                <span style="font-size:9px;color:#9ca3af;transition:transform .2s;"
                  :style="isOpen(node.label+'_'+sub.label) ? 'transform:rotate(90deg);' : ''">▶</span>
                <span>{{ sub.label }}</span>
                <span style="margin-left:auto;font-size:10px;background:#e5e7eb;color:#6b7280;border-radius:8px;padding:0 5px;">{{ sub.libs.length }}</span>
              </div>
              <!-- ===== ■.■.■.■.■.■.■. 조건부 영역 ====================================== -->
              <template v-if="isOpen(node.label+'_'+sub.label)">
                <div v-for="lib in sub.libs" :key="lib.widgetLibId || lib.libId"
                  draggable="true"
                  @dragstart="onItemDragStart($event, lib)"
                  @dragend="onItemDragEnd"
                  @click="handleSelectAction('pathTree-select', lib)"
                  style="display:flex;align-items:center;gap:7px;padding:5px 10px 5px 42px;cursor:grab;font-size:11px;border-radius:4px;margin:1px 4px;transition:background .15s;"
                  :style="uiState.selectedLibId===(lib.widgetLibId||lib.libId) ? 'background:#dbeafe;color:#1d4ed8;font-weight:700;' : 'color:#374151;'">
                  <span style="font-size:9px;color:#c4c4c4;flex-shrink:0;">⠿</span>
                  <span style="font-size:13px;flex-shrink:0;">{{ wIcon(lib.widgetTypeCd || lib.widgetType) }}</span>
                  <span style="font-size:9px;background:#f0f4ff;color:#1d4ed8;border:1px solid #dbeafe;border-radius:3px;padding:0 4px;white-space:nowrap;flex-shrink:0;">{{ wTypeLabel(lib.widgetTypeCd || lib.widgetType) }}</span>
                  <span style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">{{ lib.widgetNm || lib.name }}</span>
                </div>
              </template>
            </div>
          </template>
        </div>
        </div><!-- ===== /root children ===== -->
        <div v-if="!cfTree.length" style="padding:24px;text-align:center;color:#ccc;font-size:12px;">위젯이 없습니다.</div>
      </div>
    </div>

    <!-- ===== □.□. 왼쪽: 트리 (카드) =========================================== -->
    <!-- ===== ■.■. 오른쪽 (카드) ============================================== -->
    <div class="card" style="flex:1;display:flex;flex-direction:column;overflow:hidden;background:#f0f2f5;min-width:0;padding:0;">

      <!-- ===== ■.■.■. 영역 제목 ================================================ -->
      <div style="padding:7px 12px;border-bottom:1px solid #f0f0f0;background:#fafafa;flex-shrink:0;">
        <span class="list-title">미리보기</span>
      </div>
      <!-- ===== ■.■.■. 탭바 + 뷰포트 토글 + 배치수 =================================== -->
      <div style="display:flex;align-items:stretch;background:#f8f9fa;border-bottom:1px solid #e8e8e8;flex-shrink:0;padding:0 12px;">
        <div style="display:flex;gap:2px;align-items:flex-end;padding-top:8px;flex:1;">
          <button v-for="tab in GRID_TABS" :key="tab?.id" @click="handleSelectAction('preview-tab', tab.id)"
            style="padding:5px 14px;border:1px solid transparent;border-bottom:none;border-radius:6px 6px 0 0;font-size:12px;font-weight:600;transition:all .15s;margin-bottom:-1px;"
            :style="gridState.previewGrid===tab.id
              ? 'background:#fff;border-color:#e8e8e8;border-bottom-color:#fff;color:#1d4ed8;z-index:1;'
              : 'background:transparent;color:#9ca3af;'">
            {{ tab.label }}
          </button>
        </div>
        <!-- ===== ■.■.■.■. 실제컨텐츠 + 뷰포트 토글 (dashboard 제외) ===================== -->
        <div v-if="gridState.previewGrid!=='dashboard'" style="display:flex;align-items:center;gap:4px;padding:6px 0 6px 12px;border-left:1px solid #e5e7eb;margin-left:8px;">
          <button @click="handleBtnAction('preview-toggle-real')"
            style="font-size:11px;padding:3px 9px;border-radius:6px;border:1px solid #d1d5db;white-space:nowrap;transition:all .15s;margin-right:4px;"
            :style="gridState.showRealContent?'background:#059669;color:#fff;border-color:#059669;':'background:#fff;color:#6b7280;'">
            {{ gridState.showRealContent ? '✅ 실제컨텐츠' : '👁 실제컨텐츠' }}
          </button>
          <div style="width:1px;height:18px;background:#e5e7eb;margin-right:2px;"></div>
          <button v-for="(vp, key) in VIEWPORT" :key="key" @click="handleSelectAction('preview-viewport', key)"
            style="font-size:11px;padding:3px 8px;border-radius:6px;border:1px solid #d1d5db;white-space:nowrap;transition:all .15s;"
            :style="gridState.viewportMode===key
              ? 'background:#1d4ed8;color:#fff;border-color:#1d4ed8;'
              : 'background:#fff;color:#6b7280;'">
            {{ vp.label }}
          </button>
        </div>
        <div style="display:flex;align-items:center;gap:8px;padding:0 0 0 12px;">
          <span style="font-size:12px;color:#555;font-weight:600;">{{ cfPlacedCount }}개</span>
          <button @click="handleBtnAction('preview-reset')"
            style="font-size:11px;padding:3px 10px;border:1px solid #d0d0d0;border-radius:6px;background:#fff;color:#666;white-space:nowrap;">초기화</button>
        </div>
      </div>

      <!-- ===== ■.■.■. 그리드 캔버스 (grid1~4) =================================== -->
      <div v-if="gridState.previewGrid!=='dashboard'" @click="handleBtnAction('spanPopup-close')" style="flex:1;overflow-y:auto;overflow-x:auto;padding:16px;">
        <!-- ===== ■.■.■.■. 뷰포트 래퍼 ============================================ -->
        <div :style="{
          width: VIEWPORT[gridState.viewportMode].width || '100%',
          maxWidth: VIEWPORT[gridState.viewportMode].width || '100%',
          margin: '0 auto',
          transition: 'width .3s',
        }">
          <!-- ===== ■.■.■.■.■. 디바이스 프레임 표시 ===================================== -->
          <div v-if="gridState.viewportMode!=='desktop'"
            style="text-align:center;margin-bottom:8px;font-size:11px;color:#9ca3af;font-weight:600;">
            {{ gridState.viewportMode==='mobile' ? '📱 375px' : '📟 768px' }}
          </div>
          <div :style="{
            border: gridState.viewportMode!=='desktop' ? '2px solid #d1d5db' : 'none',
            borderRadius: gridState.viewportMode!=='desktop' ? '12px' : '0',
            padding: gridState.viewportMode!=='desktop' ? '12px' : '0',
            background: '#fff',
            boxShadow: gridState.viewportMode!=='desktop' ? '0 4px 20px rgba(0,0,0,.12)' : 'none',
          }">
            <div :style="{
              display: 'grid',
              gridTemplateColumns: cfAutoGridColumns,
              gap: '10px',
            }">
              <template v-for="(slot, idx) in cfCurrentSlots" :key="idx">
              <div v-if="!gridState.showRealContent || slot"
                @dragover="onDragOver($event, idx)"
                @dragleave="onDragLeave($event, idx)"
                @drop="onDrop($event, idx)"
                style="border-radius:8px;transition:all .15s;position:relative;"
                :style="[
                  dragState.dragOverIdx===idx
                    ? 'border:2px dashed #1d4ed8;background:#eff6ff;min-height:110px;'
                    : slot
                      ? (gridState.showRealContent ? 'border:none;background:transparent;min-height:0;' : 'border:1px solid #e5e7eb;background:#fff;box-shadow:0 1px 4px rgba(0,0,0,.07);min-height:110px;')
                      : 'border:2px dashed #d1d5db;background:#f9fafb;min-height:60px;',
                  (slot?.colSpan||1) > 1 ? { gridColumn: 'span ' + slot.colSpan } : {},
                  (slot?.rowSpan||1) > 1 ? { gridRow:    'span ' + slot.rowSpan } : {},
                ]">

                <!-- ===== ■.■.■.■.■.■.■.■. 비어있음 ====================================== -->
                <div v-if="!slot ? (dragState.dragOverIdx!==idx) : false"
                  style="height:100%;min-height:60px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:5px;color:#d1d5db;padding:10px;">
                  <span style="font-size:20px;">+</span>
                  <span style="font-size:11px;">드래그하여 추가</span>
                </div>

                <!-- ===== ■.■.■.■.■.■.■.■. 드롭 오버 ===================================== -->
                <div v-else-if="!slot ? (dragState.dragOverIdx===idx) : false"
                  style="min-height:60px;display:flex;align-items:center;justify-content:center;color:#1d4ed8;font-size:12px;font-weight:700;padding:10px;">
                  ▼ 여기에 추가
                </div>

                <!-- ===== ■.■.■.■.■.■.■.■. 배치됨 ======================================= -->
                <template v-else-if="slot">
                  <!-- ===== ■.■.■.■.■.■.■.■.■. 슬롯 헤더 (실제컨텐츠 OFF) ======================= -->
                  <div v-if="!gridState.showRealContent" style="display:flex;align-items:center;gap:5px;padding:6px 10px 5px;border-bottom:1px solid #f0f0f0;background:#fafafa;border-radius:8px 8px 0 0;">
                    <span style="font-size:12px;">{{ wIcon(slot.widgetTypeCd || slot.widgetType) }}</span>
                    <span style="font-size:10px;background:#f0f4ff;color:#1d4ed8;border:1px solid #dbeafe;border-radius:4px;padding:0 5px;white-space:nowrap;">{{ wTypeLabel(slot.widgetTypeCd || slot.widgetType) }}</span>
                    <span style="font-size:11px;font-weight:600;color:#333;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">{{ slot.widgetNm || slot.name }}</span>
                    <!-- ===== ■.■.■.■.■.■.■.■.■.■. span 설정 아이콘 =========================== -->
                    <button @click="handleSelectAction('slot-span-popup', { e: $event, idx })"
                      :title="'열 ' + (slot.colSpan||1) + ' × 행 ' + (slot.rowSpan||1)"
                      style="flex-shrink:0;width:22px;height:22px;border-radius:4px;border:1px solid #e5e7eb;font-size:13px;display:flex;align-items:center;justify-content:center;padding:0;transition:all .15s;"
                      :style="gridState.spanPopupIdx===idx ? 'background:#1d4ed8;color:#fff;border-color:#1d4ed8;' : 'background:#f9fafb;color:#6b7280;'">⚙</button>
                    <button @click="handleBtnAction('slot-remove', idx)"
                      style="flex-shrink:0;width:17px;height:17px;border-radius:50%;border:none;background:#e5e7eb;color:#6b7280;font-size:10px;display:flex;align-items:center;justify-content:center;padding:0;">✕</button>
                  </div>

                  <!-- ===== ■.■.■.■.■.■.■.■.■. span 설정 레이어 팝업 ========================== -->
                  <div v-if="gridState.spanPopupIdx===idx" @click.stop
                    style="position:absolute;top:36px;right:6px;z-index:20;background:#fff;border:1px solid #e5e7eb;border-radius:8px;box-shadow:0 4px 16px rgba(0,0,0,.12);padding:12px 14px;min-width:170px;">
                    <!-- ===== ■.■.■.■.■.■.■.■.■.■. 닫기 ==================================== -->
                    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;">
                      <span style="font-size:11px;font-weight:700;color:#374151;">그리드 스팬 설정</span>
                      <button @click="handleBtnAction('spanPopup-close')" style="border:none;background:none;font-size:13px;color:#9ca3af;padding:0;line-height:1;">✕</button>
                    </div>
                    <!-- ===== ■.■.■.■.■.■.■.■.■.■. 열(colspan) ============================ -->
                    <div style="display:flex;align-items:center;gap:6px;margin-bottom:8px;">
                      <span style="font-size:11px;color:#6b7280;width:36px;">열 span</span>
                      <button @click="handleSelectAction('slot-span-set', { idx, axis:'col', delta:-1 })" :disabled="(slot.colSpan||1)<=1"
                        style="width:24px;height:24px;border:1px solid #e5e7eb;border-radius:4px;background:#f9fafb;font-size:13px;display:flex;align-items:center;justify-content:center;padding:0;"
                        :style="(slot.colSpan||1)<=1?'opacity:.3;cursor:default;':''">−</button>
                      <span style="min-width:28px;text-align:center;font-size:14px;font-weight:700;color:#1d4ed8;">{{ slot.colSpan||1 }}</span>
                      <button @click="handleSelectAction('slot-span-set', { idx, axis:'col', delta:+1 })" :disabled="(slot.colSpan||1)>=(GRID_COLS[gridState.previewGrid]||1)"
                        style="width:24px;height:24px;border:1px solid #e5e7eb;border-radius:4px;background:#f9fafb;font-size:13px;display:flex;align-items:center;justify-content:center;padding:0;"
                        :style="(slot.colSpan||1)>=(GRID_COLS[gridState.previewGrid]||1)?'opacity:.3;cursor:default;':''">+</button>
                      <span style="font-size:10px;color:#9ca3af;">/ {{ GRID_COLS[gridState.previewGrid]||1 }}</span>
                    </div>
                    <!-- ===== ■.■.■.■.■.■.■.■.■.■. 행(rowspan) ============================ -->
                    <div style="display:flex;align-items:center;gap:6px;">
                      <span style="font-size:11px;color:#6b7280;width:36px;">행 span</span>
                      <button @click="handleSelectAction('slot-span-set', { idx, axis:'row', delta:-1 })" :disabled="(slot.rowSpan||1)<=1"
                        style="width:24px;height:24px;border:1px solid #e5e7eb;border-radius:4px;background:#f9fafb;font-size:13px;display:flex;align-items:center;justify-content:center;padding:0;"
                        :style="(slot.rowSpan||1)<=1?'opacity:.3;cursor:default;':''">−</button>
                      <span style="min-width:28px;text-align:center;font-size:14px;font-weight:700;color:#1d4ed8;">{{ slot.rowSpan||1 }}</span>
                      <button @click="handleSelectAction('slot-span-set', { idx, axis:'row', delta:+1 })" :disabled="(slot.rowSpan||1)>=4"
                        style="width:24px;height:24px;border:1px solid #e5e7eb;border-radius:4px;background:#f9fafb;font-size:13px;display:flex;align-items:center;justify-content:center;padding:0;"
                        :style="(slot.rowSpan||1)>=4?'opacity:.3;cursor:default;':''">+</button>
                      <span style="font-size:10px;color:#9ca3af;">/ 4</span>
                    </div>
                  </div>
                  <!-- ===== ■.■.■.■.■.■.■.■.■. 실제컨텐츠 ON: ×버튼만 ========================== -->
                  <div v-else style="position:relative;">
                    <button @click="handleBtnAction('slot-remove', idx)"
                      style="position:absolute;top:4px;right:4px;z-index:5;width:18px;height:18px;border-radius:50%;border:none;background:rgba(0,0,0,.3);color:#fff;font-size:11px;line-height:1;display:flex;align-items:center;justify-content:center;padding:0;">✕</button>
                  </div>
                  <!-- ===== ■.■.■.■.■.■.■.■.■. 위젯미리보기 ================================== -->
                  <widget-preview :lib="slot" />
                </template>

              </div><!-- ===== /slot ===== -->
              </template>
            </div><!-- ===== /grid ===== -->
          </div><!-- ===== /device frame ===== -->
        </div><!-- ===== /viewport wrapper ===== -->
      </div><!-- ===== /grid canvas ===== -->

      <!-- ===== ■.■.■. 대시보드 캔버스 (자유 배치) ==================================== -->
      <div v-else style="flex:1;overflow:auto;padding:16px;">
        <div
          ref="dashCanvas"
          @dragover="onDashDragOver"
          @dragleave="onDashDragLeave"
          @drop="onDashDrop"
          style="position:relative;min-height:560px;min-width:600px;background:#fff;border-radius:8px;border:2px dashed #e5e7eb;transition:border-color .15s;"
          :style="gridState.dashDragOver ? 'border-color:#1d4ed8;background:#eff6ff;' : ''">

          <!-- ===== ■.■.■.■.■. 빈 상태 ============================================ -->
          <div v-if="!dashItems.length ? (!gridState.dashDragOver) : false"
            style="position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;color:#d1d5db;pointer-events:none;">
            <span style="font-size:48px;">🧩</span>
            <span style="font-size:13px;">왼쪽 트리에서 위젯을 드래그하여 배치하세요</span>
          </div>
          <div v-if="gridState.dashDragOver ? (!dashItems.length) : false"
            style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;color:#1d4ed8;font-size:14px;font-weight:700;pointer-events:none;">
            ▼ 여기에 배치
          </div>

          <!-- ===== ■.■.■.■.■. 배치된 아이템 ========================================= -->
          <div v-for="item in dashItems" :key="item?.id"
            :style="{
              position:'absolute',
              left: item.x+'px',
              top:  item.y+'px',
              width: item.w+'px',
              minHeight: item.h+'px',
              border:'1px solid #e5e7eb',
              borderRadius:'8px',
              background:'#fff',
              boxShadow:'0 2px 10px rgba(0,0,0,.1)',
              userSelect:'none',
              zIndex: 1,
            }">

            <!-- ===== ■.■.■.■.■.■. 이동 핸들 헤더 ====================================== -->
            <div
              @mousedown="startItemMove($event, item)"
              style="display:flex;align-items:center;gap:5px;padding:6px 10px;background:#f8f9fa;border-bottom:1px solid #f0f0f0;border-radius:8px 8px 0 0;cursor:move;">
              <span style="font-size:10px;color:#c4c4c4;letter-spacing:1px;">⠿⠿</span>
              <span style="font-size:12px;">{{ wIcon(item.lib.widgetTypeCd || item.lib.widgetType) }}</span>
              <span style="font-size:11px;background:#f0f4ff;color:#1d4ed8;border:1px solid #dbeafe;border-radius:4px;padding:0 5px;white-space:nowrap;flex-shrink:0;">{{ wTypeLabel(item.lib.widgetTypeCd || item.lib.widgetType) }}</span>
              <span style="font-size:11px;font-weight:600;color:#333;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;min-width:0;">{{ item.lib.widgetNm || item.lib.name }}</span>
              <button @mousedown.stop @click="handleBtnAction('dashItem-remove', item.id)"
                style="flex-shrink:0;width:18px;height:18px;border-radius:50%;border:none;background:#e5e7eb;color:#6b7280;font-size:10px;display:flex;align-items:center;justify-content:center;padding:0;">✕</button>
            </div>

            <!-- ===== ■.■.■.■.■.■. 위젯미리보기 ======================================== -->
            <div style="overflow:hidden;" :style="{maxHeight:(item.h-40)+'px'}">
              <widget-preview :lib="item.lib" />
            </div>

            <!-- ===== ■.■.■.■.■.■. 크기 조절 핸들 ====================================== -->
            <div
              @mousedown="startItemResize($event, item)"
              style="position:absolute;right:0;bottom:0;width:18px;height:18px;cursor:se-resize;border-radius:0 0 8px 0;overflow:hidden;">
              <div style="width:0;height:0;border-style:solid;border-width:0 0 18px 18px;border-color:transparent transparent #d1d5db transparent;position:absolute;right:0;bottom:0;"></div>
            </div>

            <!-- ===== ■.■.■.■.■.■. 크기 표시 ========================================= -->
            <div style="position:absolute;right:22px;bottom:3px;font-size:9px;color:#c4c4c4;pointer-events:none;user-select:none;">
              {{ Math.round(item.w) }}×{{ Math.round(item.h) }}
            </div>
          </div>

        </div><!-- ===== /dashCanvas ===== -->
      </div><!-- ===== /dashboard ===== -->

    </div><!-- ===== /오른쪽 ===== -->
  </div><!-- ===== /2단 ===== -->
</div>
  
    <!-- ===== □.□. 오른쪽 (카드) ============================================== -->
  <!-- ===== □. 2단 레이아웃 ================================================= -->`,
  components: {
    WidgetPreview: _WP_DispWidgetPreview,
  },
};
